#!/usr/bin/env python3
# ==============================================================================
# FOUGO EXTERNAL — TELEGRAM OWNER BOT & KEY MANAGEMENT SERVER
# Support: @MYZO_PANEL | Channel: https://t.me/cheatgnexusiphone
# ==============================================================================
import os
import json
import secrets

# 1. Paste your Telegram Bot Token (from @BotFather) and Owner ID (from @userinfobot) here:
BOT_TOKEN = os.environ.get("8959294066:AAG_eAPPFVv_TSCsz6-SrjElpiRJhsT5ezo")
OWNER_ID = int(os.environ.get("8245269289"))

APP_CONFIG = {
    "app_name": "Fougo External",
    "login_headline": "Fougo External License Gateway",
    "login_notice": "Enter your license key to authenticate your device HWID and unlock Fougo External modules.",
    "dashboard_announcement": "Fougo External v3.4.0 is live.",
    "theme_preset": "emerald",
    "support_handle": "@MYZO_PANEL",
    "channel_url": "https://t.me/cheatgnexusiphone",
    "brandowner_removed": True,
    "startup_channel_redirect": False
}

def generate_license_key(plan="7D", prefix="FOUGO"):
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    p1 = "".join(secrets.choice(chars) for _ in range(4))
    p2 = "".join(secrets.choice(chars) for _ in range(4))
    return f"{prefix}-{plan}-{p1}-{p2}"

def bulk_generate(count=10, plan="7D", prefix="FOUGO"):
    return [generate_license_key(plan, prefix) for _ in range(count)]

if __name__ == "__main__":
    print("[*] Fougo External Telegram Owner Bot Ready.")
    print("[*] Bot Token:", BOT_TOKEN[:12] + "...")
    print("[*] Owner ID:", OWNER_ID)
    for k in bulk_generate(5, "30D"):
        print(" ->", k)
