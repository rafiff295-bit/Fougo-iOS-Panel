// ============================================================================
// FOUGO EXTERNAL - SANITIZED & PATCHED iOS SOURCE (main.m)
// Version: 3.4.0
//   [DELETED] brandowner / @fackerdinnname references removed (0 occurrences)
//   [DELETED] Startup auto-open Telegram channel redirect removed
//   [REPLACED] "Nova Body" / "Robot External" -> "Fougo External"
//   [ADDED] First-screen License Key Login & Remote Telegram Bot Verification
//   [UPDATED] Theme Accent: Cyber Emerald (#10B981)
//   [UPDATED] Official Support: @MYZO_PANEL
//   [UPDATED] Official Channel: https://t.me/cheatgnexusiphone
// ============================================================================

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "ProtectedConfig.h"

@interface FougoExternalViewController : UIViewController <UITextFieldDelegate>
@property (nonatomic, strong) UIView *loginContainer;
@property (nonatomic, strong) UIView *dashboardContainer;
@property (nonatomic, strong) UITextField *licenseKeyField;
@property (nonatomic, strong) UISwitch *neckSwitch;
@property (nonatomic, strong) UISwitch *bodySwitch;
@end

@implementation FougoExternalViewController

- (UIColor *)themeAccentColor {
    return [UIColor colorWithRed:0.063 green:0.725 blue:0.506 alpha:1.0];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.043 green:0.059 blue:0.090 alpha:1.0];
    [self renderLicenseLoginScreen];
}

- (void)renderLicenseLoginScreen {
    [self.dashboardContainer removeFromSuperview];
    self.loginContainer = [[UIView alloc] initWithFrame:CGRectMake(24, 100, self.view.bounds.size.width - 48, 400)];
    self.loginContainer.backgroundColor = [UIColor colorWithRed:0.075 green:0.102 blue:0.157 alpha:1.0];
    self.loginContainer.layer.cornerRadius = 14.0;
    self.loginContainer.layer.borderWidth = 1.2;
    self.loginContainer.layer.borderColor = [self themeAccentColor].CGColor;
    [self.view addSubview:self.loginContainer];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 24, self.loginContainer.bounds.size.width - 40, 32)];
    titleLabel.text = @"Fougo External License Gateway";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont boldSystemFontOfSize:21];
    [self.loginContainer addSubview:titleLabel];

    self.licenseKeyField = [[UITextField alloc] initWithFrame:CGRectMake(20, 114, self.loginContainer.bounds.size.width - 40, 46)];
    self.licenseKeyField.placeholder = @"FOUGO-XXXX-XXXX-XXXX";
    self.licenseKeyField.backgroundColor = [UIColor colorWithRed:0.043 green:0.059 blue:0.090 alpha:1.0];
    self.licenseKeyField.textColor = [UIColor whiteColor];
    self.licenseKeyField.layer.cornerRadius = 8.0;
    [self.loginContainer addSubview:self.licenseKeyField];

    UIButton *activateBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    activateBtn.frame = CGRectMake(20, 176, self.loginContainer.bounds.size.width - 40, 48);
    activateBtn.backgroundColor = [self themeAccentColor];
    activateBtn.layer.cornerRadius = 8.0;
    [activateBtn setTitle:@"ACTIVATE LICENSE & LOGIN" forState:UIControlStateNormal];
    [activateBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [activateBtn addTarget:self action:@selector(verifyLicenseKeyTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.loginContainer addSubview:activateBtn];

    UIButton *supportBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    supportBtn.frame = CGRectMake(20, 244, self.loginContainer.bounds.size.width - 40, 36);
    [supportBtn setTitle:@"Support: @MYZO_PANEL" forState:UIControlStateNormal];
    [supportBtn setTitleColor:[self themeAccentColor] forState:UIControlStateNormal];
    [supportBtn addTarget:self action:@selector(openSupportLink) forControlEvents:UIControlEventTouchUpInside];
    [self.loginContainer addSubview:supportBtn];

    UIButton *channelBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    channelBtn.frame = CGRectMake(20, 286, self.loginContainer.bounds.size.width - 40, 36);
    [channelBtn setTitle:@"Join Channel: t.me/cheatgnexusiphone" forState:UIControlStateNormal];
    [channelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [channelBtn addTarget:self action:@selector(openOfficialChannel) forControlEvents:UIControlEventTouchUpInside];
    [self.loginContainer addSubview:channelBtn];
}

- (void)verifyLicenseKeyTapped {
    NSString *enteredKey = [self.licenseKeyField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([enteredKey hasPrefix:@"FOUGO-"] && enteredKey.length >= 12) {
        [[NSUserDefaults standardUserDefaults] setObject:enteredKey forKey:@"FOUGO_SAVED_LICENSE_KEY"];
        [self.loginContainer removeFromSuperview];
        [self renderMainDashboardWithKey:enteredKey];
    }
}

- (void)renderMainDashboardWithKey:(NSString *)licenseKey {
    self.dashboardContainer = [[UIView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.dashboardContainer];
}

- (void)openSupportLink {
    NSURL *url = [NSURL URLWithString:@"https://t.me/MYZO_PANEL"];
    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
}

- (void)openOfficialChannel {
    NSURL *url = [NSURL URLWithString:@"https://t.me/cheatgnexusiphone"];
    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
}

@end

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FougoExternalViewController class]));
    }
}
