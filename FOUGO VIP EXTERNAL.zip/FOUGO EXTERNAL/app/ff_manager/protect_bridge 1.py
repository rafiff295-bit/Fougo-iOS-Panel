import os
bot_token = os.environ.get("TELEGRAM_BOT_TOKEN", "8123456789:AAH_YOUR_TELEGRAM_BOT_TOKEN_HERE")
owner_id = os.environ.get("TELEGRAM_OWNER_ID", "6849201944")

header = f"""#ifndef ProtectedConfig_h
#define ProtectedConfig_h
#define FOUGO_APP_NAME @"Fougo External"
#define FOUGO_SUPPORT_HANDLE @"@MYZO_PANEL"
#define FOUGO_SUPPORT_URL @"https://t.me/MYZO_PANEL"
#define FOUGO_CHANNEL_URL @"https://t.me/cheatgnexusiphone"
#define FOUGO_TELEGRAM_BOT_TOKEN @"{bot_token}"
#define FOUGO_TELEGRAM_OWNER_ID @"{owner_id}"
#endif
"""
with open(os.path.join(os.path.dirname(__file__), "ProtectedConfig.h"), "w") as f:
    f.write(header)
print("[+] ProtectedConfig.h generated cleanly for Fougo External.")
