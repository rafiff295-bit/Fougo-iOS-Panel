#ifndef ProtectedConfig_h
#define ProtectedConfig_h

#define FOUGO_APP_NAME              @"Fougo External"
#define FOUGO_APP_VERSION           @"3.4.0"
#define FOUGO_THEME_HEX             @"#10B981"
#define FOUGO_REMOVE_BRANDOWNER     1
#define FOUGO_STARTUP_CHANNEL_OPEN  0
#define FOUGO_SUPPORT_HANDLE        @"@MYZO_PANEL"
#define FOUGO_SUPPORT_URL           @"https://t.me/MYZO_PANEL"
#define FOUGO_CHANNEL_URL           @"https://t.me/cheatgnexusiphone"
#define FOUGO_TELEGRAM_OWNER_BOT    @"@FougoOwnerControlBot"
#define FOUGO_TELEGRAM_BOT_TOKEN    @"8123456789:AAH_YOUR_TELEGRAM_BOT_TOKEN_HERE"
#define FOUGO_TELEGRAM_OWNER_ID     @"6849201944"

#endif /* ProtectedConfig_h */
