#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FOUGO EXTERNAL — License Key Gateway + Telegram Bot (Owner / Admin / Seller Panels)
Complete Standalone Backend Server (SQLite + Flask REST API + Telegram Bot Polling)
"""

import os
import re
import sys
import json
import time
import secrets
import sqlite3
import hashlib
import datetime
import threading
import urllib.request
import urllib.error
from flask import Flask, request, jsonify

WORKSPACE = os.environ.get("GITHUB_WORKSPACE", os.getcwd())
DB_PATH = os.path.join(WORKSPACE, "fougo_enterprise.db")
CLOUD_JSON_PATH = os.path.join(WORKSPACE, "fougo_cloud_db.json")
BOT_TOKEN = (
    os.environ.get("BOT_TOKEN")
    or os.environ.get("TELEGRAM_BOT_TOKEN")
    or os.environ.get("INPUT_BOT_TOKEN")
    or ""
).strip()
OWNER_ID = (
    os.environ.get("OWNER_ID")
    or os.environ.get("TELEGRAM_OWNER_ID")
    or os.environ.get("INPUT_OWNER_ID")
    or ""
).strip()

db_lock = threading.Lock()
live_tunnel_url = ""

CREDIT_COSTS = {
    1: 1,      # 1 Day = 1 Credit
    7: 3,      # 7 Days = 3 Credits
    30: 7,     # 30 Days = 7 Credits
    3650: 20,  # Lifetime = 20 Credits
}


def now_iso() -> str:
    return datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")


def hash_pw(pw: str, salt: str = "fougo_liquid_salt") -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt.encode("utf-8"), 100000).hex()


def db_exec(sql: str, params: tuple = (), fetch: bool = False):
    with db_lock:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute(sql, params)
        rows = [dict(r) for r in cur.fetchall()] if fetch else []
        conn.commit()
        conn.close()
        return rows


def init_db():
    db_exec(
        "CREATE TABLE IF NOT EXISTS licenses ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "key TEXT UNIQUE,"
        "status TEXT DEFAULT 'Active',"
        "duration_days INTEGER DEFAULT 30,"
        "max_devices INTEGER DEFAULT 1,"
        "seller_id TEXT DEFAULT 'OWNER',"
        "note TEXT DEFAULT '',"
        "created_at TEXT,"
        "activated_at TEXT DEFAULT '',"
        "expires_at TEXT DEFAULT '',"
        "session_id TEXT DEFAULT '',"
        "device_info TEXT DEFAULT ''"
        ")"
    )
    db_exec(
        "CREATE TABLE IF NOT EXISTS sessions ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "license_id INTEGER,"
        "license_key TEXT,"
        "session_id TEXT UNIQUE,"
        "device_info TEXT,"
        "created_at TEXT,"
        "last_active TEXT,"
        "status TEXT DEFAULT 'Active'"
        ")"
    )
    db_exec(
        "CREATE TABLE IF NOT EXISTS staff_users ("
        "telegram_id TEXT PRIMARY KEY,"
        "username TEXT DEFAULT '',"
        "role TEXT DEFAULT 'SELLER',"
        "credits INTEGER DEFAULT 0,"
        "total_keys_created INTEGER DEFAULT 0,"
        "status TEXT DEFAULT 'Active',"
        "permissions TEXT DEFAULT 'default',"
        "added_at TEXT"
        ")"
    )
    db_exec(
        "CREATE TABLE IF NOT EXISTS credit_logs ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "seller_id TEXT,"
        "delta INTEGER,"
        "balance_after INTEGER,"
        "reason TEXT,"
        "actor TEXT,"
        "created_at TEXT"
        ")"
    )
    db_exec(
        "CREATE TABLE IF NOT EXISTS announcements ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "title TEXT,"
        "message TEXT,"
        "enabled INTEGER DEFAULT 1,"
        "created_at TEXT"
        ")"
    )
    db_exec(
        "CREATE TABLE IF NOT EXISTS activity_logs ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "actor TEXT,"
        "category TEXT,"
        "action TEXT,"
        "details TEXT,"
        "created_at TEXT"
        ")"
    )
    db_exec("CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)")

    defaults = {
        "owner_username": "owner",
        "owner_password_hash": hash_pw("FougoOwner#2026"),
        "admin_username": "admin",
        "admin_password_hash": hash_pw("FougoAdmin#2026"),
        "seller_username": "seller",
        "seller_password_hash": hash_pw("FougoSeller#2026"),
        "website_name": "FOUGO EXTERNAL",
        "login_title": "FOUGO EXTERNAL",
        "subtitle": "Frosted Liquid-Glass License Gateway",
        "maintenance_mode": "OFF",
        "maintenance_description": "Scheduled maintenance in progress. Please try again shortly.",
        "cost_1d": "1",
        "cost_7d": "3",
        "cost_30d": "7",
        "cost_lifetime": "20",
    }
    for k, v in defaults.items():
        db_exec("INSERT OR IGNORE INTO settings (k, v) VALUES (?, ?)", (k, v))

    if OWNER_ID:
        db_exec(
            "INSERT OR REPLACE INTO staff_users (telegram_id, username, role, credits, status, permissions, added_at) "
            "VALUES (?, 'Owner', 'OWNER', 999999, 'Active', 'all', ?)",
            (str(OWNER_ID), now_iso()),
        )

    # Ensure demo keys & demo seller exist for instant testing
    if not db_exec("SELECT id FROM licenses", fetch=True):
        exp30 = (datetime.datetime.utcnow() + datetime.timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S UTC")
        db_exec(
            "INSERT OR IGNORE INTO licenses (key, status, duration_days, max_devices, seller_id, note, created_at, expires_at) "
            "VALUES (?, 'Active', 30, 1, 'OWNER', 'Default VIP Key', ?, ?)",
            ("FOUGO-VIP-9942-ABCD", now_iso(), exp30),
        )
        db_exec(
            "INSERT OR IGNORE INTO licenses (key, status, duration_days, max_devices, seller_id, note, created_at, expires_at) "
            "VALUES (?, 'Active', 3650, 2, 'OWNER', 'Lifetime Master Key', ?, 'Lifetime')",
            ("FOUGO-LIFE-8821-XY99", now_iso()),
        )


def get_setting(k: str, default: str = "") -> str:
    rows = db_exec("SELECT v FROM settings WHERE k=?", (k,), fetch=True)
    return rows[0]["v"] if rows else default


def set_setting(k: str, v: str):
    db_exec("INSERT OR REPLACE INTO settings (k, v) VALUES (?, ?)", (k, str(v)))


def log_event(actor: str, category: str, action: str, details: str = ""):
    db_exec(
        "INSERT INTO activity_logs (actor, category, action, details, created_at) VALUES (?, ?, ?, ?, ?)",
        (str(actor), category, action, details, now_iso()),
    )


def get_user_role(uid) -> tuple:
    uid_s = str(uid)
    if OWNER_ID and uid_s == str(OWNER_ID):
        return "OWNER", 999999, "Active"
    rows = db_exec("SELECT * FROM staff_users WHERE telegram_id=?", (uid_s,), fetch=True)
    if not rows:
        all_staff = db_exec("SELECT * FROM staff_users", fetch=True)
        if not all_staff and not OWNER_ID:
            db_exec(
                "INSERT INTO staff_users (telegram_id, username, role, credits, status, permissions, added_at) "
                "VALUES (?, 'PrimaryOwner', 'OWNER', 999999, 'Active', 'all', ?)",
                (uid_s, now_iso()),
            )
            return "OWNER", 999999, "Active"
        return None, 0, "Inactive"
    r = rows[0]
    return r["role"].upper(), int(r["credits"] or 0), r["status"]


def generate_license_keys(actor_id: str, role: str, days: int, qty: int, max_dev: int = 1, note: str = ""):
    days = int(days)
    qty = max(1, min(100, int(qty)))
    cost_per_key = CREDIT_COSTS.get(days, max(1, days // 4))
    total_cost = cost_per_key * qty

    if role == "SELLER":
        staff = db_exec("SELECT * FROM staff_users WHERE telegram_id=?", (str(actor_id),), fetch=True)
        if not staff or staff[0]["status"] != "Active":
            return None, "Seller account is inactive or frozen."
        bal = int(staff[0]["credits"] or 0)
        if bal < total_cost:
            return None, f"Insufficient Seller Credits! Need {total_cost} Cr, Available: {bal} Cr."
        new_bal = bal - total_cost
        new_total = int(staff[0]["total_keys_created"] or 0) + qty
        db_exec(
            "UPDATE staff_users SET credits=?, total_keys_created=? WHERE telegram_id=?",
            (new_bal, new_total, str(actor_id)),
        )
        db_exec(
            "INSERT INTO credit_logs (seller_id, delta, balance_after, reason, actor, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (str(actor_id), -total_cost, new_bal, f"Generated {qty}x {days}d key(s)", str(actor_id), now_iso()),
        )

    exp = (
        "Lifetime"
        if days >= 3650
        else (datetime.datetime.utcnow() + datetime.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S UTC")
    )
    created_keys = []
    for _ in range(qty):
        k = f"FOUGO-{secrets.token_hex(2).upper()}-{secrets.token_hex(2).upper()}-{secrets.token_hex(2).upper()}"
        db_exec(
            "INSERT INTO licenses (key, status, duration_days, max_devices, seller_id, note, created_at, expires_at) "
            "VALUES (?, 'Active', ?, ?, ?, ?, ?, ?)",
            (k, days, int(max_dev), str(actor_id), note or f"{role}-Issued", now_iso(), exp),
        )
        created_keys.append(k)

    log_event(actor_id, "keys", "generate_keys", f"Role={role} Qty={qty} Days={days}")
    return created_keys, exp


# ============================================================================
# Flask REST API (iOS App Validation + Owner / Admin / Seller Web Endpoints)
# ============================================================================
app = Flask(__name__)


@app.route("/api/status", methods=["GET"])
def api_status():
    lics = db_exec("SELECT * FROM licenses ORDER BY id DESC", fetch=True)
    staff = db_exec("SELECT * FROM staff_users ORDER BY role ASC", fetch=True)
    anns = db_exec("SELECT * FROM announcements WHERE enabled=1 ORDER BY id DESC LIMIT 5", fetch=True)
    return jsonify({
        "ok": True,
        "maintenance": get_setting("maintenance_mode", "OFF") == "ON",
        "maintenance_message": get_setting("maintenance_description"),
        "total_licenses": len(lics),
        "active_licenses": sum(1 for x in lics if x["status"] == "Active"),
        "total_staff": len(staff),
        "announcements": anns,
        "licenses": lics[:50],
        "staff": staff,
    })


@app.route("/api/license/validate", methods=["POST"])
def api_validate_license():
    if get_setting("maintenance_mode") == "ON":
        return jsonify({
            "ok": False,
            "error": "MAINTENANCE_MODE",
            "message": get_setting("maintenance_description"),
        }), 503

    data = request.get_json(silent=True) or {}
    raw_k = data.get("key") or ""
    k = re.sub(r"[\s`'\"\u200b\u200c\u200d\ufeff]+", "", str(raw_k)).upper()
    udid = (data.get("udid") or data.get("device") or "IOS-ARM64-DEVICE")[:120]

    rows = db_exec("SELECT * FROM licenses WHERE UPPER(TRIM(key))=?", (k,), fetch=True)
    if not rows:
        log_event(udid, "auth", "invalid_key", f"Key={k}")
        return jsonify({"ok": False, "error": "INVALID_KEY", "message": "Invalid License Key"}), 401

    lic = rows[0]
    if lic["status"] != "Active":
        return jsonify({"ok": False, "error": f"KEY_{lic['status'].upper()}", "message": f"Key is {lic['status']}"}), 403

    now_dt = datetime.datetime.utcnow()
    days = int(lic["duration_days"] or 30)
    max_dev = int(lic["max_devices"] or 1)
    act_at = lic["activated_at"] or now_iso()
    exp_at = lic["expires_at"] or (
        "Lifetime" if days >= 3650 else (now_dt + datetime.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S UTC")
    )

    if exp_at != "Lifetime" and exp_at < now_iso():
        db_exec("UPDATE licenses SET status='Expired' WHERE id=?", (lic["id"],))
        return jsonify({"ok": False, "error": "KEY_EXPIRED", "message": "License Key Expired"}), 403

    act_s = db_exec("SELECT * FROM sessions WHERE license_id=? AND status='Active'", (lic["id"],), fetch=True)
    ex_dev = [s for s in act_s if s["device_info"] == udid]
    if not ex_dev and len(act_s) >= max_dev:
        return jsonify({"ok": False, "error": "HWID_MISMATCH", "message": "Key bound to another device HWID"}), 403

    sid = ex_dev[0]["session_id"] if ex_dev else f"SESS-{secrets.token_hex(4).upper()}"
    db_exec(
        "UPDATE licenses SET activated_at=?, expires_at=?, session_id=?, device_info=? WHERE id=?",
        (act_at, exp_at, sid, udid, lic["id"]),
    )
    db_exec(
        "INSERT OR REPLACE INTO sessions (license_id, license_key, session_id, device_info, created_at, last_active, status) "
        "VALUES (?, ?, ?, ?, ?, ?, 'Active')",
        (lic["id"], k, sid, udid, now_iso(), now_iso()),
    )

    plan_str = "LIFETIME VIP" if days >= 3650 else f"{days} DAYS VIP"
    return jsonify({
        "ok": True,
        "status": "ACTIVE",
        "key": k,
        "plan": plan_str,
        "expires_at": exp_at,
        "device_limit_display": f"{min(len(act_s) + (0 if ex_dev else 1), max_dev)} / {max_dev}",
        "device_slot": "VERIFIED HWID",
        "session_id": sid,
        "seller_id": lic["seller_id"],
    })


# ============================================================================
# Telegram Bot Handler (Owner Panel / Admin Panel / Seller Panel)
# ============================================================================
def tg_api(method: str, payload: dict):
    if not BOT_TOKEN:
        return {}
    try:
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{BOT_TOKEN}/{method}",
            data=body,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as ex:
        print(f"tg_api ({method}) error:", ex)
        return {}


def send_tg(chat_id, text: str, kb=None):
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": True,
    }
    if kb:
        payload["reply_markup"] = {"inline_keyboard": kb}
    tg_api("sendMessage", payload)


def answer_cb(cb_id: str, text: str = ""):
    tg_api("answerCallbackQuery", {"callback_query_id": cb_id, "text": text})


def build_role_keyboard(role: str):
    maint = get_setting("maintenance_mode", "OFF")
    if role == "OWNER":
        return [
            [{"text": "👑 Owner Overview", "callback_data": "panel_owner"}, {"text": "🔑 Generate Keys", "callback_data": "menu_genkey"}],
            [{"text": "👮 Admin Panel", "callback_data": "panel_admin"}, {"text": "💼 Seller Panel", "callback_data": "panel_seller"}],
            [{"text": "➕ Manage Sellers & Credits", "callback_data": "menu_sellers"}, {"text": "🛡 Manage Admins", "callback_data": "menu_admins"}],
            [{"text": "🗂 All License Keys", "callback_data": "menu_keys"}, {"text": "🔄 Reset Key HWID", "callback_data": "menu_resethwid"}],
            [{"text": f"🛠 Maintenance: {maint}", "callback_data": "toggle_maint"}, {"text": "📣 Broadcast", "callback_data": "menu_broadcast"}],
        ]
    if role == "ADMIN":
        return [
            [{"text": "👮 Admin Overview", "callback_data": "panel_admin"}, {"text": "🔑 Generate Keys", "callback_data": "menu_genkey"}],
            [{"text": "💼 Manage Sellers", "callback_data": "menu_sellers"}, {"text": "🗂 Recent Keys", "callback_data": "menu_keys"}],
            [{"text": "🔄 Reset Key HWID", "callback_data": "menu_resethwid"}, {"text": f"🛠 Maintenance: {maint}", "callback_data": "toggle_maint"}],
        ]
    # SELLER
    return [
        [{"text": "💼 Seller Wallet & Stats", "callback_data": "panel_seller"}, {"text": "🔑 Buy / Generate Key", "callback_data": "seller_gen_menu"}],
        [{"text": "🗂 My Generated Keys", "callback_data": "seller_my_keys"}, {"text": "🔄 Reset Customer HWID", "callback_data": "menu_resethwid"}],
        [{"text": "💳 Credit Pricing Table", "callback_data": "seller_pricing"}],
    ]


def status_summary_text(uid, role: str, credits: int) -> str:
    total_l = db_exec("SELECT COUNT(*) AS c FROM licenses", fetch=True)[0]["c"]
    act_l = db_exec("SELECT COUNT(*) AS c FROM licenses WHERE status='Active'", fetch=True)[0]["c"]
    sellers_c = db_exec("SELECT COUNT(*) AS c FROM staff_users WHERE role='SELLER'", fetch=True)[0]["c"]
    admins_c = db_exec("SELECT COUNT(*) AS c FROM staff_users WHERE role='ADMIN'", fetch=True)[0]["c"]
    maint = get_setting("maintenance_mode", "OFF")

    if role == "SELLER":
        my_keys = db_exec("SELECT COUNT(*) AS c FROM licenses WHERE seller_id=?", (str(uid),), fetch=True)[0]["c"]
        return (
            "💼 *FOUGO EXTERNAL — SELLER PANEL*\n\n"
            f"👤 *Seller ID:* `{uid}`\n"
            f"💳 *Available Credits:* `{credits} Cr`\n"
            f"🔑 *Keys Sold by You:* `{my_keys}`\n\n"
            "*Credit Key Pricing:*\n"
            "• `1 Day Key` — `1 Credit`\n"
            "• `7 Days Key` — `3 Credits`\n"
            "• `30 Days Key` — `7 Credits`\n"
            "• `Lifetime Key` — `20 Credits`"
        )

    return (
        f"👑 *FOUGO EXTERNAL — {role} CONTROL PANEL*\n\n"
        f"🔑 *Total Licenses:* `{total_l}` (`{act_l}` Active)\n"
        f"👮 *Authorized Admins:* `{admins_c}`\n"
        f"💼 *Active Sellers:* `{sellers_c}`\n"
        f"🛠 *Maintenance Mode:* `{maint}`\n\n"
        "*Quick Commands:*\n"
        "• `/genkey <days> <qty>` — Generate license keys\n"
        "• `/reset <KEY>` — Reset HWID binding\n"
        "• `/ban <KEY>` | `/unban <KEY>` — Suspend/Activate key\n"
        "• `/addseller <tg_id> <credits>` — Add reseller with credits\n"
        "• `/addcredits <tg_id> <credits>` — Top-up seller credits\n"
        "• `/addadmin <tg_id>` — Promote admin"
    )


def run_bot_polling():
    if not BOT_TOKEN:
        print("No BOT_TOKEN set; running Flask API server only.")
        return

    offset = 0
    print("Starting Telegram Owner / Admin / Seller Bot polling...")
    while True:
        try:
            url = f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates?timeout=25&offset={offset}"
            with urllib.request.urlopen(url, timeout=35) as resp:
                updates = json.loads(resp.read().decode("utf-8")).get("result", [])

            for u in updates:
                offset = u["update_id"] + 1
                if "callback_query" in u:
                    cb = u["callback_query"]
                    cb_id = cb["id"]
                    uid = cb.get("from", {}).get("id")
                    cid = cb.get("message", {}).get("chat", {}).get("id")
                    data = cb.get("data", "")
                    role, credits, st = get_user_role(uid)
                    if not role or st != "Active":
                        answer_cb(cb_id, "Access Denied")
                        continue
                    answer_cb(cb_id)
                    if data in ("panel_owner", "panel_admin", "panel_seller"):
                        send_tg(cid, status_summary_text(uid, role, credits), build_role_keyboard(role))
                    elif data in ("menu_genkey", "seller_gen_menu"):
                        kb = [
                            [{"text": "⚡ 1 Day (1 Cr)", "callback_data": "gen_1_1"}, {"text": "⚡ 7 Days (3 Cr)", "callback_data": "gen_7_1"}],
                            [{"text": "🔥 30 Days (7 Cr)", "callback_data": "gen_30_1"}, {"text": "🔥 5x 30 Days (35 Cr)", "callback_data": "gen_30_5"}],
                            [{"text": "👑 Lifetime (20 Cr)", "callback_data": "gen_3650_1"}],
                            [{"text": "⬅️ Back to Panel", "callback_data": f"panel_{role.lower()}"}],
                        ]
                        send_tg(cid, f"🔑 *GENERATE LICENSE KEYS ({role})*\nSelect duration & package below:", kb)
                    elif data.startswith("gen_"):
                        _, d_s, q_s = data.split("_")
                        keys, exp = generate_license_keys(str(uid), role, int(d_s), int(q_s), 1)
                        if not keys:
                            send_tg(cid, f"⛔ *Error:* {exp}", build_role_keyboard(role))
                        else:
                            _, new_cr, _ = get_user_role(uid)
                            k_list = "\n".join(f"`{k}`" for k in keys)
                            send_tg(
                                cid,
                                f"✅ *Generated {len(keys)} Key(s)*\n"
                                f"⏳ *Duration:* `{d_s} Days` (`{exp}`)\n"
                                f"💳 *Remaining Credits:* `{new_cr} Cr`\n\n{k_list}",
                                build_role_keyboard(role),
                            )
                    elif data == "seller_my_keys":
                        rows = db_exec("SELECT * FROM licenses WHERE seller_id=? ORDER BY id DESC LIMIT 15", (str(uid),), fetch=True)
                        lines = [f"• `{r['key']}` — *{r['status']}* ({r['duration_days']}d)" for r in rows] or ["No keys generated yet."]
                        send_tg(cid, "🗂 *YOUR GENERATED KEYS*\n" + "\n".join(lines), build_role_keyboard(role))
                    elif data == "menu_keys":
                        rows = db_exec("SELECT * FROM licenses ORDER BY id DESC LIMIT 15", fetch=True)
                        lines = [f"• `{r['key']}` — *{r['status']}* ({r['duration_days']}d | By: `{r['seller_id']}`)" for r in rows]
                        send_tg(cid, "🗂 *RECENT LICENSE KEYS*\n" + "\n".join(lines), build_role_keyboard(role))
                    elif data == "menu_sellers":
                        rows = db_exec("SELECT * FROM staff_users WHERE role='SELLER' ORDER BY added_at DESC", fetch=True)
                        lines = [f"• ID: `{r['telegram_id']}` | Credits: `{r['credits']} Cr` | Sold: `{r['total_keys_created']}`" for r in rows] or ["No sellers added yet."]
                        send_tg(
                            cid,
                            "💼 *SELLERS / RESELLERS*\n" + "\n".join(lines) + "\n\n"
                            "Commands:\n"
                            "`/addseller <tg_id> <credits>`\n"
                            "`/addcredits <tg_id> <credits>`",
                            build_role_keyboard(role),
                        )
                    elif data == "menu_admins":
                        rows = db_exec("SELECT * FROM staff_users WHERE role IN ('OWNER','ADMIN')", fetch=True)
                        lines = [f"• ID: `{r['telegram_id']}` — *{r['role']}*" for r in rows]
                        send_tg(
                            cid,
                            "🛡 *OWNER & ADMINS*\n" + "\n".join(lines) + "\n\n"
                            "Commands:\n`/addadmin <tg_id>` | `/deladmin <tg_id>`",
                            build_role_keyboard(role),
                        )
                    elif data == "toggle_maint" and role in ("OWNER", "ADMIN"):
                        cur = get_setting("maintenance_mode", "OFF")
                        nxt = "OFF" if cur == "ON" else "ON"
                        set_setting("maintenance_mode", nxt)
                        send_tg(cid, f"🛠 *Maintenance Mode switched to:* `{nxt}`", build_role_keyboard(role))

                elif "message" in u:
                    msg = u["message"]
                    cid = msg.get("chat", {}).get("id")
                    uid = msg.get("from", {}).get("id")
                    text = (msg.get("text") or "").strip()
                    if not text:
                        continue
                    role, credits, st = get_user_role(uid)
                    if not role or st != "Active":
                        send_tg(cid, f"⛔ *Unauthorized*\nYour Telegram ID (`{uid}`) is not registered in Owner/Admin/Seller system.")
                        continue

                    parts = text.split()
                    cmd = parts[0].lower()
                    if cmd in ("/start", "/panel", "/owner", "/admin", "/seller"):
                        send_tg(cid, status_summary_text(uid, role, credits), build_role_keyboard(role))
                    elif cmd == "/addseller" and role in ("OWNER", "ADMIN") and len(parts) >= 3:
                        sid, cr = parts[1], int(parts[2])
                        db_exec(
                            "INSERT OR REPLACE INTO staff_users (telegram_id, role, credits, status, added_at) VALUES (?, 'SELLER', ?, 'Active', ?)",
                            (sid, cr, now_iso()),
                        )
                        send_tg(cid, f"✅ Seller `{sid}` added with `{cr} Credits`.", build_role_keyboard(role))
                    elif cmd == "/addcredits" and role in ("OWNER", "ADMIN") and len(parts) >= 3:
                        sid, cr = parts[1], int(parts[2])
                        db_exec("UPDATE staff_users SET credits = credits + ? WHERE telegram_id=?", (cr, sid))
                        send_tg(cid, f"✅ Added `{cr} Credits` to Seller `{sid}`.", build_role_keyboard(role))
                    elif cmd == "/addadmin" and role == "OWNER" and len(parts) >= 2:
                        aid = parts[1]
                        db_exec(
                            "INSERT OR REPLACE INTO staff_users (telegram_id, role, credits, status, added_at) VALUES (?, 'ADMIN', 99999, 'Active', ?)",
                            (aid, now_iso()),
                        )
                        send_tg(cid, f"✅ Admin `{aid}` promoted.", build_role_keyboard(role))
                    elif cmd in ("/reset", "/resethwid") and len(parts) >= 2:
                        k = parts[1].strip().upper()
                        lic = db_exec("SELECT * FROM licenses WHERE key=?", (k,), fetch=True)
                        if not lic:
                            send_tg(cid, f"⚠️ Key `{k}` not found.")
                        elif role == "SELLER" and lic[0]["seller_id"] != str(uid):
                            send_tg(cid, "⛔ You can only reset HWID for keys generated by your Seller account.")
                        else:
                            db_exec("UPDATE licenses SET session_id='', device_info='' WHERE key=?", (k,))
                            db_exec("DELETE FROM sessions WHERE license_key=?", (k,))
                            send_tg(cid, f"🔄 HWID & Device Binding reset for `{k}`.", build_role_keyboard(role))
                    elif cmd == "/ban" and role in ("OWNER", "ADMIN") and len(parts) >= 2:
                        k = parts[1].strip().upper()
                        db_exec("UPDATE licenses SET status='Suspended' WHERE key=?", (k,))
                        send_tg(cid, f"🚫 Key `{k}` suspended.", build_role_keyboard(role))
                    elif cmd == "/unban" and role in ("OWNER", "ADMIN") and len(parts) >= 2:
                        k = parts[1].strip().upper()
                        db_exec("UPDATE licenses SET status='Active' WHERE key=?", (k,))
                        send_tg(cid, f"🟢 Key `{k}` re-activated.", build_role_keyboard(role))
        except Exception as ex:
            print("Polling error:", ex)
            time.sleep(3)


if __name__ == "__main__":
    init_db()
    threading.Thread(
        target=lambda: app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5050)), use_reloader=False),
        daemon=True,
    ).start()
    run_bot_polling()
