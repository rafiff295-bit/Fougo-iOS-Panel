#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
#import <math.h>
#import "ProtectedConfig.h"

// ============================================================================
// FOUGO EXTERNAL — Frosted Liquid-Glass License Authentication Login Screen
// ============================================================================

typedef NS_ENUM(NSInteger, FougoLoginVectorKind) {
    FougoLoginVectorKey = 0,
    FougoLoginVectorEyeOpen = 1,
    FougoLoginVectorEyeClosed = 2,
    FougoLoginVectorClipboard = 3,
    FougoLoginVectorShield = 4,
    FougoLoginVectorCheck = 5
};

@interface FougoLoginVectorView : UIView
@property (nonatomic, assign) FougoLoginVectorKind kind;
@property (nonatomic, strong) UIColor *strokeColor;
- (instancetype)initWithFrame:(CGRect)frame kind:(FougoLoginVectorKind)kind;
@end

@implementation FougoLoginVectorView {
    CAShapeLayer *_shapeLayer;
}

- (instancetype)initWithFrame:(CGRect)frame kind:(FougoLoginVectorKind)kind {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        _kind = kind;
        _strokeColor = [UIColor colorWithRed:0.58 green:0.92 blue:1.0 alpha:0.95];

        _shapeLayer = [CAShapeLayer layer];
        _shapeLayer.fillColor = [UIColor clearColor].CGColor;
        _shapeLayer.strokeColor = _strokeColor.CGColor;
        _shapeLayer.lineWidth = 1.75;
        _shapeLayer.lineCap = kCALineCapRound;
        _shapeLayer.lineJoin = kCALineJoinRound;
        [self.layer addSublayer:_shapeLayer];
    }
    return self;
}

- (void)setKind:(FougoLoginVectorKind)kind {
    _kind = kind;
    [self setNeedsLayout];
}

- (void)setStrokeColor:(UIColor *)strokeColor {
    _strokeColor = strokeColor;
    _shapeLayer.strokeColor = strokeColor.CGColor;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _shapeLayer.frame = self.bounds;
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    if (w <= 0 || h <= 0) return;

    UIBezierPath *p = [UIBezierPath bezierPath];
    switch (_kind) {
        case FougoLoginVectorKey: {
            CGPoint c = CGPointMake(w * 0.34, h * 0.50);
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.18 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p moveToPoint:CGPointMake(w * 0.52, h * 0.50)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.50)];
            [p moveToPoint:CGPointMake(w * 0.72, h * 0.50)];
            [p addLineToPoint:CGPointMake(w * 0.72, h * 0.66)];
            [p moveToPoint:CGPointMake(w * 0.84, h * 0.50)];
            [p addLineToPoint:CGPointMake(w * 0.84, h * 0.68)];
            break;
        }
        case FougoLoginVectorEyeOpen: {
            [p moveToPoint:CGPointMake(w * 0.12, h * 0.50)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.88, h * 0.50) controlPoint:CGPointMake(w * 0.50, h * 0.16)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.12, h * 0.50) controlPoint:CGPointMake(w * 0.50, h * 0.84)];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:CGPointMake(w * 0.50, h * 0.50) radius:w * 0.12 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            break;
        }
        case FougoLoginVectorEyeClosed: {
            [p moveToPoint:CGPointMake(w * 0.12, h * 0.50)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.88, h * 0.50) controlPoint:CGPointMake(w * 0.50, h * 0.18)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.12, h * 0.50) controlPoint:CGPointMake(w * 0.50, h * 0.82)];
            [p moveToPoint:CGPointMake(w * 0.18, h * 0.82)];
            [p addLineToPoint:CGPointMake(w * 0.82, h * 0.18)];
            break;
        }
        case FougoLoginVectorClipboard: {
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.22, h * 0.22, w * 0.56, h * 0.64) cornerRadius:w * 0.08]];
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.36, h * 0.14, w * 0.28, h * 0.14) cornerRadius:w * 0.04]];
            break;
        }
        case FougoLoginVectorShield: {
            [p moveToPoint:CGPointMake(w * 0.50, h * 0.14)];
            [p addLineToPoint:CGPointMake(w * 0.82, h * 0.26)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.50, h * 0.88) controlPoint:CGPointMake(w * 0.82, h * 0.68)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.18, h * 0.26) controlPoint:CGPointMake(w * 0.18, h * 0.68)];
            [p closePath];
            break;
        }
        case FougoLoginVectorCheck: {
            [p moveToPoint:CGPointMake(w * 0.22, h * 0.52)];
            [p addLineToPoint:CGPointMake(w * 0.42, h * 0.72)];
            [p addLineToPoint:CGPointMake(w * 0.78, h * 0.28)];
            break;
        }
    }
    _shapeLayer.path = p.CGPath;
}

@end

#pragma mark - Floating Liquid-Glass Status Bar

@interface FougoLiquidGlassBar : UIView
@property (nonatomic, assign) BOOL isLightMode;
@property (nonatomic, strong) UILabel *barHintLabel;
@end

@implementation FougoLiquidGlassBar {
    UIVisualEffectView *_blurView;
    UIView *_glassTintOverlay;
    CAGradientLayer *_topSheen;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        self.clipsToBounds = NO;

        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 12);
        self.layer.shadowRadius = 24.0;
        self.layer.shadowOpacity = 0.48;

        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterialDark];
        _blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
        _blurView.frame = self.bounds;
        _blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _blurView.layer.cornerRadius = 28.0;
        _blurView.layer.masksToBounds = YES;
        _blurView.layer.borderWidth = 1.0;
        _blurView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.22].CGColor;
        [self addSubview:_blurView];

        _glassTintOverlay = [[UIView alloc] initWithFrame:self.bounds];
        _glassTintOverlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _glassTintOverlay.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.04];
        [_blurView.contentView addSubview:_glassTintOverlay];

        _topSheen = [CAGradientLayer layer];
        _topSheen.colors = @[
            (id)[UIColor colorWithWhite:1.0 alpha:0.16].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.02].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor
        ];
        _topSheen.locations = @[@0.0, @0.5, @1.0];
        _topSheen.startPoint = CGPointMake(0.5, 0.0);
        _topSheen.endPoint = CGPointMake(0.5, 1.0);
        [_blurView.contentView.layer addSublayer:_topSheen];

        _barHintLabel = [[UILabel alloc] initWithFrame:self.bounds];
        _barHintLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _barHintLabel.text = @"ENCRYPTED LICENSE GATEWAY • HWID LOCKED";
        _barHintLabel.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightBold];
        _barHintLabel.textAlignment = NSTextAlignmentCenter;
        _barHintLabel.textColor = [UIColor colorWithRed:0.68 green:0.93 blue:1.0 alpha:0.80];
        [_blurView.contentView addSubview:_barHintLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _blurView.layer.cornerRadius = self.bounds.size.height * 0.5;
    _topSheen.frame = self.bounds;
}

- (void)setIsLightMode:(BOOL)isLightMode {
    _isLightMode = isLightMode;
}

@end

#pragma mark - FougoLoginViewController

@interface FougoLoginViewController : UIViewController <UITextFieldDelegate>
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *contentContainer;
@property (nonatomic, strong) UIVisualEffectView *cardGlassView;
@property (nonatomic, strong) UIView *statusPillView;
@property (nonatomic, strong) UILabel *statusPillLabel;
@property (nonatomic, strong) UIView *keyFieldContainer;
@property (nonatomic, strong) FougoLoginVectorView *keyLeadIcon;
@property (nonatomic, strong) UITextField *keyField;
@property (nonatomic, strong) UIButton *visibilityToggleBtn;
@property (nonatomic, strong) FougoLoginVectorView *eyeVectorIcon;
@property (nonatomic, strong) UIButton *pasteKeyBtn;
@property (nonatomic, strong) UIButton *clearKeyBtn;
@property (nonatomic, strong) UIView *hwidInfoRow;
@property (nonatomic, strong) UILabel *hwidValueLabel;
@property (nonatomic, strong) UILabel *inlineErrorLabel;
@property (nonatomic, strong) UIButton *loginButton;
@property (nonatomic, strong) UIActivityIndicatorView *loadingSpinner;
@property (nonatomic, strong) UIView *successGlassBanner;
@property (nonatomic, strong) FougoLiquidGlassBar *liquidBottomBar;
@property (nonatomic, assign) BOOL isVerifying;
@property (nonatomic, assign) BOOL isMasked;
@end

@implementation FougoLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isMasked = NO;
    self.isVerifying = NO;

    [self setupBackgroundSurface];
    [self setupGlassLoginHierarchy];
    [self setupLiquidBottomBar];
    [self registerKeyboardNotifications];
    [self applyAdaptiveAppearance];

    NSString *savedKey = [[NSUserDefaults standardUserDefaults] stringForKey:@"FougoActivatedKey"];
    if ([savedKey isKindOfClass:[NSString class]] && savedKey.length >= 4) {
        self.keyField.text = savedKey;
        [self updateLoginButtonState];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (NSString *)deviceHardwareIdentifier {
    NSString *idfv = [UIDevice currentDevice].identifierForVendor.UUIDString ?: @"IOS-ARM64-DEVICE";
    NSString *clean = [[idfv stringByReplacingOccurrencesOfString:@"-" withString:@""] uppercaseString];
    if (clean.length > 12) {
        clean = [NSString stringWithFormat:@"%@-%@", [clean substringToIndex:6], [clean substringWithRange:NSMakeRange(6, 6)]];
    }
    return [NSString stringWithFormat:@"HWID • %@", clean];
}

- (void)setupBackgroundSurface {
    self.view.backgroundColor = [UIColor colorWithRed:0.02 green:0.04 blue:0.09 alpha:1.0];
    CAGradientLayer *bgGrad = [CAGradientLayer layer];
    bgGrad.frame = [UIScreen mainScreen].bounds;
    bgGrad.name = @"fougo_bg_grad";
    bgGrad.colors = @[
        (id)[UIColor colorWithRed:0.03 green:0.06 blue:0.13 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.05 green:0.10 blue:0.20 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.02 green:0.04 blue:0.08 alpha:1.0].CGColor
    ];
    bgGrad.startPoint = CGPointMake(0.15, 0.0);
    bgGrad.endPoint = CGPointMake(0.85, 1.0);
    [self.view.layer insertSublayer:bgGrad atIndex:0];
}

- (void)setupGlassLoginHierarchy {
    CGRect bounds = self.view.bounds;

    self.scrollView = [[UIScrollView alloc] initWithFrame:bounds];
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    [self.view addSubview:self.scrollView];

    UITapGestureRecognizer *bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleBackgroundTap)];
    bgTap.cancelsTouchesInView = NO;
    [self.scrollView addGestureRecognizer:bgTap];

    self.contentContainer = [[UIView alloc] initWithFrame:bounds];
    [self.scrollView addSubview:self.contentContainer];

    UIBlurEffect *cardBlur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
    self.cardGlassView = [[UIVisualEffectView alloc] initWithEffect:cardBlur];
    self.cardGlassView.layer.cornerRadius = 32.0;
    self.cardGlassView.layer.masksToBounds = YES;
    self.cardGlassView.layer.borderWidth = 1.2;
    self.cardGlassView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.22].CGColor;
    [self.contentContainer addSubview:self.cardGlassView];

    UIView *cardContent = self.cardGlassView.contentView;

    // Top Status Pill
    self.statusPillView = [[UIView alloc] init];
    self.statusPillView.backgroundColor = [UIColor colorWithRed:0.20 green:0.78 blue:0.98 alpha:0.14];
    self.statusPillView.layer.cornerRadius = 12.0;
    self.statusPillView.layer.borderWidth = 1.0;
    self.statusPillView.layer.borderColor = [UIColor colorWithRed:0.45 green:0.90 blue:1.0 alpha:0.40].CGColor;
    [cardContent addSubview:self.statusPillView];

    self.statusPillLabel = [[UILabel alloc] init];
    self.statusPillLabel.text = @"CLOUD AUTHENTICATION ONLINE";
    self.statusPillLabel.font = [UIFont systemFontOfSize:10.0 weight:UIFontWeightBold];
    self.statusPillLabel.textColor = [UIColor colorWithRed:0.62 green:0.93 blue:1.0 alpha:1.0];
    self.statusPillLabel.textAlignment = NSTextAlignmentCenter;
    [self.statusPillView addSubview:self.statusPillLabel];

    UILabel *brandTitle = [[UILabel alloc] init];
    brandTitle.text = @"FOUGO EXTERNAL";
    brandTitle.font = [UIFont systemFontOfSize:26.0 weight:UIFontWeightHeavy];
    brandTitle.textAlignment = NSTextAlignmentCenter;
    brandTitle.textColor = [UIColor whiteColor];
    brandTitle.tag = 102;
    [cardContent addSubview:brandTitle];

    UILabel *subtitleLabel = [[UILabel alloc] init];
    subtitleLabel.text = @"Enter your issued license key to verify device HWID and unlock your workspace.";
    subtitleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightRegular];
    subtitleLabel.textAlignment = NSTextAlignmentCenter;
    subtitleLabel.textColor = [UIColor colorWithWhite:0.76 alpha:0.92];
    subtitleLabel.numberOfLines = 2;
    subtitleLabel.tag = 103;
    [cardContent addSubview:subtitleLabel];

    // License Key Input Box
    self.keyFieldContainer = [[UIView alloc] init];
    self.keyFieldContainer.layer.cornerRadius = 18.0;
    self.keyFieldContainer.layer.borderWidth = 1.25;
    self.keyFieldContainer.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.06];
    self.keyFieldContainer.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
    self.keyFieldContainer.userInteractionEnabled = YES;
    [cardContent addSubview:self.keyFieldContainer];

    UITapGestureRecognizer *fieldBoxTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(focusKeyFieldImmediately)];
    fieldBoxTap.cancelsTouchesInView = NO;
    [self.keyFieldContainer addGestureRecognizer:fieldBoxTap];

    self.keyLeadIcon = [[FougoLoginVectorView alloc] initWithFrame:CGRectMake(14, 16, 24, 24) kind:FougoLoginVectorKey];
    [self.keyFieldContainer addSubview:self.keyLeadIcon];

    self.keyField = [[UITextField alloc] init];
    self.keyField.delegate = self;
    self.keyField.placeholder = @"FOUGO-XXXX-XXXX-XXXX";
    self.keyField.secureTextEntry = NO;
    self.keyField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
    self.keyField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.keyField.spellCheckingType = UITextSpellCheckingTypeNo;
    self.keyField.returnKeyType = UIReturnKeyGo;
    self.keyField.clearButtonMode = UITextFieldViewModeNever;
    self.keyField.textColor = [UIColor whiteColor];
    self.keyField.font = [UIFont monospacedSystemFontOfSize:15.0 weight:UIFontWeightSemibold];
    [self.keyField addTarget:self action:@selector(keyFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self.keyFieldContainer addSubview:self.keyField];

    self.visibilityToggleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.visibilityToggleBtn.accessibilityLabel = @"Toggle license key visibility";
    [self.visibilityToggleBtn addTarget:self action:@selector(toggleKeyMasking:) forControlEvents:UIControlEventTouchUpInside];
    [self.keyFieldContainer addSubview:self.visibilityToggleBtn];

    self.eyeVectorIcon = [[FougoLoginVectorView alloc] initWithFrame:CGRectMake(7, 7, 22, 22) kind:FougoLoginVectorEyeOpen];
    self.eyeVectorIcon.strokeColor = [UIColor colorWithWhite:0.82 alpha:0.85];
    [self.visibilityToggleBtn addSubview:self.eyeVectorIcon];

    // Quick Action Row: PASTE KEY & CLEAR
    self.pasteKeyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.pasteKeyBtn setTitle:@"PASTE CLIPBOARD" forState:UIControlStateNormal];
    [self.pasteKeyBtn setTitleColor:[UIColor colorWithRed:0.58 green:0.92 blue:1.0 alpha:0.95] forState:UIControlStateNormal];
    self.pasteKeyBtn.titleLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightBold];
    self.pasteKeyBtn.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.06];
    self.pasteKeyBtn.layer.cornerRadius = 11.0;
    self.pasteKeyBtn.layer.borderWidth = 1.0;
    self.pasteKeyBtn.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.16].CGColor;
    [self.pasteKeyBtn addTarget:self action:@selector(handlePasteClipboard:) forControlEvents:UIControlEventTouchUpInside];
    [cardContent addSubview:self.pasteKeyBtn];

    self.hwidInfoRow = [[UIView alloc] init];
    self.hwidInfoRow.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.04];
    self.hwidInfoRow.layer.cornerRadius = 11.0;
    self.hwidInfoRow.layer.borderWidth = 1.0;
    self.hwidInfoRow.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.12].CGColor;
    [cardContent addSubview:self.hwidInfoRow];

    self.hwidValueLabel = [[UILabel alloc] init];
    self.hwidValueLabel.text = [self deviceHardwareIdentifier];
    self.hwidValueLabel.font = [UIFont monospacedSystemFontOfSize:10.5 weight:UIFontWeightSemibold];
    self.hwidValueLabel.textColor = [UIColor colorWithWhite:0.75 alpha:0.85];
    self.hwidValueLabel.textAlignment = NSTextAlignmentCenter;
    [self.hwidInfoRow addSubview:self.hwidValueLabel];

    self.inlineErrorLabel = [[UILabel alloc] init];
    self.inlineErrorLabel.text = @"Invalid or Expired License Key";
    self.inlineErrorLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightSemibold];
    self.inlineErrorLabel.textColor = [UIColor colorWithRed:1.0 green:0.38 blue:0.46 alpha:1.0];
    self.inlineErrorLabel.textAlignment = NSTextAlignmentCenter;
    self.inlineErrorLabel.alpha = 0.0;
    [cardContent addSubview:self.inlineErrorLabel];

    self.loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.loginButton setTitle:@"VERIFY & UNLOCK WORKSPACE" forState:UIControlStateNormal];
    self.loginButton.titleLabel.font = [UIFont systemFontOfSize:14.5 weight:UIFontWeightBold];
    self.loginButton.layer.cornerRadius = 18.0;
    self.loginButton.layer.borderWidth = 1.0;
    self.loginButton.layer.borderColor = [UIColor colorWithRed:0.65 green:0.94 blue:1.0 alpha:0.45].CGColor;
    self.loginButton.enabled = NO;
    [self.loginButton addTarget:self action:@selector(handleLoginSubmission:) forControlEvents:UIControlEventTouchUpInside];
    [cardContent addSubview:self.loginButton];

    self.loadingSpinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    self.loadingSpinner.hidesWhenStopped = YES;
    self.loadingSpinner.color = [UIColor whiteColor];
    [self.loginButton addSubview:self.loadingSpinner];

    self.successGlassBanner = [[UIView alloc] init];
    self.successGlassBanner.layer.cornerRadius = 14.0;
    self.successGlassBanner.layer.borderWidth = 1.0;
    self.successGlassBanner.backgroundColor = [UIColor colorWithRed:0.12 green:0.84 blue:0.66 alpha:0.16];
    self.successGlassBanner.layer.borderColor = [UIColor colorWithRed:0.25 green:0.95 blue:0.78 alpha:0.50].CGColor;
    self.successGlassBanner.alpha = 0.0;
    [cardContent addSubview:self.successGlassBanner];

    UILabel *successText = [[UILabel alloc] init];
    successText.text = @"LICENSE VERIFIED • UNLOCKING WORKSPACE";
    successText.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightBold];
    successText.textColor = [UIColor colorWithRed:0.38 green:0.98 blue:0.82 alpha:1.0];
    successText.textAlignment = NSTextAlignmentCenter;
    successText.tag = 301;
    [self.successGlassBanner addSubview:successText];

    [self updateLoginButtonState];
}

- (void)setupLiquidBottomBar {
    self.liquidBottomBar = [[FougoLiquidGlassBar alloc] initWithFrame:CGRectMake(24, self.view.bounds.size.height - 84, self.view.bounds.size.width - 48, 54)];
    self.liquidBottomBar.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [self.view addSubview:self.liquidBottomBar];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect b = self.view.bounds;

    for (CALayer *layer in self.view.layer.sublayers) {
        if ([layer.name isEqualToString:@"fougo_bg_grad"]) {
            layer.frame = b;
        }
    }

    self.contentContainer.frame = b;
    CGFloat cardW = MIN(b.size.width - 36.0, 400.0);
    CGFloat cardH = 392.0;
    CGFloat cardX = (b.size.width - cardW) * 0.5;
    CGFloat cardY = (b.size.height - cardH) * 0.5 - 14.0;
    self.cardGlassView.frame = CGRectMake(cardX, MAX(52.0, cardY), cardW, cardH);

    UIView *cc = self.cardGlassView.contentView;
    CGFloat pillW = MIN(cardW - 64.0, 236.0);
    self.statusPillView.frame = CGRectMake((cardW - pillW) * 0.5, 22, pillW, 24);
    self.statusPillLabel.frame = self.statusPillView.bounds;

    [cc viewWithTag:102].frame = CGRectMake(24, 54, cardW - 48, 32);
    [cc viewWithTag:103].frame = CGRectMake(28, 90, cardW - 56, 36);

    self.keyFieldContainer.frame = CGRectMake(24, 138, cardW - 48, 56);
    CGFloat fW = self.keyFieldContainer.bounds.size.width;
    self.keyLeadIcon.frame = CGRectMake(14, 16, 24, 24);
    self.visibilityToggleBtn.frame = CGRectMake(fW - 44, 10, 36, 36);
    self.eyeVectorIcon.frame = CGRectMake(7, 7, 22, 22);
    self.keyField.frame = CGRectMake(46, 8, fW - 94, 40);

    CGFloat rowW = cardW - 48;
    CGFloat halfW = (rowW - 10.0) * 0.5;
    self.pasteKeyBtn.frame = CGRectMake(24, 204, halfW, 34);
    self.hwidInfoRow.frame = CGRectMake(24 + halfW + 10.0, 204, halfW, 34);
    self.hwidValueLabel.frame = self.hwidInfoRow.bounds;

    self.inlineErrorLabel.frame = CGRectMake(24, 246, cardW - 48, 18);
    self.loginButton.frame = CGRectMake(24, 270, cardW - 48, 54);
    self.loadingSpinner.center = CGPointMake(self.loginButton.bounds.size.width * 0.5, self.loginButton.bounds.size.height * 0.5);

    self.successGlassBanner.frame = CGRectMake(24, 336, cardW - 48, 36);
    [self.successGlassBanner viewWithTag:301].frame = self.successGlassBanner.bounds;

    CGFloat bottomInset = 22.0;
    if (@available(iOS 11.0, *)) {
        bottomInset = MAX(18.0, self.view.safeAreaInsets.bottom + 8.0);
    }
    CGFloat barW = MIN(b.size.width - 36.0, 400.0);
    self.liquidBottomBar.frame = CGRectMake((b.size.width - barW) * 0.5, b.size.height - bottomInset - 54.0, barW, 54.0);
}

- (void)applyAdaptiveAppearance {
    NSAttributedString *attrPlaceholder = [[NSAttributedString alloc] initWithString:@"FOUGO-XXXX-XXXX-XXXX" attributes:@{
        NSForegroundColorAttributeName: [UIColor colorWithWhite:0.62 alpha:0.52],
        NSFontAttributeName: [UIFont monospacedSystemFontOfSize:14.5 weight:UIFontWeightMedium]
    }];
    self.keyField.attributedPlaceholder = attrPlaceholder;
    [self animateKeyFieldFocusState:self.keyField.isFirstResponder];
    [self updateLoginButtonState];
}

#pragma mark - Field Actions & Validation

- (NSString *)cleanKeyString:(NSString *)raw {
    NSMutableCharacterSet *trimSet = [[NSCharacterSet whitespaceAndNewlineCharacterSet] mutableCopy];
    [trimSet addCharactersInString:@"`'\"\u200B\u200C\u200D\uFEFF"];
    return [[raw ?: @"" stringByTrimmingCharactersInSet:trimSet] uppercaseString];
}

- (void)handlePasteClipboard:(UIButton *)sender {
    if (self.isVerifying) return;
    NSString *clip = [UIPasteboard generalPasteboard].string;
    if ([clip isKindOfClass:[NSString class]] && clip.length > 0) {
        self.keyField.text = [self cleanKeyString:clip];
        [self keyFieldDidChange:self.keyField];
    }
}

- (void)focusKeyFieldImmediately {
    if (!self.isVerifying && self.keyField.isEnabled) {
        [self.keyField becomeFirstResponder];
    }
}

- (void)handleBackgroundTap {
    if (!self.isVerifying) {
        [self.view endEditing:YES];
    }
}

- (void)toggleKeyMasking:(UIButton *)sender {
    if (self.isVerifying) return;
    self.isMasked = !self.isMasked;
    BOOL wasFirstResponder = self.keyField.isFirstResponder;
    NSString *currentText = self.keyField.text;
    self.keyField.secureTextEntry = self.isMasked;
    self.keyField.text = currentText;
    self.eyeVectorIcon.kind = self.isMasked ? FougoLoginVectorEyeClosed : FougoLoginVectorEyeOpen;
    if (wasFirstResponder) {
        [self.keyField becomeFirstResponder];
    }
}

- (BOOL)hasAtLeastOneValidKeyCharacter:(NSString *)raw {
    NSString *trimmed = [self cleanKeyString:raw];
    if (trimmed.length < 4) return NO;
    NSCharacterSet *validSet = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"];
    return [trimmed rangeOfCharacterFromSet:validSet].location != NSNotFound;
}

- (void)updateLoginButtonState {
    BOOL canSubmit = !self.isVerifying && [self hasAtLeastOneValidKeyCharacter:self.keyField.text];
    self.loginButton.enabled = canSubmit;

    [UIView animateWithDuration:0.18 animations:^{
        if (self.isVerifying) {
            self.loginButton.backgroundColor = [UIColor colorWithRed:0.12 green:0.62 blue:0.86 alpha:0.55];
            self.loginButton.alpha = 0.88;
        } else if (canSubmit) {
            self.loginButton.backgroundColor = [UIColor colorWithRed:0.14 green:0.74 blue:0.96 alpha:0.95];
            [self.loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            self.loginButton.alpha = 1.0;
        } else {
            self.loginButton.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.08];
            [self.loginButton setTitleColor:[UIColor colorWithWhite:0.65 alpha:0.55] forState:UIControlStateNormal];
            self.loginButton.alpha = 0.78;
        }
    }];
}

- (void)animateKeyFieldFocusState:(BOOL)focused {
    [UIView animateWithDuration:0.20 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        if (focused) {
            self.keyFieldContainer.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.11];
            self.keyFieldContainer.layer.borderColor = [UIColor colorWithRed:0.35 green:0.88 blue:1.0 alpha:0.92].CGColor;
        } else {
            self.keyFieldContainer.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.06];
            self.keyFieldContainer.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
        }
    } completion:nil];
}

- (void)keyFieldDidChange:(UITextField *)sender {
    if (self.inlineErrorLabel.alpha > 0.0) {
        [UIView animateWithDuration:0.15 animations:^{
            self.inlineErrorLabel.alpha = 0.0;
        }];
        [self animateKeyFieldFocusState:self.keyField.isFirstResponder];
    }
    [self updateLoginButtonState];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [self animateKeyFieldFocusState:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [self animateKeyFieldFocusState:NO];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if ([self hasAtLeastOneValidKeyCharacter:textField.text] && !self.isVerifying) {
        [self handleLoginSubmission:self.loginButton];
        return YES;
    }
    return NO;
}

- (void)triggerFieldErrorShakeAndRefocus:(NSString *)errorText {
    self.inlineErrorLabel.text = ([errorText isKindOfClass:[NSString class]] && errorText.length > 0) ? errorText : @"Invalid License Key";
    self.keyFieldContainer.layer.borderColor = [UIColor colorWithRed:1.0 green:0.35 blue:0.45 alpha:0.92].CGColor;
    [UIView animateWithDuration:0.16 animations:^{
        self.inlineErrorLabel.alpha = 1.0;
    }];

    CAKeyframeAnimation *shake = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
    shake.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    shake.duration = 0.36;
    shake.values = @[@(-9.0), @(9.0), @(-7.0), @(7.0), @(-4.0), @(4.0), @(0.0)];
    [self.keyFieldContainer.layer addAnimation:shake forKey:@"fougo_error_shake"];
}

- (void)handleLoginSubmission:(UIButton *)sender {
    if (self.isVerifying) return;

    NSString *trimmedKey = [self cleanKeyString:self.keyField.text];
    if (![self hasAtLeastOneValidKeyCharacter:trimmedKey]) {
        return;
    }

    self.keyField.text = trimmedKey;
    [self.view endEditing:YES];
    self.isVerifying = YES;
    self.keyField.enabled = NO;
    self.visibilityToggleBtn.enabled = NO;
    self.pasteKeyBtn.enabled = NO;
    self.loginButton.enabled = NO;
    self.inlineErrorLabel.alpha = 0.0;

    [self.loginButton setTitle:@"" forState:UIControlStateNormal];
    [self.loadingSpinner startAnimating];
    [self updateLoginButtonState];

    __weak typeof(self) weakSelf = self;
    void (^finishVerification)(BOOL, NSString *) = [^(BOOL isValid, NSString *errMsg) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) return;

            if (isValid) {
                [[NSUserDefaults standardUserDefaults] setObject:trimmedKey forKey:@"FougoActivatedKey"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [strongSelf.loadingSpinner stopAnimating];
                [UIView animateWithDuration:0.22 animations:^{
                    strongSelf.successGlassBanner.alpha = 1.0;
                    strongSelf.keyFieldContainer.layer.borderColor = [UIColor colorWithRed:0.22 green:0.95 blue:0.76 alpha:0.92].CGColor;
                }];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    id appDel = [UIApplication sharedApplication].delegate;
                    SEL goDashSel = NSSelectorFromString(@"goDash");
                    if ([appDel respondsToSelector:goDashSel]) {
                        #pragma clang diagnostic push
                        #pragma clang diagnostic ignored "-Warc-performSelector-leaks"
                        [appDel performSelector:goDashSel];
                        #pragma clang diagnostic pop
                    }
                });
            } else {
                strongSelf.isVerifying = NO;
                strongSelf.keyField.enabled = YES;
                strongSelf.visibilityToggleBtn.enabled = YES;
                strongSelf.pasteKeyBtn.enabled = YES;
                [strongSelf.loadingSpinner stopAnimating];
                [strongSelf.loginButton setTitle:@"VERIFY & UNLOCK WORKSPACE" forState:UIControlStateNormal];
                [strongSelf updateLoginButtonState];
                [strongSelf triggerFieldErrorShakeAndRefocus:([errMsg isKindOfClass:[NSString class]] && errMsg.length > 0 ? errMsg : @"Invalid License Key")];
            }
        });
    } copy];

    id appDel = [UIApplication sharedApplication].delegate;
    SEL verifySel = NSSelectorFromString(@"fougoVerifyKey:completion:");
    if ([appDel respondsToSelector:verifySel]) {
        ((void (*)(id, SEL, NSString *, void (^)(BOOL, NSString *)))[appDel methodForSelector:verifySel])(appDel, verifySel, trimmedKey, finishVerification);
        return;
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.45 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        BOOL passesFormat = (trimmedKey.length >= 8 && [trimmedKey containsString:@"-"]);
        finishVerification(passesFormat, @"Invalid License Key Format");
    });
}

#pragma mark - Keyboard Avoidance

- (void)registerKeyboardNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleKeyboardFrameChange:)
                                                 name:UIKeyboardWillChangeFrameNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleKeyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

- (void)handleKeyboardFrameChange:(NSNotification *)note {
    if (!self.isViewLoaded || !self.view.window) return;
    NSDictionary *info = note.userInfo;
    CGRect endFrame = [info[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGRect localKeyboard = [self.view convertRect:endFrame fromView:nil];
    CGFloat overlap = MAX(0.0, CGRectGetMaxY(self.view.bounds) - CGRectGetMinY(localKeyboard));
    NSTimeInterval dur = [info[UIKeyboardAnimationDurationUserInfoKey] doubleValue] ?: 0.25;

    [UIView animateWithDuration:dur animations:^{
        self.scrollView.contentInset = UIEdgeInsetsMake(0, 0, overlap + 20.0, 0);
        if (overlap > 40.0) {
            CGFloat shiftY = MIN(overlap * 0.42, 95.0);
            self.cardGlassView.transform = CGAffineTransformMakeTranslation(0, -shiftY);
        } else {
            self.cardGlassView.transform = CGAffineTransformIdentity;
        }
    }];
}

- (void)handleKeyboardWillHide:(NSNotification *)note {
    if (!self.isViewLoaded || !self.view.window) return;
    NSTimeInterval dur = [note.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue] ?: 0.25;
    [UIView animateWithDuration:dur animations:^{
        self.scrollView.contentInset = UIEdgeInsetsZero;
        self.cardGlassView.transform = CGAffineTransformIdentity;
    }];
}

@end

@interface FougoLoginAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation FougoLoginAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[FougoLoginViewController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FougoLoginAppDelegate class]));
    }
}
