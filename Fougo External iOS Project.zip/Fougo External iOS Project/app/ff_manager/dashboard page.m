#define FM_OFFLINE_BUILD 1
#import <UIKit/UIKit.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import <Security/Security.h>
#import <CommonCrypto/CommonDigest.h>
#import <mach-o/loader.h>
#import <dlfcn.h>
#import <objc/message.h>
#import <sys/utsname.h>
#import <errno.h>
#import <fcntl.h>
#import <stdbool.h>
#import <stdarg.h>
#import <stdlib.h>
#import <string.h>
#import <unistd.h>
#import "ProtectedConfig.h"#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
#import <math.h>
#import "ProtectedConfig.h"

// ============================================================================
// FOUGO EXTERNAL — Frosted Liquid-Glass Workspace & License Dashboard
// ============================================================================
#ifndef LC_DYLD_EXPORTS_TRIE
#define LC_DYLD_EXPORTS_TRIE (0x33 | LC_REQ_DYLD)
#endif

static NSString *const FFBookmarkKey = @"FMSelectedFolderBookmark";
static NSString *const FFBackupSuffix = @".fmbackup";
static NSString *const FFActiveProfileKey = @"FMActiveProfile";
static NSString *const FFKeychainService = @"com.acidevloper.fougoexternal.protected";
static NSString *const FFDeviceAccount = @"fm-installation-id";
static NSString *const FFLegacyLicenseAccount = @"fm-owner-license";
static NSString *const FFAccessTokenAccount = @"fm-session-access-token";
static NSString *const FFRefreshTokenAccount = @"fm-session-refresh-token";
static NSString *const FFAutoClipboardLicenseDigestKey = @"FMAutoClipboardLicenseDigest";

// The bot generates FOUGO-XXXXX-XXXX-XXXX keys.  A user may copy the
// whole bot message rather than just the code, so extract one bounded key from
// the text.  The raw clipboard contents are never persisted.
static NSString *FFLicenseKeyFromText(NSString *value) {
    if (![value isKindOfClass:NSString.class]) return nil;
    NSString *candidate = [[value stringByTrimmingCharactersInSet:
        NSCharacterSet.whitespaceAndNewlineCharacterSet] uppercaseString];
    if (!candidate.length) return nil;
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:
        @"(?:^|[^A-Z0-9-])((?:FFM|[A-Z0-9]{4,12})(?:-[A-Z0-9]{4,8}){3,5})(?=$|[^A-Z0-9-])"
        options:0 error:nil];
    NSArray<NSTextCheckingResult *> *matches = [expression matchesInString:candidate options:0
        range:NSMakeRange(0, candidate.length)];
    if (matches.count != 1) return nil;
    NSRange keyRange = [matches.firstObject rangeAtIndex:1];
    return keyRange.location == NSNotFound ? nil : [candidate substringWithRange:keyRange];
}

static NSString *FFClipboardLicenseKey(void) {
    return FFLicenseKeyFromText(UIPasteboard.generalPasteboard.string);
}

static NSString *FFActiveProfileDefaultsKey(NSString *gameIdentifier) {
    if (!FFGameDefinition(gameIdentifier)) return nil;
    return [NSString stringWithFormat:@"%@.%@", FFActiveProfileKey, gameIdentifier];
}
static NSString *FFSHA256String(NSString *value) {
    NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    NSMutableString *result = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
    for (NSUInteger i = 0; i < CC_SHA256_DIGEST_LENGTH; i++) [result appendFormat:@"%02x", digest[i]];
    return result;
}

// Network configuration is intentionally absent in this local build.
static NSString *FFAPIBaseURL(void) { return @""; }
static NSString *const FFBundleIDFreeFireTH = @"com.dts.freefireth";
static NSString *const FFBundleIDFreeFireMAX = @"com.dts.freefiremax";
static NSString *const FFHologramShaderFilename = @"shaders.HPt9DZviTSXL9hpGW9QNOMigNLA~3D";
static NSString *const FFThreeDShaderFilename = @"optionalavatarres_commonab_shader";
static NSString *const FFHologramStateKey = @"FMHologramPersistentState";

static NSURL *FFFindGameAssetBundles(NSURL *root, NSError **error);

typedef void (*MCMFilzaStartFunction)(void);
typedef void (*MCMFilzaSetUnrestrictedFilesystemFunction)(BOOL);
typedef NSString *(*MCMFilzaDataContainerPathFunction)(NSString *, NSString **);
typedef NSString *(*MCMFilzaVirtualRootFunction)(void);

#ifdef FM_OFFLINE_BUILD
typedef void *(*FF3105QueryCreateFunction)(void);
typedef void (*FF3105QuerySetClassFunction)(void *, uint64_t);
typedef void (*FF3105QuerySetIdentifiersFunction)(void *, void *);
typedef void (*FF3105QuerySetFlagsFunction)(void *, uint64_t);
typedef void (*FF3105QuerySetPartFunction)(void *, uint64_t);
typedef void *(*FF3105QueryGetResultFunction)(void *);
typedef void *(*FF3105QueryGetErrorFunction)(void *);
typedef void (*FF3105QueryFreeFunction)(void *);
typedef const char *(*FF3105ObjectGetPathFunction)(void *);
typedef void *(*FF3105ObjectCopyFunction)(void *);
typedef char *(*FF3105CopySandboxTokenFunction)(void *);
typedef BOOL (*FF3105ActivateSandboxExtensionFunction)(void *, uint32_t);
typedef void (*FF3105ObjectFreeFunction)(void *);
typedef int (*FF3105ErrorPOSIXFunction)(void *);
typedef const char *(*FF3105ErrorMessageFunction)(void *);
typedef void *(*FF3105XPCStringCreateFunction)(const char *);

typedef struct {
    void *handle;
    FF3105QueryCreateFunction queryCreate;
    FF3105QuerySetClassFunction querySetClass;
    FF3105QuerySetIdentifiersFunction querySetIdentifiers;
    FF3105QuerySetIdentifiersFunction querySetGroupIdentifiers;
    FF3105QuerySetFlagsFunction querySetFlags;
    FF3105QuerySetPartFunction querySetPart;
    FF3105QueryGetResultFunction queryGetSingleResult;
    FF3105QueryGetErrorFunction queryGetLastError;
    FF3105QueryFreeFunction queryFree;
    FF3105ObjectGetPathFunction objectGetPath;
    FF3105ObjectCopyFunction objectCopy;
    FF3105CopySandboxTokenFunction copySandboxToken;
    FF3105ActivateSandboxExtensionFunction activateSandboxExtension;
    FF3105ObjectFreeFunction objectFree;
    FF3105ErrorPOSIXFunction errorPOSIX;
    FF3105ErrorMessageFunction errorMessage;
    FF3105XPCStringCreateFunction xpcStringCreate;
} FF3105MCMAPI;

static FF3105MCMAPI FF3105API;
static NSString *FF3105MCMContainerPath(NSString *identifier, NSString **detail);
#endif

static void *FFProtectedCoreHandle = NULL;
static MCMFilzaStartFunction FFMCMStart = NULL;
static MCMFilzaSetUnrestrictedFilesystemFunction FFMCMSetUnrestrictedFilesystem = NULL;
static MCMFilzaDataContainerPathFunction FFMCMDataContainerPath = NULL;
static MCMFilzaVirtualRootFunction FFMCMVirtualRoot = NULL;

static NSString *ZXDigest(NSData *data);
static BOOL ZXIsSHA256(NSString *value);
static NSDictionary<NSString *, NSString *> *FFGameDefinition(NSString *bundleIdentifier);
typedef NS_ENUM(NSInteger, FougoVectorIconType) {
    FougoVectorIconHome = 0,
    FougoVectorIconGames = 1,
    FougoVectorIconSettings = 2,
    FougoVectorIconCrosshair = 3,
    FougoVectorIconLayers = 4,
    FougoVectorIconChevronRight = 5,
    FougoVectorIconSliders = 6,
    FougoVectorIconShield = 7
};

static NSArray<NSDictionary<NSString *, NSString *> *> *FFSupportedGames(void) {
    static NSArray<NSDictionary<NSString *, NSString *> *> *games;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        games = @[
            @{
                @"id": @"FREE_FIRE_TH",
                @"displayName": @"FREE FIRE TH",
                @"subtitle": @"TH / NORMAL",
                @"bundleIdentifier": FFBundleIDFreeFireTH,
            },
            @{
                @"id": @"FREE_FIRE_MAX",
                @"displayName": @"FREE FIRE MAX",
                @"subtitle": @"MAX",
                @"bundleIdentifier": FFBundleIDFreeFireMAX,
            },
        ];
    });
    return games;
}

static NSDictionary<NSString *, NSString *> *FFGameDefinition(NSString *bundleIdentifier) {
    for (NSDictionary<NSString *, NSString *> *game in FFSupportedGames()) {
        if ([game[@"bundleIdentifier"] isEqualToString:bundleIdentifier]) return game;
    }
    return nil;
}

static NSSet<NSString *> *FFLocalFeaturesForGame(NSString *bundleIdentifier) {
    if ([bundleIdentifier isEqualToString:FFBundleIDFreeFireTH]) {
        // BODY intentionally shares the approved MAX cache payload for TH.
        return [NSSet setWithArray:@[@"BODY", @"NECK"]];
    }
    if ([bundleIdentifier isEqualToString:FFBundleIDFreeFireMAX]) {
        return [NSSet setWithArray:@[@"BODY", @"NECK"]];
    }
    return [NSSet set];
}

#ifdef FM_OFFLINE_BUILD
static NSSet<NSString *> *FFBundledOfflineFeatures(void) {
    // Offline builds always expose the three embedded profiles. Resource
    // existence is validated only when the selected profile is actually read.
    // This prevents signing/repacking tools from making the UI show
    // "NOT IN PLAN" merely because they changed the resource lookup layout.
    static NSSet<NSString *> *features;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        features = [NSSet setWithArray:@[@"BODY", @"NECK"]];
    });
    return features;
}

static NSString *FFOfflineProfilePath(NSString *feature) {
    if (!feature.length) return nil;
    NSBundle *bundle = NSBundle.mainBundle;
    NSFileManager *fm = NSFileManager.defaultManager;
    NSArray<NSString *> *candidates = @[
        [bundle pathForResource:feature ofType:@"robotexternal" inDirectory:@"OfflineCache"] ?: @"",
        [bundle pathForResource:feature ofType:@"robotexternal"] ?: @"",
        [[bundle resourcePath] stringByAppendingPathComponent:
            [NSString stringWithFormat:@"OfflineCache/%@.robotexternal", feature]],
        [[bundle bundlePath] stringByAppendingPathComponent:
            [NSString stringWithFormat:@"OfflineCache/%@.robotexternal", feature]],
        [[bundle bundlePath] stringByAppendingPathComponent:
            [NSString stringWithFormat:@"%@.robotexternal", feature]],
    ];
    for (NSString *candidate in candidates) {
        if (candidate.length && [fm fileExistsAtPath:candidate]) return candidate;
    }
    return nil;
}
#endif

static NSString *ZXWireFeature(NSString *label) {
    static NSDictionary<NSString *, NSString *> *mapping;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        mapping = @{
            @"BODY": @"P1", @"NECK": @"P3"
        };
    });
    return mapping[label.uppercaseString];
}

static NSString *ZXLabelFeature(NSString *wire) {
    static NSDictionary<NSString *, NSString *> *mapping;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        mapping = @{
            @"P1": @"BODY", @"P3": @"NECK"
        };
    });
    return mapping[wire.uppercaseString];
}

static NSString *FFFeatureDisplayName(NSString *feature) {
    if ([feature isEqualToString:@"HOLOGRAM_GUN"]) return @"HOLOGRAM GUN";
    if ([feature isEqualToString:@"THREE_D"]) return @"3D";
    return feature ?: @"FEATURE";
}

static NSString *ZXPlistDigest(NSDictionary *plist, NSArray<NSString *> *keys) {
    if (![plist isKindOfClass:NSDictionary.class]) return nil;
    NSMutableArray<NSString *> *parts = [NSMutableArray arrayWithCapacity:keys.count];
    for (NSString *key in keys) {
        id value = plist[key];
        if (![value isKindOfClass:NSString.class] && ![value isKindOfClass:NSNumber.class]) value = @"";
        [parts addObject:[NSString stringWithFormat:@"%@=%@", key, value]];
    }
    return ZXDigest([[parts componentsJoinedByString:@"|"] dataUsingEncoding:NSUTF8StringEncoding]);
}

static NSError *FFError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"com.acidevloper.robotexternal"
                               code:code
                           userInfo:@{NSLocalizedDescriptionKey: message}];
}

#ifdef FM_OFFLINE_BUILD
static BOOL FF3105MCMInitialize(void) {
    static BOOL available = NO;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        FF3105API.handle = dlopen("/usr/lib/system/libsystem_containermanager.dylib",
                                 RTLD_NOW | RTLD_LOCAL);
        void *lookup = FF3105API.handle ?: RTLD_DEFAULT;
#define FF3105_RESOLVE(field, symbol) FF3105API.field = (typeof(FF3105API.field))dlsym(lookup, symbol)
        FF3105_RESOLVE(queryCreate, "container_query_create");
        FF3105_RESOLVE(querySetClass, "container_query_set_class");
        FF3105_RESOLVE(querySetIdentifiers, "container_query_set_identifiers");
        FF3105_RESOLVE(querySetGroupIdentifiers, "container_query_set_group_identifiers");
        FF3105_RESOLVE(querySetFlags, "container_query_operation_set_flags");
        FF3105_RESOLVE(querySetPart, "container_query_operation_set_part");
        FF3105_RESOLVE(queryGetSingleResult, "container_query_get_single_result");
        FF3105_RESOLVE(queryGetLastError, "container_query_get_last_error");
        FF3105_RESOLVE(queryFree, "container_query_free");
        FF3105_RESOLVE(objectGetPath, "container_object_get_path");
        FF3105_RESOLVE(objectCopy, "container_object_copy");
        FF3105_RESOLVE(copySandboxToken, "container_copy_sandbox_token");
        FF3105_RESOLVE(activateSandboxExtension, "container_object_sandbox_extension_activate");
        FF3105_RESOLVE(objectFree, "container_object_free");
        FF3105_RESOLVE(errorPOSIX, "container_error_get_posix_errno");
        FF3105_RESOLVE(errorMessage, "container_error_get_message");
        FF3105API.xpcStringCreate = (FF3105XPCStringCreateFunction)dlsym(RTLD_DEFAULT, "xpc_string_create");
#undef FF3105_RESOLVE
        available = FF3105API.queryCreate && FF3105API.querySetClass &&
            FF3105API.querySetIdentifiers && FF3105API.querySetFlags &&
            FF3105API.queryGetSingleResult && FF3105API.queryFree &&
            FF3105API.objectGetPath && FF3105API.objectCopy &&
            FF3105API.copySandboxToken && FF3105API.activateSandboxExtension &&
            FF3105API.objectFree && FF3105API.xpcStringCreate;
    });
    return available;
}

static BOOL FF3105SafeIdentifier(NSString *identifier) {
    if (![identifier isKindOfClass:NSString.class] || identifier.length == 0 || identifier.length > 255) return NO;
    static NSCharacterSet *invalid;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *allowed = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_";
        invalid = [[NSCharacterSet characterSetWithCharactersInString:allowed] invertedSet];
    });
    return [identifier rangeOfCharacterFromSet:invalid].location == NSNotFound &&
        ![identifier isEqualToString:@"."] && ![identifier isEqualToString:@".."];
}

static NSString *FF3105LookupFailure(void *query, NSString *fallback) {
    void *containerError = FF3105API.queryGetLastError ? FF3105API.queryGetLastError(query) : NULL;
    int posix = containerError && FF3105API.errorPOSIX ? FF3105API.errorPOSIX(containerError) : 0;
    const char *message = containerError && FF3105API.errorMessage
        ? FF3105API.errorMessage(containerError) : NULL;
    if (message && message[0]) {
        return [NSString stringWithFormat:@"%@ posix=%d message=%s", fallback, posix, message];
    }
    return fallback;
}

@interface FF3105MCMRetainedLease : NSObject {
@public
    void *_query;
    void *_activation;
}
@property(nonatomic, copy) NSString *rootPath;
@property(nonatomic) BOOL activated;
+ (instancetype)leaseForClass:(uint64_t)containerClass
                   identifier:(NSString *)identifier
                        group:(BOOL)group
                       detail:(NSString **)detail;
- (BOOL)activate:(NSString **)detail;
@end

@implementation FF3105MCMRetainedLease
+ (instancetype)leaseForClass:(uint64_t)containerClass
                   identifier:(NSString *)identifier
                        group:(BOOL)group
                       detail:(NSString **)detail {
    if (!FF3105MCMInitialize() || !FF3105SafeIdentifier(identifier)) {
        if (detail) *detail = @"MCM unavailable or identifier contains unsupported characters";
        return nil;
    }
    void *query = FF3105API.queryCreate();
    if (!query) {
        if (detail) *detail = @"query create failed";
        return nil;
    }
    FF3105API.querySetClass(query, containerClass);
    void *xpcIdentifier = FF3105API.xpcStringCreate(identifier.UTF8String);
    if (group && FF3105API.querySetGroupIdentifiers) {
        FF3105API.querySetGroupIdentifiers(query, xpcIdentifier);
    } else {
        FF3105API.querySetIdentifiers(query, xpcIdentifier);
    }
    FF3105API.querySetFlags(query, UINT64_C(0x900000000));
    if (FF3105API.querySetPart) FF3105API.querySetPart(query, 0);

    void *result = FF3105API.queryGetSingleResult(query);
    const char *pathBytes = result ? FF3105API.objectGetPath(result) : NULL;
    NSString *root = pathBytes ? [NSString stringWithUTF8String:pathBytes] : nil;
    if (root.length && ([root isEqualToString:@"/var"] || [root hasPrefix:@"/var/"])) {
        root = [@"/private" stringByAppendingString:root];
    }
    if (!root.length || !root.isAbsolutePath) {
        if (detail) *detail = result
            ? @"MCM returned no absolute container path"
            : FF3105LookupFailure(query, @"MCM lookup failed");
        FF3105API.queryFree(query);
        return nil;
    }
    FF3105MCMRetainedLease *lease = [FF3105MCMRetainedLease new];
    lease->_query = query;
    lease.rootPath = root;
    return lease;
}

- (BOOL)activate:(NSString **)detail {
    if (self.activated) return YES;
    if (!_query) {
        if (detail) *detail = @"lease invalidated";
        return NO;
    }
    void *result = FF3105API.queryGetSingleResult(_query);
    if (result) _activation = FF3105API.objectCopy(result);
    char *token = _activation ? FF3105API.copySandboxToken(_activation) : NULL;
    BOOL hasToken = token && token[0];
    if (token) free(token);
    if (!hasToken) {
        if (detail) *detail = @"MCM object contained no sandbox token";
        return NO;
    }
    self.activated = FF3105API.activateSandboxExtension(_activation, 0);
    if (!self.activated && detail) *detail = @"sandbox extension activation failed";
    return self.activated;
}

- (void)dealloc {
    if (_activation && FF3105API.objectFree) FF3105API.objectFree(_activation);
    if (_query && FF3105API.queryFree) FF3105API.queryFree(_query);
}
@end

static NSString *FF3105MCMContainerPath(NSString *identifier, NSString **detail) {
    if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.mobile.MobileHouseArrest"]) {
        if (detail) *detail = @"host bundle identifier is not com.apple.mobile.MobileHouseArrest";
        return nil;
    }
    static NSMutableDictionary<NSString *, FF3105MCMRetainedLease *> *leases;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ leases = [NSMutableDictionary dictionary]; });
    NSString *key = [NSString stringWithFormat:@"2:0:%@", identifier ?: @""];
    @synchronized (leases) {
        FF3105MCMRetainedLease *lease = leases[key];
        if (lease.rootPath.length) return lease.rootPath;
        lease = [FF3105MCMRetainedLease leaseForClass:2
                                           identifier:identifier
                                                group:NO
                                               detail:detail];
        if (!lease || ![lease activate:detail]) return nil;
        int descriptor = open(lease.rootPath.fileSystemRepresentation,
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (descriptor < 0) {
            if (detail) *detail = [NSString stringWithFormat:@"container root open failed errno=%d", errno];
            return nil;
        }
        close(descriptor);
        leases[key] = lease;
        return lease.rootPath;
    }
}
#endif

#ifdef FM_RELEASE_BUILD
#define FFDiagnosticLog(...) ((void)0)
#else
static void FFDiagnosticLog(NSString *component, NSString *format, ...) NS_FORMAT_FUNCTION(2,3);
#endif
static NSError *FFNamedError(NSInteger code, NSString *name, NSString *detail) {
    NSString *message = detail.length ? [NSString stringWithFormat:@"%@: %@", name, detail] : name;
    FFDiagnosticLog(@"ApplyManager", @"%@", message);
    return FFError(code, message);
}

#ifndef FM_RELEASE_BUILD
static void FFDiagnosticLog(NSString *component, NSString *format, ...) {
    va_list arguments;
    va_start(arguments, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:arguments];
    va_end(arguments);
    NSLog(@"[%@] %@", component ?: @"Compatibility", message ?: @"");
}
#endif

static NSError *FFPOSIXAccessError(NSInteger code, NSString *operation, NSURL *url, int savedErrno) {
    const char *description = strerror(savedErrno);
    NSString *detail = description ? [NSString stringWithUTF8String:description] : @"unknown POSIX error";
    return FFError(code, [NSString stringWithFormat:@"%@ failed for %@ (errno=%d: %@).",
        operation ?: @"Filesystem access", url.path ?: @"selected path", savedErrno, detail]);
}

static NSString *FFKeychainRead(NSString *account) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: FFKeychainService,
        (__bridge id)kSecAttrAccount: account,
        (__bridge id)kSecReturnData: @YES,
        (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne
    };
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || !result) return nil;
    NSData *data = CFBridgingRelease(result);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

static BOOL FFKeychainWrite(NSString *account, NSString *value) {
    NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *identity = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: FFKeychainService,
        (__bridge id)kSecAttrAccount: account
    };
    SecItemDelete((__bridge CFDictionaryRef)identity);
    NSMutableDictionary *item = [identity mutableCopy];
    item[(__bridge id)kSecValueData] = data;
    item[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly;
    return SecItemAdd((__bridge CFDictionaryRef)item, NULL) == errSecSuccess;
}

static void FFKeychainDelete(NSString *account) {
    NSDictionary *identity = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: FFKeychainService,
        (__bridge id)kSecAttrAccount: account
    };
    SecItemDelete((__bridge CFDictionaryRef)identity);
}

static void FFClearSession(void) {
    FFKeychainDelete(FFAccessTokenAccount);
    FFKeychainDelete(FFRefreshTokenAccount);
}

static NSString *ZXInstallID(void) {
    NSString *identifier = FFKeychainRead(FFDeviceAccount);
    if (identifier.length >= 16) return identifier;
    identifier = NSUUID.UUID.UUIDString;
    return FFKeychainWrite(FFDeviceAccount, identifier) ? identifier : nil;
}

static uint32_t FFReadBE32(const uint8_t *bytes) {
    return ((uint32_t)bytes[0] << 24) | ((uint32_t)bytes[1] << 16) |
           ((uint32_t)bytes[2] << 8) | (uint32_t)bytes[3];
}

static uint64_t FFReadBE64(const uint8_t *bytes) {
    return ((uint64_t)FFReadBE32(bytes) << 32) | FFReadBE32(bytes + 4);
}

static BOOL FFRangeFits(uint64_t offset, uint64_t size, uint64_t limit) {
    return offset <= limit && size <= limit - offset;
}

static BOOL ZXVerifySlice(NSData *file, uint64_t sliceOffset, uint64_t sliceSize,
                          NSString **textHash, NSString **exportHash, NSString **sectionHash) {
    if (!FFRangeFits(sliceOffset, sliceSize, file.length) || sliceSize < sizeof(struct mach_header_64)) return NO;
    const uint8_t *slice = (const uint8_t *)file.bytes + sliceOffset;
    struct mach_header_64 header;
    memcpy(&header, slice, sizeof(header));
    if (header.magic != MH_MAGIC_64 || !FFRangeFits(sizeof(header), header.sizeofcmds, sliceSize)) return NO;

    uint64_t textOffset = 0, textSize = 0, exportsOffset = 0, exportsSize = 0;
    uint64_t fallbackExportsOffset = 0, fallbackExportsSize = 0;
    NSMutableData *sectionBytesForHash = sectionHash ? [NSMutableData data] : nil;
    uint64_t cursor = sizeof(header);
    for (uint32_t index = 0; index < header.ncmds; index++) {
        if (!FFRangeFits(cursor, sizeof(struct load_command), sliceSize)) return NO;
        struct load_command command;
        memcpy(&command, slice + cursor, sizeof(command));
        if (command.cmdsize < sizeof(command) || !FFRangeFits(cursor, command.cmdsize, sliceSize)) return NO;

        if (command.cmd == LC_SEGMENT_64 && command.cmdsize >= sizeof(struct segment_command_64)) {
            struct segment_command_64 segment;
            memcpy(&segment, slice + cursor, sizeof(segment));
            uint64_t sectionsSize = (uint64_t)segment.nsects * sizeof(struct section_64);
            if (!FFRangeFits(sizeof(segment), sectionsSize, command.cmdsize)) return NO;
            const uint8_t *sectionBytes = slice + cursor + sizeof(segment);
            for (uint32_t sectionIndex = 0; sectionIndex < segment.nsects; sectionIndex++) {
                struct section_64 section;
                memcpy(&section, sectionBytes + sectionIndex * sizeof(section), sizeof(section));
                if (strncmp(section.segname, "__TEXT", 16) == 0 &&
                    strncmp(section.sectname, "__text", 16) == 0) {
                    textOffset = section.offset;
                    textSize = section.size;
                }
                if (sectionHash && section.offset && section.size &&
                    FFRangeFits(section.offset, section.size, sliceSize)) {
                    [sectionBytesForHash appendBytes:slice + section.offset length:(NSUInteger)section.size];
                }
            }
        } else if (command.cmd == LC_DYLD_EXPORTS_TRIE && command.cmdsize >= sizeof(struct linkedit_data_command)) {
            struct linkedit_data_command exports;
            memcpy(&exports, slice + cursor, sizeof(exports));
            exportsOffset = exports.dataoff;
            exportsSize = exports.datasize;
        } else if (command.cmd == LC_DYLD_INFO_ONLY && command.cmdsize >= sizeof(struct dyld_info_command)) {
            struct dyld_info_command info;
            memcpy(&info, slice + cursor, sizeof(info));
            fallbackExportsOffset = info.export_off;
            fallbackExportsSize = info.export_size;
        }
        cursor += command.cmdsize;
    }

    if (!exportsSize) {
        exportsOffset = fallbackExportsOffset;
        exportsSize = fallbackExportsSize;
    }
    if (!textSize || !exportsSize || !FFRangeFits(textOffset, textSize, sliceSize) ||
        !FFRangeFits(exportsOffset, exportsSize, sliceSize)) return NO;

    *textHash = ZXDigest([file subdataWithRange:NSMakeRange((NSUInteger)(sliceOffset + textOffset), (NSUInteger)textSize)]);
    *exportHash = ZXDigest([file subdataWithRange:NSMakeRange((NSUInteger)(sliceOffset + exportsOffset), (NSUInteger)exportsSize)]);
    if (sectionHash) {
        if (!sectionBytesForHash.length) return NO;
        *sectionHash = ZXDigest(sectionBytesForHash);
    }
    return YES;
}

static BOOL FFApplicationSectionHashes(NSData *file, NSString **textHash, NSString **cstringHash) {
    if (file.length < sizeof(struct mach_header_64)) return NO;
    const uint8_t *bytes = file.bytes;
    struct mach_header_64 header;
    memcpy(&header, bytes, sizeof(header));
    if (header.magic != MH_MAGIC_64 || !FFRangeFits(sizeof(header), header.sizeofcmds, file.length)) return NO;
    uint64_t textOffset = 0, textSize = 0, cstringOffset = 0, cstringSize = 0;
    uint64_t cursor = sizeof(header);
    for (uint32_t index = 0; index < header.ncmds; index++) {
        if (!FFRangeFits(cursor, sizeof(struct load_command), file.length)) return NO;
        struct load_command command;
        memcpy(&command, bytes + cursor, sizeof(command));
        if (command.cmdsize < sizeof(command) || !FFRangeFits(cursor, command.cmdsize, file.length)) return NO;
        if (command.cmd == LC_SEGMENT_64 && command.cmdsize >= sizeof(struct segment_command_64)) {
            struct segment_command_64 segment;
            memcpy(&segment, bytes + cursor, sizeof(segment));
            uint64_t sectionsSize = (uint64_t)segment.nsects * sizeof(struct section_64);
            if (!FFRangeFits(sizeof(segment), sectionsSize, command.cmdsize)) return NO;
            const uint8_t *sections = bytes + cursor + sizeof(segment);
            for (uint32_t sectionIndex = 0; sectionIndex < segment.nsects; sectionIndex++) {
                struct section_64 section;
                memcpy(&section, sections + sectionIndex * sizeof(section), sizeof(section));
                if (strncmp(section.segname, "__TEXT", 16) != 0) continue;
                if (strncmp(section.sectname, "__text", 16) == 0) {
                    textOffset = section.offset;
                    textSize = section.size;
                }
                if (strncmp(section.sectname, "__cstring", 16) == 0) {
                    cstringOffset = section.offset;
                    cstringSize = section.size;
                }
            }
        }
        cursor += command.cmdsize;
    }
    // Final distribution signers may legitimately rewrite non-code metadata
    // sections inside __TEXT.  Pin the executable instructions and constant
    // strings directly; neither is part of the code-signature blob and both
    // must remain byte-for-byte stable after a clean signing operation.
    if (!textSize || !cstringSize ||
        !FFRangeFits(textOffset, textSize, file.length) ||
        !FFRangeFits(cstringOffset, cstringSize, file.length)) return NO;
    *textHash = ZXDigest([file subdataWithRange:NSMakeRange((NSUInteger)textOffset, (NSUInteger)textSize)]);
    *cstringHash = ZXDigest([file subdataWithRange:NSMakeRange((NSUInteger)cstringOffset, (NSUInteger)cstringSize)]);
    return YES;
}

static BOOL FFVerifyCoreBinaryAtPath(NSString *path) {
    NSData *file = [NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:nil];
    if (file.length < 8) return NO;
    const uint8_t *bytes = file.bytes;
    uint32_t magic = FFReadBE32(bytes);
    BOOL fat64 = magic == 0xcafebabf;
    if (magic != 0xcafebabe && !fat64) return NO;
    uint32_t count = FFReadBE32(bytes + 4);
    uint64_t entrySize = fat64 ? 32 : 20;
    if (count != 2 || !FFRangeFits(8, (uint64_t)count * entrySize, file.length)) return NO;

    BOOL foundA = NO, foundB = NO;
    for (uint32_t index = 0; index < count; index++) {
        const uint8_t *entry = bytes + 8 + (uint64_t)index * entrySize;
        uint64_t sliceOffset = fat64 ? FFReadBE64(entry + 8) : FFReadBE32(entry + 8);
        uint64_t sliceSize = fat64 ? FFReadBE64(entry + 16) : FFReadBE32(entry + 12);
        NSString *textHash = nil, *exportHash = nil, *sectionHash = nil;
        if (!ZXVerifySlice(file, sliceOffset, sliceSize, &textHash, &exportHash, &sectionHash)) return NO;
        BOOL matchesA = [textHash isEqualToString:FMCORE_TEXT_SHA256_A] &&
                         [exportHash isEqualToString:FMCORE_EXPORT_SHA256_A] &&
                         [sectionHash isEqualToString:FMCORE_SECTION_SHA256_A];
        BOOL matchesB = [textHash isEqualToString:FMCORE_TEXT_SHA256_B] &&
                         [exportHash isEqualToString:FMCORE_EXPORT_SHA256_B] &&
                         [sectionHash isEqualToString:FMCORE_SECTION_SHA256_B];
        if ((!matchesA && !matchesB) || (matchesA && foundA) || (matchesB && foundB)) return NO;
        foundA |= matchesA;
        foundB |= matchesB;
    }
    return foundA && foundB;
}

static NSDictionary *FFIntegrityReport(void) {
    NSBundle *bundle = NSBundle.mainBundle;
    NSString *corePath = [bundle.privateFrameworksPath stringByAppendingPathComponent:@"CoreTelemetry.framework/CoreTelemetry"];
    if (!FFVerifyCoreBinaryAtPath(corePath)) return nil;
    NSData *coreFile = [NSData dataWithContentsOfFile:corePath options:NSDataReadingMappedIfSafe error:nil];
    if (coreFile.length < 8) return nil;
    const uint8_t *coreBytes = coreFile.bytes;
    uint32_t fatMagic = FFReadBE32(coreBytes);
    BOOL fat64 = fatMagic == 0xcafebabf;
    if ((fatMagic != 0xcafebabe && !fat64) || FFReadBE32(coreBytes + 4) != 2) return nil;
    uint64_t entrySize = fat64 ? 32 : 20;
    NSMutableArray<NSDictionary *> *slices = [NSMutableArray arrayWithCapacity:2];
    for (uint32_t index = 0; index < 2; index++) {
        const uint8_t *entry = coreBytes + 8 + (uint64_t)index * entrySize;
        uint64_t offset = fat64 ? FFReadBE64(entry + 8) : FFReadBE32(entry + 8);
        uint64_t size = fat64 ? FFReadBE64(entry + 16) : FFReadBE32(entry + 12);
        NSString *textHash = nil, *exportHash = nil;
        if (!ZXVerifySlice(coreFile, offset, size, &textHash, &exportHash, nil)) return nil;
        [slices addObject:@{ @"text": textHash, @"exports": exportHash }];
    }

    NSData *appFile = [NSData dataWithContentsOfFile:bundle.executablePath options:NSDataReadingMappedIfSafe error:nil];
    NSString *appText = nil, *appCString = nil;
    if (!appFile.length || !FFApplicationSectionHashes(appFile, &appText, &appCString)) return nil;
    NSString *frameworkInfoPath = [bundle.privateFrameworksPath stringByAppendingPathComponent:@"CoreTelemetry.framework/Info.plist"];
    NSDictionary *info = bundle.infoDictionary;
    NSDictionary *frameworkInfo = [NSDictionary dictionaryWithContentsOfFile:frameworkInfoPath];
    NSString *displayName = info[@"CFBundleDisplayName"] ?: info[@"CFBundleName"];
    NSString *infoHash = ZXPlistDigest(info, @[
        @"CFBundleDisplayName", @"CFBundleExecutable", @"CFBundleIdentifier", @"CFBundleName",
        @"CFBundlePackageType", @"CFBundleShortVersionString", @"CFBundleVersion", @"MinimumOSVersion"
    ]);
    NSString *frameworkInfoHash = ZXPlistDigest(frameworkInfo, @[
        @"CFBundleExecutable", @"CFBundleIdentifier", @"CFBundleName", @"CFBundlePackageType",
        @"CFBundleShortVersionString", @"CFBundleVersion", @"MinimumOSVersion"
    ]);
    if (!infoHash.length || !frameworkInfoHash.length || !bundle.bundleIdentifier.length || !displayName.length) return nil;
    return @{
        @"app_text_sha256": appText,
        @"app_cstring_sha256": appCString,
        @"core_a_text_sha256": slices[0][@"text"],
        @"core_a_export_sha256": slices[0][@"exports"],
        @"core_b_text_sha256": slices[1][@"text"],
        @"core_b_export_sha256": slices[1][@"exports"],
        @"info_plist_sha256": infoHash,
        @"framework_plist_sha256": frameworkInfoHash,
        @"bundle_identifier": bundle.bundleIdentifier,
        @"display_name": displayName,
        @"app_version": info[@"CFBundleShortVersionString"] ?: @"",
        @"build_version": info[@"CFBundleVersion"] ?: @""
    };
}

static BOOL FFLoadSandboxBridge(NSError **error) {
    if (FFProtectedCoreHandle && FFMCMStart && FFMCMDataContainerPath) return YES;
    if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.mobile.MobileHouseArrest"]) {
        if (error) *error = FFError(2, @"This build's required runtime identity is unavailable.");
        return NO;
    }
    NSString *frameworkPath = [NSBundle.mainBundle.privateFrameworksPath stringByAppendingPathComponent:@"CoreTelemetry.framework"];
    NSString *executablePath = [frameworkPath stringByAppendingPathComponent:@"CoreTelemetry"];
    if (!FFVerifyCoreBinaryAtPath(executablePath)) {
        if (error) *error = FFError(3, @"Protected core integrity verification failed.");
        return NO;
    }
    FFProtectedCoreHandle = dlopen(executablePath.fileSystemRepresentation, RTLD_NOW | RTLD_GLOBAL);
    if (!FFProtectedCoreHandle) {
        const char *detail = dlerror();
        if (error) *error = FFError(4, [NSString stringWithFormat:@"Protected core failed to load: %s", detail ?: "unknown"]);
        return NO;
    }
    FFMCMStart = (MCMFilzaStartFunction)dlsym(FFProtectedCoreHandle, "FKX0A7Q2M9Z");
    FFMCMDataContainerPath = (MCMFilzaDataContainerPathFunction)dlsym(FFProtectedCoreHandle, "FKX1R4V8N6P");
    FFMCMSetUnrestrictedFilesystem = (MCMFilzaSetUnrestrictedFilesystemFunction)dlsym(FFProtectedCoreHandle, "FKX2C5J9T3W");
    // FilzaSlop 1.0.3 keeps this read-only helper exported. It exposes only
    // the bridge's own virtual root, which lets us use its iOS 18 fallback
    // links without constructing arbitrary filesystem paths.
    FFMCMVirtualRoot = (MCMFilzaVirtualRootFunction)dlsym(FFProtectedCoreHandle, "FKX3D8H4K7R");
    if (!FFMCMStart || !FFMCMDataContainerPath || !FFMCMSetUnrestrictedFilesystem) {
        if (error) *error = FFError(5, @"Protected core APIs are incomplete.");
        return NO;
    }
    // MCMFilzaStart builds its Device Storage links only once. Set this before
    // starting the bridge so iOS 18 can enumerate the class-2 App Data links
    // instead of pruning them during its first start.
    FFMCMSetUnrestrictedFilesystem(YES);
    FFMCMStart();
    return YES;
}

static NSArray<NSString *> *FFGameContainerCandidates(NSString *selectedGameIdentifier,
                                                       NSString **lookupDetail) {
    NSMutableOrderedSet<NSString *> *paths = [NSMutableOrderedSet orderedSet];
#ifdef FM_OFFLINE_BUILD
    NSString *exact3105Detail = nil;
    NSString *exact3105 = FF3105MCMContainerPath(selectedGameIdentifier, &exact3105Detail);
    if (exact3105.length) [paths addObject:exact3105];
    if (lookupDetail && exact3105Detail.length) *lookupDetail = exact3105Detail;
#endif

    NSError *bridgeError = nil;
    if (FFLoadSandboxBridge(&bridgeError)) {
        NSString *direct = FFMCMDataContainerPath(selectedGameIdentifier, lookupDetail);
        if (direct.length) [paths addObject:direct];
    } else if (lookupDetail && !(*lookupDetail).length) {
        *lookupDetail = bridgeError.localizedDescription;
    }

    // A direct MCM lookup can return no path even when this existing bridge
    // exposes its own virtual root. Probe the exported capability instead of
    // routing by an OS-version number; every candidate is verified later by
    // AccessVerifier before it can become CONNECTED/READY.
    if (FFMCMVirtualRoot) {
        NSString *root = FFMCMVirtualRoot();
        if (root.length && root.isAbsolutePath) {
            // FilzaSlop 1.0.3 creates this class-2 directory when started with
            // unrestricted enumeration. Keep the legacy name as a read-only
            // fallback for devices that already have a pre-migration root.
            for (NSString *directoryName in @[@"[MHA-C2] App Data", @"App Data"]) {
                NSString *appData = [root stringByAppendingPathComponent:directoryName];
                NSString *linked = [appData stringByAppendingPathComponent:selectedGameIdentifier];
                if (linked.length) [paths addObject:linked];
            }
        }
    }
    return paths.array;
}

static NSURL *FFDirectGameContainer(NSString *selectedGameIdentifier,
                                    NSString **gameIdentifier, NSString **gameName,
                                    NSURL **assetBundles, NSError **error) {
    NSDictionary<NSString *, NSString *> *game = FFGameDefinition(selectedGameIdentifier);
    if (!game) {
        if (error) *error = FFError(5, @"Select a supported game first.");
        return nil;
    }
    NSString *lookupDetail = nil;
    NSURL *foundContainer = nil;
    NSError *assetBundleError = nil;
    NSFileManager *manager = NSFileManager.defaultManager;
    for (NSString *containerPath in FFGameContainerCandidates(selectedGameIdentifier, &lookupDetail)) {
        NSURL *container = [NSURL fileURLWithPath:containerPath isDirectory:YES];
        BOOL isDirectory = NO;
        if (![manager fileExistsAtPath:container.path isDirectory:&isDirectory] || !isDirectory) continue;
        if (!foundContainer) foundContainer = container;
        NSError *candidateError = nil;
        NSURL *directory = FFFindGameAssetBundles(container, &candidateError);
        if (directory) {
            if (gameIdentifier) *gameIdentifier = selectedGameIdentifier;
            if (gameName) *gameName = game[@"displayName"];
            if (assetBundles) *assetBundles = directory;
            return container;
        }
        if (!assetBundleError) assetBundleError = candidateError;
    }
    if (foundContainer) {
        // A valid class-2 container proves that the game is installed. The
        // cache may not exist until the game has completed its first launch,
        // so do not report a false "GAME NOT INSTALLED" result on iOS 18.
        if (gameIdentifier) *gameIdentifier = selectedGameIdentifier;
        if (gameName) *gameName = game[@"displayName"];
        if (assetBundles) *assetBundles = nil;
        if (error) *error = assetBundleError ?: FFError(10, @"Game cache is not ready yet.");
        return foundContainer;
    }
    NSString *message = [NSString stringWithFormat:@"%@ is not installed or its container is not available yet.", game[@"displayName"]];
    if (lookupDetail.length) message = [message stringByAppendingFormat:@"\n%@", lookupDetail];
    if (error) *error = FFError(5, message);
    return nil;
}

static NSURL *FFDirectGameAssetBundles(NSString *selectedGameIdentifier,
                                       NSString **gameIdentifier, NSString **gameName, NSError **error) {
    NSURL *directory = nil;
    FFDirectGameContainer(selectedGameIdentifier, gameIdentifier, gameName, &directory, error);
    return directory;
}

static BOOL FFLaunchGame(NSString *gameIdentifier, NSError **error) {
    if (!FFGameDefinition(gameIdentifier)) {
        if (error) *error = FFError(54, @"Select a supported game first.");
        return NO;
    }
    Class workspaceClass = NSClassFromString(@"LSApplicationWorkspace");
    SEL defaultSelector = NSSelectorFromString(@"defaultWorkspace");
    SEL openSelector = NSSelectorFromString(@"openApplicationWithBundleID:");
    if (!workspaceClass || ![workspaceClass respondsToSelector:defaultSelector]) {
        if (error) *error = FFError(54, @"Game launcher is unavailable on this installation.");
        return NO;
    }
    id (*sendWorkspace)(id, SEL) = (void *)objc_msgSend;
    BOOL (*sendOpen)(id, SEL, id) = (void *)objc_msgSend;
    id workspace = sendWorkspace((id)workspaceClass, defaultSelector);
    if (!workspace || ![workspace respondsToSelector:openSelector] ||
        !sendOpen(workspace, openSelector, gameIdentifier)) {
        if (error) *error = FFError(54, @"GAME NOT INSTALLED");
        return NO;
    }
    return YES;
}

static BOOL FFDataLooksLikeUnityBundle(NSData *data) {
    if (data.length < 8) return NO;
    const unsigned char expected[] = {'U','n','i','t','y','F','S',0};
    return memcmp(data.bytes, expected, sizeof(expected)) == 0;
}

static NSString *ZXDigest(NSData *data) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    NSMutableString *hex = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
    for (NSUInteger index = 0; index < CC_SHA256_DIGEST_LENGTH; index++) [hex appendFormat:@"%02x", digest[index]];
    return hex;
}

static NSString *FFHardwareModel(void) {
    struct utsname systemInfo;
    if (uname(&systemInfo) != 0) return @"unknown";
    return [NSString stringWithUTF8String:systemInfo.machine] ?: @"unknown";
}

static NSString *FFAPIErrorMessage(NSDictionary *json, NSString *fallback) {
    id value = [json isKindOfClass:NSDictionary.class] ? json[@"error"] : nil;
    if ([value isKindOfClass:NSString.class] && [value length]) return value;
    if ([value isKindOfClass:NSDictionary.class]) {
        NSString *message = value[@"message"];
        if ([message isKindOfClass:NSString.class] && message.length) return message;
    }
    return fallback;
}

// ---------------------------------------------------------------------------
// Response signing verification (RSA-2048 PSS-SHA256).
//
// The server wraps critical responses as
//   { "data": {...}, "sig_alg": "RSA-PSS-SHA256",
//     "sig_ts": <epoch>, "sig_nonce": <hex>, "sig": <base64> }
// Signing input is exactly "<sig_ts>|<sig_nonce>|<canonical_json(data)>".
//
// Release builds define FM_REQUIRE_SIGNED_RESPONSES and fail closed when a
// successful JSON response is unsigned, stale, malformed, or invalid.
// ---------------------------------------------------------------------------
static NSString *const FFResponseSigningPublicKeyPEM =
    @"-----BEGIN PUBLIC KEY-----\n"
    @"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAv6fKqN4As200Hw23IjN4\n"
    @"IU6+YmnTKgLhxnFDvHcT8yNZEfr6U/p/PHjakdRt388aT/KIrvtPs59sB6yRnt5t\n"
    @"28CXj+FzMGAelu10fWkagiImln4sM/VAAxV+l8KOePMsv77SL0uUbhwM8kLyweEY\n"
    @"JhCVXTS13YUdJWgVAy3B9DX46cc58cdVvMNixpO0h2VkK9HKQTr1RzXM8sQMKWMZ\n"
    @"AFBkt1AzBZZSeHkQbuPu+2vPV7TUBWsgKUhZfrwHFbF3XAzzokAhlje9q2QbarQK\n"
    @"aqKcNCiRG8njxDNUq3BzFk0qIn3vCSDJSWyoQQDYI8SnUbBxBxqYwY0taA1ZmBlK\n"
    @"xwIDAQAB\n"
    @"-----END PUBLIC KEY-----";

static SecKeyRef FFLoadSigningPublicKey(void) {
    static SecKeyRef cached = NULL;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *pem = FFResponseSigningPublicKeyPEM;
        NSMutableString *body = [pem mutableCopy];
        [body replaceOccurrencesOfString:@"-----BEGIN PUBLIC KEY-----" withString:@""
                                 options:0 range:NSMakeRange(0, body.length)];
        [body replaceOccurrencesOfString:@"-----END PUBLIC KEY-----" withString:@""
                                 options:0 range:NSMakeRange(0, body.length)];
        [body replaceOccurrencesOfString:@"\n" withString:@""
                                 options:0 range:NSMakeRange(0, body.length)];
        [body replaceOccurrencesOfString:@"\r" withString:@""
                                 options:0 range:NSMakeRange(0, body.length)];
        [body replaceOccurrencesOfString:@" " withString:@""
                                 options:0 range:NSMakeRange(0, body.length)];
        NSData *spki = [[NSData alloc] initWithBase64EncodedString:body options:0];
        if (spki.length <= 24) return;
        // Strip the fixed 24-byte SubjectPublicKeyInfo header for RSA-2048 so
        // SecKeyCreateWithData sees a raw PKCS#1 RSAPublicKey.
        NSData *pkcs1 = [spki subdataWithRange:NSMakeRange(24, spki.length - 24)];
        NSDictionary *attrs = @{
            (__bridge id)kSecAttrKeyType:  (__bridge id)kSecAttrKeyTypeRSA,
            (__bridge id)kSecAttrKeyClass: (__bridge id)kSecAttrKeyClassPublic,
            (__bridge id)kSecAttrKeySizeInBits: @2048,
        };
        CFErrorRef err = NULL;
        cached = SecKeyCreateWithData((__bridge CFDataRef)pkcs1, (__bridge CFDictionaryRef)attrs, &err);
        if (err) CFRelease(err);
    });
    return cached;
}

static NSDictionary *FFVerifySignedResponse(NSDictionary *envelope, NSError **error) {
    NSString *sigAlg = envelope[@"sig_alg"];
    if (![sigAlg isEqualToString:@"RSA-PSS-SHA256"]) {
        if (error) *error = FFError(60, @"Server signature algorithm is unsupported.");
        return nil;
    }
    NSDictionary *data = envelope[@"data"];
    NSNumber *tsNum   = envelope[@"sig_ts"];
    NSString *nonce   = envelope[@"sig_nonce"];
    NSString *sigB64  = envelope[@"sig"];
    if (![data isKindOfClass:NSDictionary.class] || ![tsNum isKindOfClass:NSNumber.class] ||
        ![nonce isKindOfClass:NSString.class]    || ![sigB64 isKindOfClass:NSString.class]) {
        if (error) *error = FFError(61, @"Server signature envelope is malformed.");
        return nil;
    }
    NSTimeInterval ts  = tsNum.doubleValue;
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    if (fabs(now - ts) > 300.0) {
        if (error) *error = FFError(62, @"Server response is outside the allowed clock window.");
        return nil;
    }
    NSData *canonical = [NSJSONSerialization dataWithJSONObject:data
        options:NSJSONWritingSortedKeys error:nil];
    if (!canonical) {
        if (error) *error = FFError(63, @"Could not canonicalize the server response.");
        return nil;
    }
    NSString *canonicalString = [[NSString alloc] initWithData:canonical encoding:NSUTF8StringEncoding];
    NSString *signingInput = [NSString stringWithFormat:@"%lld|%@|%@",
        (long long)ts, nonce, canonicalString];
    NSData *inputBytes = [signingInput dataUsingEncoding:NSUTF8StringEncoding];
    NSData *sigBytes = [[NSData alloc] initWithBase64EncodedString:sigB64 options:0];
    if (!sigBytes.length || !inputBytes.length) {
        if (error) *error = FFError(64, @"Server signature payload is malformed.");
        return nil;
    }
    SecKeyRef key = FFLoadSigningPublicKey();
    if (!key) {
        if (error) *error = FFError(65, @"Server signing key is unavailable to the app.");
        return nil;
    }
    CFErrorRef verifyErr = NULL;
    Boolean ok = SecKeyVerifySignature(key, kSecKeyAlgorithmRSASignatureMessagePSSSHA256,
                                       (__bridge CFDataRef)inputBytes,
                                       (__bridge CFDataRef)sigBytes, &verifyErr);
    if (verifyErr) CFRelease(verifyErr);
    if (!ok) {
        if (error) *error = FFError(66, @"Server signature verification failed.");
        return nil;
    }
    return data;
}

static void FFJSONRequest(NSString *method, NSString *path, NSDictionary *body, NSString *accessToken,
                          void (^completion)(NSDictionary *json, NSError *error)) {
    NSString *installationID = ZXInstallID();
    if (!installationID.length) {
        completion(nil, FFError(30, @"Installation identity is unavailable."));
        return;
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:
        [NSURL URLWithString:[FFAPIBaseURL() stringByAppendingString:path]]
        cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20.0];
    request.HTTPMethod = method;
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:installationID forHTTPHeaderField:@"X-Installation-ID"];
    if (accessToken.length) {
        [request setValue:[@"Bearer " stringByAppendingString:accessToken] forHTTPHeaderField:@"Authorization"];
    }
    if (body) {
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        request.HTTPBody = [NSJSONSerialization dataWithJSONObject:body options:0 error:nil];
        if (!request.HTTPBody) {
            completion(nil, FFError(31, @"Could not create the secure request."));
            return;
        }
    }
    NSURLSessionDataTask *task = [NSURLSession.sharedSession dataTaskWithRequest:request
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *networkError) {
            if (networkError) {
                completion(nil, FFError(32, @"Activation server is unavailable. Check the internet connection."));
                return;
            }
            NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
            NSDictionary *json = data.length ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            if (http.statusCode < 200 || http.statusCode >= 300) {
                completion(nil, FFError(33, FFAPIErrorMessage(json, @"Server authorization failed.")));
                return;
            }
            if ([json isKindOfClass:NSDictionary.class] && json[@"sig_alg"]) {
                NSError *sigErr = nil;
                NSDictionary *verified = FFVerifySignedResponse(json, &sigErr);
                if (sigErr || !verified) {
                    completion(nil, sigErr ?: FFError(67, @"Server signature verification failed."));
                    return;
                }
                json = verified;
            }
#ifdef FM_REQUIRE_SIGNED_RESPONSES
            else {
                completion(nil, FFError(68, @"Server response is unsigned but signing is required."));
                return;
            }
#endif
            if (![json isKindOfClass:NSDictionary.class] || ![json[@"success"] boolValue]) {
                completion(nil, FFError(34, @"Activation server returned an invalid response."));
                return;
            }
            completion(json, nil);
        }];
    [task resume];
}

static NSArray<NSString *> *FFIntegrityFieldOrder(void) {
    return @[
        @"app_text_sha256", @"app_cstring_sha256",
        @"core_a_text_sha256", @"core_a_export_sha256",
        @"core_b_text_sha256", @"core_b_export_sha256",
        @"info_plist_sha256", @"framework_plist_sha256",
        @"bundle_identifier", @"display_name", @"app_version", @"build_version"
    ];
}

static void ZXProof(NSString *purpose, NSString *context,
                    void (^completion)(NSDictionary *proof, NSError *error)) {
    NSDictionary *integrity = FFIntegrityReport();
    NSString *installationID = ZXInstallID();
    if (!integrity || !installationID.length) {
        completion(nil, FFError(43, @"Application integrity measurement failed."));
        return;
    }
    NSString *safeContext = context ?: @"";
    FFJSONRequest(@"POST", @"/integrity/challenge", @{
        @"installation_id": installationID,
        @"purpose": purpose,
        @"context": safeContext
    }, nil, ^(NSDictionary *json, NSError *error) {
        if (error) {
            completion(nil, error);
            return;
        }
        NSString *challenge = [json[@"challenge"] isKindOfClass:NSString.class] ? json[@"challenge"] : nil;
        if (!challenge.length) {
            completion(nil, FFError(44, @"Security challenge response is invalid."));
            return;
        }
        NSMutableArray<NSString *> *values = [NSMutableArray array];
        for (NSString *field in FFIntegrityFieldOrder()) [values addObject:integrity[field] ?: @""];
        NSString *fingerprint = ZXDigest([[values componentsJoinedByString:@"|"] dataUsingEncoding:NSUTF8StringEncoding]);
        NSString *binding = [NSString stringWithFormat:@"%@|%@|%@|%@|%@",
            challenge, purpose, installationID, safeContext, fingerprint];
        NSString *requestHash = ZXDigest([binding dataUsingEncoding:NSUTF8StringEncoding]);
        completion(@{
            @"challenge": challenge,
            @"request_hash": requestHash,
            @"integrity": integrity
        }, nil);
    });
}

static BOOL ZXPersist(NSDictionary *session) {
    NSString *accessToken = [session[@"access_token"] isKindOfClass:NSString.class] ? session[@"access_token"] : nil;
    NSString *refreshToken = [session[@"refresh_token"] isKindOfClass:NSString.class] ? session[@"refresh_token"] : nil;
    if (![accessToken hasPrefix:@"ffa_"] || ![refreshToken hasPrefix:@"ffr_"]) return NO;
    if (!FFKeychainWrite(FFAccessTokenAccount, accessToken)) return NO;
    if (!FFKeychainWrite(FFRefreshTokenAccount, refreshToken)) {
        FFClearSession();
        return NO;
    }
    return YES;
}

static void FFActivateLicense(NSString *licenseKey, void (^completion)(NSDictionary *response, NSError *error)) {
    NSString *trimmed = [licenseKey stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    NSString *installationID = ZXInstallID();
    if (!trimmed.length || !installationID.length) {
        completion(nil, FFError(35, @"Enter the owner license key."));
        return;
    }
    ZXProof(@"activation", @"", ^(NSDictionary *proof, NSError *proofError) {
        if (proofError) {
            completion(nil, proofError);
            return;
        }
        NSDictionary *payload = @{
            @"license_key": trimmed,
            @"installation_id": installationID,
            @"device_model": FFHardwareModel(),
            @"ios_version": UIDevice.currentDevice.systemVersion ?: @"unknown",
            @"app_version": NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"] ?: @"unknown",
            @"proof": proof
        };
        FFJSONRequest(@"POST", @"/license/activate", payload, nil, completion);
    });
}

static void ZXRenew(void (^completion)(NSDictionary *response, NSError *error)) {
    NSString *refreshToken = FFKeychainRead(FFRefreshTokenAccount);
    NSString *installationID = ZXInstallID();
    if (!refreshToken.length || !installationID.length) {
        completion(nil, FFError(36, @"Session refresh is unavailable. Activate the license again."));
        return;
    }
    ZXProof(@"refresh", @"", ^(NSDictionary *proof, NSError *proofError) {
        if (proofError) {
            completion(nil, proofError);
            return;
        }
        FFJSONRequest(@"POST", @"/session/refresh", @{
            @"refresh_token": refreshToken,
            @"installation_id": installationID,
            @"proof": proof
        }, nil, completion);
    });
}

static void FFValidateSession(NSString *accessToken, void (^completion)(NSDictionary *response, NSError *error)) {
    if (!accessToken.length) {
        completion(nil, FFError(37, @"Session is unavailable."));
        return;
    }
    FFJSONRequest(@"GET", @"/session/validate", nil, accessToken, completion);
}

static void FFLogoutSession(NSString *accessToken, void (^completion)(NSError *error)) {
    if (!accessToken.length) {
        if (completion) completion(nil);
        return;
    }
    FFJSONRequest(@"POST", @"/session/logout", @{}, accessToken,
        ^(NSDictionary *response, NSError *error) {
            (void)response;
            if (completion) completion(error);
        });
}

static void FFFetchServiceStatus(void (^completion)(NSDictionary *response, NSError *error)) {
    FFJSONRequest(@"GET", @"/status", nil, nil, completion);
}

static void FFFetchFeatureCatalog(NSString *gameIdentifier, NSString *accessToken,
                                  void (^completion)(NSSet<NSString *> *planFeatures,
                                                     NSSet<NSString *> *serverFeatures,
                                                     NSError *error)) {
    if (!FFGameDefinition(gameIdentifier) || !accessToken.length) {
        completion(nil, nil, FFError(38, @"A supported game and active session are required."));
        return;
    }
    NSString *escapedGame = [gameIdentifier stringByAddingPercentEncodingWithAllowedCharacters:
        NSCharacterSet.URLQueryAllowedCharacterSet];
    NSString *path = [NSString stringWithFormat:@"/feature/catalog?game=%@", escapedGame ?: @""];
    FFJSONRequest(@"GET", path, nil, accessToken, ^(NSDictionary *json, NSError *error) {
        if (error) {
            completion(nil, nil, error);
            return;
        }
        NSDictionary *game = [json[@"game"] isKindOfClass:NSDictionary.class] ? json[@"game"] : nil;
        NSString *responseGame = [game[@"bundle_identifier"] isKindOfClass:NSString.class]
            ? game[@"bundle_identifier"] : nil;
        NSArray *rows = [game[@"features"] isKindOfClass:NSArray.class] ? game[@"features"] : nil;
        if (![responseGame isEqualToString:gameIdentifier] || !rows) {
            completion(nil, nil, FFError(38, @"Feature catalog response is invalid."));
            return;
        }
        NSMutableSet<NSString *> *plan = [NSMutableSet set];
        NSMutableSet<NSString *> *available = [NSMutableSet set];
        NSSet<NSString *> *local = FFLocalFeaturesForGame(gameIdentifier);
        for (NSDictionary *row in rows) {
            if (![row isKindOfClass:NSDictionary.class]) continue;
            NSString *wire = [row[@"id"] isKindOfClass:NSString.class] ? row[@"id"] : nil;
            NSString *feature = ZXLabelFeature(wire) ?: ([local containsObject:wire] ? wire : nil);
            if (!feature || ![local containsObject:feature]) continue;
            if ([row[@"plan_authorized"] boolValue]) [plan addObject:feature];
            if ([row[@"server_available"] boolValue]) [available addObject:feature];
        }
        completion(plan, available, nil);
    });
}

static BOOL ZXIsSHA256(NSString *value);

static void ZXGrant(NSString *feature, NSString *gameIdentifier, NSString *accessToken,
                    void (^completion)(NSString *featureToken, NSString *profileHash, NSError *error)) {
    NSString *wireFeature = ZXWireFeature(feature);
    if (!wireFeature.length || !FFGameDefinition(gameIdentifier) ||
        ![FFLocalFeaturesForGame(gameIdentifier) containsObject:feature]) {
        completion(nil, nil, FFError(38, @"Option authorization response is invalid."));
        return;
    }
#ifdef FM_OFFLINE_BUILD
    (void)accessToken;
    completion(@"ffg_offline", nil, nil);
    return;
#endif
    NSString *context = [NSString stringWithFormat:@"%@|%@", gameIdentifier, wireFeature];
    ZXProof(@"feature", context, ^(NSDictionary *proof, NSError *proofError) {
        if (proofError) {
            completion(nil, nil, proofError);
            return;
        }
        FFJSONRequest(@"POST", @"/feature/authorize", @{
            @"feature": wireFeature, @"game": gameIdentifier, @"proof": proof
        }, accessToken, ^(NSDictionary *json, NSError *error) {
            if (error) {
                completion(nil, nil, error);
                return;
            }
            NSDictionary *authorization = [json[@"authorization"] isKindOfClass:NSDictionary.class] ? json[@"authorization"] : nil;
            NSString *token = [authorization[@"token"] isKindOfClass:NSString.class] ? authorization[@"token"] : nil;
            NSString *authorizedGame = [authorization[@"game"] isKindOfClass:NSString.class] ? authorization[@"game"] : nil;
            NSString *authorizedFeature = [authorization[@"feature"] isKindOfClass:NSString.class] ? authorization[@"feature"] : nil;
            NSString *profileHash = [authorization[@"profile_sha256"] isKindOfClass:NSString.class]
                ? [authorization[@"profile_sha256"] lowercaseString] : nil;
            if (![token hasPrefix:@"ffg_"] || ![authorizedGame isEqualToString:gameIdentifier] ||
                ![authorizedFeature isEqualToString:wireFeature] || !ZXIsSHA256(profileHash)) {
                completion(nil, nil, FFError(38, @"Feature authorization response is invalid."));
                return;
            }
            completion(token, profileHash, nil);
        });
    });
}

static void ZXFetch(NSString *feature, NSString *gameIdentifier, NSString *color, NSString *expectedHash,
                    NSString *accessToken, NSString *featureToken,
                    void (^completion)(NSData *data, NSError *error)) {
#ifdef FM_OFFLINE_BUILD
    (void)accessToken; (void)featureToken; (void)color; (void)expectedHash;
    if (!FFGameDefinition(gameIdentifier) ||
        ![FFLocalFeaturesForGame(gameIdentifier) containsObject:feature]) {
        completion(nil, FFError(39, @"Feature is not available for the selected game."));
        return;
    }
    // Keep data resources extension-qualified.  ESign and similar tools scan
    // extensionless bundle files as candidate Mach-O executables; naming a
    // UnityFS payload BODY/NECK without an extension makes those signers
    // reject the whole .app before certificate selection.
    NSString *offlinePath = FFOfflineProfilePath(feature);
    NSData *offlineData = offlinePath ? [NSData dataWithContentsOfFile:offlinePath] : nil;
    if (!offlineData.length) {
        completion(nil, FFError(40, @"Offline profile not bundled for this feature."));
        return;
    }
    if (![feature isEqualToString:@"HOLOGRAM_GUN"] && !FFDataLooksLikeUnityBundle(offlineData)) {
        completion(nil, FFError(42, @"Bundled offline profile is not a valid UnityFS cache."));
        return;
    }
    completion(offlineData, nil);
    return;
#endif
    NSString *installationID = ZXInstallID();
    NSString *wireFeature = ZXWireFeature(feature);
    if (!installationID.length || !accessToken.length || !featureToken.length ||
        !FFGameDefinition(gameIdentifier) ||
        ![FFLocalFeaturesForGame(gameIdentifier) containsObject:feature]) {
        completion(nil, FFError(39, @"Feature authorization is required."));
        return;
    }
    if (!wireFeature.length) {
        completion(nil, FFError(39, @"Option authorization is unavailable."));
        return;
    }
    NSString *escapedGame = [gameIdentifier stringByAddingPercentEncodingWithAllowedCharacters:
        NSCharacterSet.URLQueryAllowedCharacterSet];
    NSString *endpoint = [NSString stringWithFormat:@"%@/profile/%@?game=%@",
        FFAPIBaseURL(), wireFeature, escapedGame ?: @""];
    if (color.length) {
        NSString *escapedColor = [color stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
        endpoint = [endpoint stringByAppendingFormat:@"&color=%@", escapedColor ?: @""];
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:endpoint]
        cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20.0];
    [request setValue:[@"Bearer " stringByAppendingString:accessToken] forHTTPHeaderField:@"Authorization"];
    [request setValue:installationID forHTTPHeaderField:@"X-Installation-ID"];
    [request setValue:featureToken forHTTPHeaderField:@"X-Feature-Token"];
    NSURLSessionDataTask *task = [NSURLSession.sharedSession dataTaskWithRequest:request
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *networkError) {
            if (networkError) {
                completion(nil, FFError(40, @"Could not download the selected option."));
                return;
            }
            NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
            if (http.statusCode < 200 || http.statusCode >= 300) {
                NSDictionary *json = data.length ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                completion(nil, FFError(41, FFAPIErrorMessage(json, @"The selected option is unavailable.")));
                return;
            }
            NSString *normalized = feature.uppercaseString;
            NSString *serverHash = [[http valueForHTTPHeaderField:@"X-Profile-SHA256"] lowercaseString];
            NSString *responseGame = [http valueForHTTPHeaderField:@"X-Game-Identifier"];
            // The feature-authorization response is RSA-signed and contains
            // this digest. It is the source of truth for a cache published by
            // the owner bot; raw download headers are only checked to match it.
            NSString *signedHash = expectedHash.lowercaseString;
            NSString *actualHash = [ZXDigest(data) lowercaseString];
            BOOL validFormat = NO;
            if ([@[@"BODY", @"NECK"] containsObject:normalized]) {
                validFormat = data.length >= 40000 && data.length <= (2 * 1024 * 1024) && FFDataLooksLikeUnityBundle(data);
            } else if ([normalized isEqualToString:@"HOLOGRAM_GUN"]) {
                validFormat = data.length > 1000000 && data.length < 30000000 &&
                    memcmp(data.bytes, "FFPKG001", 8) == 0;
            } else if ([normalized isEqualToString:@"THREE_D"]) {
                validFormat = data.length >= 100000 && data.length <= 2000000 &&
                    FFDataLooksLikeUnityBundle(data);
            }
            if (!validFormat || !ZXIsSHA256(serverHash) || !ZXIsSHA256(signedHash) ||
                ![responseGame isEqualToString:gameIdentifier] ||
                ![actualHash isEqualToString:signedHash] ||
                ![serverHash isEqualToString:actualHash]) {
                completion(nil, FFError(42, @"Downloaded option failed integrity validation."));
                return;
            }
            completion(data, nil);
        }];
    [task resume];
}

static BOOL ZXIsSHA256(NSString *value) {
    if (value.length != 64) return NO;
    NSCharacterSet *invalid = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdef"] invertedSet];
    return [[value lowercaseString] rangeOfCharacterFromSet:invalid].location == NSNotFound;
}

static void ZXFeatureColors(NSString *feature, NSString *gameIdentifier, NSString *accessToken,
                            void (^completion)(NSArray<NSDictionary *> *colors, NSError *error)) {
    NSString *installationID = ZXInstallID();
    BOOL hologram = [feature isEqualToString:@"HOLOGRAM_GUN"];
    BOOL threeD = [feature isEqualToString:@"THREE_D"];
    if (!installationID.length || !accessToken.length || (!hologram && !threeD) ||
        (hologram && ![gameIdentifier isEqualToString:FFBundleIDFreeFireTH]) ||
        !FFGameDefinition(gameIdentifier)) {
        completion(nil, FFError(39, @"Feature authorization is required."));
        return;
    }
    NSString *escapedGame = [gameIdentifier stringByAddingPercentEncodingWithAllowedCharacters:
        NSCharacterSet.URLQueryAllowedCharacterSet];
    NSString *route = hologram ? @"hologram" : @"3d";
    NSString *display = hologram ? @"Hologram" : @"3D";
    NSURL *url = [NSURL URLWithString:[FFAPIBaseURL() stringByAppendingFormat:
        @"/%@/colors?game=%@", route, escapedGame ?: @""]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
        cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20.0];
    [request setValue:[@"Bearer " stringByAppendingString:accessToken] forHTTPHeaderField:@"Authorization"];
    [request setValue:installationID forHTTPHeaderField:@"X-Installation-ID"];
    NSURLSessionDataTask *task = [NSURLSession.sharedSession dataTaskWithRequest:request
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *networkError) {
            if (networkError) {
                completion(nil, FFError(40, [NSString stringWithFormat:@"Could not load %@ options.", display]));
                return;
            }
            NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
            NSDictionary *json = data.length ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            if (http.statusCode < 200 || http.statusCode >= 300) {
                completion(nil, FFError(41, FFAPIErrorMessage(json,
                    [NSString stringWithFormat:@"%@ options are unavailable.", display])));
                return;
            }
            NSArray *rows = [json[@"colors"] isKindOfClass:NSArray.class] ? json[@"colors"] : nil;
            NSString *responseGame = [json[@"game"] isKindOfClass:NSString.class] ? json[@"game"] : nil;
            if (![responseGame isEqualToString:gameIdentifier]) {
                completion(nil, FFError(41, [NSString stringWithFormat:@"%@ game validation failed.", display]));
                return;
            }
            NSMutableArray<NSDictionary *> *valid = [NSMutableArray array];
            NSCharacterSet *colorCharacters = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"];
            for (NSDictionary *row in rows) {
                NSString *name = [row[@"name"] isKindOfClass:NSString.class] ? row[@"name"] : nil;
                NSString *label = [row[@"label"] isKindOfClass:NSString.class] ? row[@"label"] : nil;
                NSString *hash = [row[@"sha256"] isKindOfClass:NSString.class] ? row[@"sha256"] : nil;
                if (!name.length || name.length > 48 || [name rangeOfCharacterFromSet:colorCharacters.invertedSet].location != NSNotFound || !ZXIsSHA256(hash)) continue;
                [valid addObject:@{@"name": name, @"label": label.length ? label : name, @"sha256": hash.lowercaseString}];
            }
            if (threeD) {
                NSArray *expected = @[@"BLACK", @"PINK", @"BLUE"];
                NSArray *received = [valid valueForKey:@"name"];
                if (![received isEqualToArray:expected]) {
                    completion(nil, FFNamedError(53, @"ASSET_NOT_FOUND", @"3D catalog must contain exactly Black, Pink, and Blue."));
                    return;
                }
            } else if (!valid.count) {
                completion(nil, FFNamedError(53, @"ASSET_NOT_FOUND", @"No Hologram colors are available."));
                return;
            }
            completion(valid, nil);
        }];
    [task resume];
}

static BOOL FFIsKnownCacheFilename(NSString *name) {
    NSString *lower = name.lowercaseString;
    return [lower isEqualToString:@"cache_res"] ||
        [lower hasPrefix:@"cache_res."] ||
        [lower isEqualToString:@"content_cache_compulsory"] ||
        [lower hasPrefix:@"content_cache_compulsory."];
}

static NSURL *FFFindGameAssetBundles(NSURL *root, NSError **error) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSNumber *isDirectory = nil;
    [root getResourceValue:&isDirectory forKey:NSURLIsDirectoryKey error:nil];
    if (isDirectory.boolValue && [root.lastPathComponent caseInsensitiveCompare:@"gameassetbundles"] == NSOrderedSame) {
        return root;
    }

    NSArray<NSString *> *relativeCandidates = @[
        @"Documents/contentcache/Compulsory/ios/gameassetbundles",
        @"Documents/contentcache/Optional/ios/gameassetbundles",
        @"Documents/contentcache/Optional/ios/GameAssetBundles",
        @"contentcache/Compulsory/ios/gameassetbundles",
        @"contentcache/Optional/ios/gameassetbundles",
        @"contentcache/Optional/ios/GameAssetBundles",
        @"Compulsory/ios/gameassetbundles",
        @"Optional/ios/gameassetbundles",
        @"ios/gameassetbundles",
        @"gameassetbundles"
    ];
    for (NSString *relativePath in relativeCandidates) {
        NSURL *candidate = [root URLByAppendingPathComponent:relativePath isDirectory:YES];
        BOOL directory = NO;
        if ([fm fileExistsAtPath:candidate.path isDirectory:&directory] && directory) return candidate;
    }

    NSMutableOrderedSet<NSURL *> *cacheParents = [NSMutableOrderedSet orderedSet];
    NSDirectoryEnumerator<NSURL *> *enumerator = [fm enumeratorAtURL:root
                                           includingPropertiesForKeys:@[NSURLIsDirectoryKey, NSURLIsRegularFileKey]
                                                              options:NSDirectoryEnumerationSkipsHiddenFiles | NSDirectoryEnumerationSkipsPackageDescendants
                                                         errorHandler:^BOOL(NSURL *url, NSError *enumerationError) {
        (void)url; (void)enumerationError;
        return YES;
    }];
    NSUInteger visited = 0;
    for (NSURL *url in enumerator) {
        if (++visited > 250000) break;
        NSNumber *directory = nil;
        [url getResourceValue:&directory forKey:NSURLIsDirectoryKey error:nil];
        if (directory.boolValue) {
            if ([url.lastPathComponent caseInsensitiveCompare:@"gameassetbundles"] == NSOrderedSame) {
                return url;
            }
            continue;
        }
        NSNumber *regular = nil;
        [url getResourceValue:&regular forKey:NSURLIsRegularFileKey error:nil];
        if (regular.boolValue && FFIsKnownCacheFilename(url.lastPathComponent)) {
            [cacheParents addObject:url.URLByDeletingLastPathComponent];
        }
    }
    if (cacheParents.count == 1) return cacheParents.firstObject;
    if (error) {
        *error = cacheParents.count > 1
            ? FFError(10, [NSString stringWithFormat:
                @"Found %lu possible cache locations in the game container; no unique target was selected.",
                (unsigned long)cacheParents.count])
            : FFError(10, @"No gameassetbundles or cache_res location was found in the game container.");
    }
    return nil;
}

static NSURL *FFTargetFile(NSURL *directory, NSString *gameIdentifier, BOOL allowBackupOnly, NSError **error) {
    NSFileManager *fm = NSFileManager.defaultManager;
    // The two games keep their own data containers, but current Free Fire
    // builds use different cache naming orders. Prefer the known TH bundle
    // name and the MAX base name, then retain the safe recursive discovery
    // for versioned filenames introduced by game updates.
    NSArray<NSString *> *names = [gameIdentifier isEqualToString:FFBundleIDFreeFireTH]
        ? @[@"cache_res.CfnFf59sr1SbsqQ6JqTKsEusjKs~3D", @"cache_res", @"content_cache_compulsory"]
        : @[@"cache_res", @"content_cache_compulsory", @"cache_res.CfnFf59sr1SbsqQ6JqTKsEusjKs~3D"];
    for (NSString *name in names) {
        NSURL *candidate = [directory URLByAppendingPathComponent:name];
        if ([fm fileExistsAtPath:candidate.path]) return candidate;
    }
    if (allowBackupOnly) {
        for (NSString *name in names) {
            NSURL *candidate = [directory URLByAppendingPathComponent:name];
            NSURL *backup = [NSURL fileURLWithPath:[candidate.path stringByAppendingString:FFBackupSuffix]];
            if ([fm fileExistsAtPath:backup.path]) return candidate;
        }
    }

    NSData *cabMarker = [@"CAB-f35e59c15686beb35c2683bdcd5b9393" dataUsingEncoding:NSASCIIStringEncoding];
    NSString *knownCacheName = @"cache_res.CfnFf59sr1SbsqQ6JqTKsEusjKs~3D";
    NSMutableArray<NSURL *> *knownNameMatches = [NSMutableArray array];
    NSMutableArray<NSURL *> *cacheNameMatches = [NSMutableArray array];
    NSMutableArray<NSURL *> *backupMatches = [NSMutableArray array];
    NSMutableArray<NSURL *> *markerMatches = [NSMutableArray array];
    NSMutableArray<NSURL *> *unityCandidates = [NSMutableArray array];
    NSMutableSet<NSString *> *seenPaths = [NSMutableSet set];
    NSArray<NSURLResourceKey> *keys = @[NSURLIsRegularFileKey, NSURLFileSizeKey];
    NSDirectoryEnumerator<NSURL *> *enumerator = [fm enumeratorAtURL:directory
                                           includingPropertiesForKeys:keys
                                                              options:NSDirectoryEnumerationSkipsHiddenFiles | NSDirectoryEnumerationSkipsPackageDescendants
                                                         errorHandler:^BOOL(NSURL *url, NSError *enumerationError) {
        (void)url; (void)enumerationError;
        return YES;
    }];
    NSUInteger visited = 0;
    for (NSURL *url in enumerator) {
        if (++visited > 50000) break;
        NSNumber *regular = nil;
        NSNumber *size = nil;
        [url getResourceValue:&regular forKey:NSURLIsRegularFileKey error:nil];
        [url getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
        if (!regular.boolValue || size.unsignedLongLongValue < 40000 || size.unsignedLongLongValue > 150000) continue;

        BOOL isBackup = [url.path hasSuffix:FFBackupSuffix];
        NSURL *liveURL = isBackup ? [NSURL fileURLWithPath:[url.path substringToIndex:url.path.length - FFBackupSuffix.length]] : url;
        if (isBackup && !allowBackupOnly && ![fm fileExistsAtPath:liveURL.path]) continue;
        NSData *data = [NSData dataWithContentsOfURL:url options:NSDataReadingMappedIfSafe error:nil];
        if (!FFDataLooksLikeUnityBundle(data)) continue;
        if (![seenPaths containsObject:liveURL.path]) {
            [seenPaths addObject:liveURL.path];
            [unityCandidates addObject:liveURL];
        }
        NSString *liveName = liveURL.lastPathComponent;
        NSString *lowerName = liveName.lowercaseString;
        if ([liveName caseInsensitiveCompare:knownCacheName] == NSOrderedSame && ![knownNameMatches containsObject:liveURL]) {
            [knownNameMatches addObject:liveURL];
        }
        BOOL cacheNameMatch = [lowerName isEqualToString:@"cache_res"] ||
            [lowerName hasPrefix:@"cache_res."] ||
            [lowerName isEqualToString:@"content_cache_compulsory"] ||
            [lowerName hasPrefix:@"content_cache_compulsory."];
        if (cacheNameMatch && ![cacheNameMatches containsObject:liveURL]) [cacheNameMatches addObject:liveURL];
        if (isBackup && ![backupMatches containsObject:liveURL]) [backupMatches addObject:liveURL];
        BOOL markerMatch = [data rangeOfData:cabMarker options:0 range:NSMakeRange(0, data.length)].location != NSNotFound;
        if (markerMatch && ![markerMatches containsObject:liveURL]) [markerMatches addObject:liveURL];
    }

    if (backupMatches.count == 1) return backupMatches.firstObject;
    if (knownNameMatches.count == 1) return knownNameMatches.firstObject;
    if (cacheNameMatches.count == 1) return cacheNameMatches.firstObject;
    if (markerMatches.count == 1) return markerMatches.firstObject;
    if (knownNameMatches.count > 1 || cacheNameMatches.count > 1) {
        NSUInteger count = knownNameMatches.count > 1 ? knownNameMatches.count : cacheNameMatches.count;
        if (error) *error = FFError(11, [NSString stringWithFormat:@"Found %lu files named cache_res. Update Free Fire once, then retry.", (unsigned long)count]);
        return nil;
    }
    if (unityCandidates.count == 1) return unityCandidates.firstObject;
    if (error) {
        NSString *message = unityCandidates.count == 0
            ? @"No matching UnityFS cache bundle was found recursively under gameassetbundles."
            : [NSString stringWithFormat:@"Found %lu UnityFS bundles, but the expected cache_res file name was not present.", (unsigned long)unityCandidates.count];
        *error = FFError(11, message);
    }
    return nil;
}

typedef NS_ENUM(NSInteger, FFAccessMethod) {
    FFAccessMethodNone = 0,
    FFAccessMethodDirect,
    FFAccessMethodAuthorizedFolder,
};

static NSString *FFAccessMethodName(FFAccessMethod method) {
    switch (method) {
        case FFAccessMethodDirect:
#ifdef FM_OFFLINE_BUILD
            return @"3105 MCM DirectAccess";
#else
            return @"DirectAccess";
#endif
        case FFAccessMethodAuthorizedFolder: return @"AuthorizedFolderAccess";
        default: return @"NONE";
    }
}

@interface FFAccessContext : NSObject
@property(nonatomic) FFAccessMethod method;
@property(nonatomic, copy) NSString *gameIdentifier;
@property(nonatomic, strong) NSURL *rootURL;
@property(nonatomic, strong) NSURL *assetBundlesURL;
@property(nonatomic, strong) NSURL *targetURL;
@property(nonatomic, copy) NSString *activeFeature;
@property(nonatomic, strong) NSError *error;
@property(nonatomic, copy) NSString *fallbackReason;
@property(nonatomic) BOOL discovered;
@property(nonatomic) BOOL opened;
@property(nonatomic) BOOL readVerified;
@property(nonatomic) BOOL writeVerified;
@property(nonatomic) BOOL usable;
@property(nonatomic) BOOL needsFolderSelection;
@end

@implementation FFAccessContext
@end

static NSString *FFActiveFeatureAtTarget(NSURL *target, NSString *gameIdentifier) {
    NSData *current = [NSData dataWithContentsOfURL:target options:NSDataReadingMappedIfSafe error:nil];
    if (!current) return @"UNKNOWN";
    NSURL *backup = [NSURL fileURLWithPath:[target.path stringByAppendingString:FFBackupSuffix]];
    NSData *original = [NSData dataWithContentsOfURL:backup options:NSDataReadingMappedIfSafe error:nil];
    if (original && [current isEqualToData:original]) return @"ORIGINAL";
    NSString *key = FFActiveProfileDefaultsKey(gameIdentifier);
    NSString *saved = key ? [NSUserDefaults.standardUserDefaults stringForKey:key] : nil;
    return saved.length ? saved : @"CUSTOM / ORIGINAL";
}

@interface FFGameDetector : NSObject
+ (FFAccessContext *)detectDirectContainerForGame:(NSString *)gameIdentifier;
@end

@implementation FFGameDetector
+ (FFAccessContext *)detectDirectContainerForGame:(NSString *)gameIdentifier {
    FFAccessContext *context = [FFAccessContext new];
    context.method = FFAccessMethodDirect;
    context.gameIdentifier = gameIdentifier;
    FFDiagnosticLog(@"GameDetector", @"Bundle: %@", gameIdentifier ?: @"NONE");

    NSError *error = nil;
    NSString *detectedIdentifier = nil;
    NSURL *assetBundles = nil;
    NSURL *container = FFDirectGameContainer(gameIdentifier, &detectedIdentifier, nil,
        &assetBundles, &error);
    context.rootURL = container;
    context.assetBundlesURL = assetBundles;
    context.discovered = container != nil && [detectedIdentifier isEqualToString:gameIdentifier];
    context.error = error;
    FFDiagnosticLog(@"DirectAccess", @"Discovery: %@%@", context.discovered ? @"SUCCESS" : @"FAILED",
        container.path.length ? [NSString stringWithFormat:@" (%@)", container.path] : @"");
    if (error) FFDiagnosticLog(@"DirectAccess", @"Discovery detail: %@", error.localizedDescription);
    return context;
}
@end

@interface FFAccessVerifier : NSObject
+ (FFAccessContext *)verifyContext:(FFAccessContext *)context
                     requiresWrite:(BOOL)requiresWrite
                   allowBackupOnly:(BOOL)allowBackupOnly;
@end

@implementation FFAccessVerifier
+ (FFAccessContext *)verifyContext:(FFAccessContext *)context
                     requiresWrite:(BOOL)requiresWrite
                   allowBackupOnly:(BOOL)allowBackupOnly {
    NSString *component = FFAccessMethodName(context.method);
    NSFileManager *manager = NSFileManager.defaultManager;
    BOOL isDirectory = NO;
    if (!context.discovered || !context.rootURL ||
        ![manager fileExistsAtPath:context.rootURL.path isDirectory:&isDirectory] || !isDirectory) {
        context.error = context.error ?: FFNamedError(60, @"CONTAINER_NOT_FOUND", @"Game detector did not produce an existing directory.");
        FFDiagnosticLog(component, @"Open: FAILED (%@)", context.error.localizedDescription);
        return context;
    }

    errno = 0;
    int rootDescriptor = open(context.rootURL.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (rootDescriptor < 0) {
        NSError *posix = FFPOSIXAccessError(61, @"Container root open", context.rootURL, errno);
        context.error = FFNamedError(61, @"CONTAINER_FOUND_ACCESS_DENIED", posix.localizedDescription);
        FFDiagnosticLog(component, @"Open: FAILED (%@)", context.error.localizedDescription);
        return context;
    }
    close(rootDescriptor);
    context.opened = YES;
    FFDiagnosticLog(component, @"Open: SUCCESS");

    NSError *lookupError = nil;
    NSURL *assetBundles = context.assetBundlesURL ?: FFFindGameAssetBundles(context.rootURL, &lookupError);
    NSURL *target = assetBundles
        ? FFTargetFile(assetBundles, context.gameIdentifier, allowBackupOnly, &lookupError) : nil;
    if (!assetBundles || !target) {
        context.error = FFNamedError(62, @"ASSET_NOT_FOUND",
            lookupError.localizedDescription ?: @"Required game files were not found.");
        FFDiagnosticLog(@"AccessVerifier", @"Read: FAILED (%@)", context.error.localizedDescription);
        return context;
    }
    context.assetBundlesURL = assetBundles;
    context.targetURL = target;

    NSURL *readURL = target;
    if (allowBackupOnly && ![manager fileExistsAtPath:target.path]) {
        readURL = [NSURL fileURLWithPath:[target.path stringByAppendingString:FFBackupSuffix]];
    }
    errno = 0;
    int targetDescriptor = open(readURL.fileSystemRepresentation, O_RDONLY | O_CLOEXEC);
    if (targetDescriptor < 0) {
        NSError *posix = FFPOSIXAccessError(63, @"Required game file read", readURL, errno);
        context.error = FFNamedError(63, @"READ_FAILED", posix.localizedDescription);
        FFDiagnosticLog(@"AccessVerifier", @"Read: FAILED (%@)", context.error.localizedDescription);
        return context;
    }
    unsigned char header[8] = {0};
    ssize_t bytesRead = read(targetDescriptor, header, sizeof(header));
    int readErrno = errno;
    close(targetDescriptor);
    const unsigned char unityHeader[] = {'U','n','i','t','y','F','S',0};
    if (bytesRead != (ssize_t)sizeof(header) || memcmp(header, unityHeader, sizeof(unityHeader)) != 0) {
        NSError *readFailure = bytesRead < 0
            ? FFPOSIXAccessError(63, @"Required game file read", readURL, readErrno)
            : FFError(63, @"Required game file is readable but does not have the expected UnityFS header.");
        context.error = FFNamedError(63, @"READ_FAILED", readFailure.localizedDescription);
        FFDiagnosticLog(@"AccessVerifier", @"Read: FAILED (%@)", context.error.localizedDescription);
        return context;
    }
    context.readVerified = YES;
    FFDiagnosticLog(@"AccessVerifier", @"Read: SUCCESS");

    if (requiresWrite) {
        if ([manager fileExistsAtPath:target.path]) {
            errno = 0;
            int writableTarget = open(target.fileSystemRepresentation, O_WRONLY | O_CLOEXEC);
            if (writableTarget < 0) {
                NSError *posix = FFPOSIXAccessError(64, @"Required destination write open", target, errno);
                context.error = FFNamedError(64, @"WRITE_FAILED", posix.localizedDescription);
                FFDiagnosticLog(@"AccessVerifier", @"Write: FAILED (%@)", context.error.localizedDescription);
                return context;
            }
            close(writableTarget);
        }
        NSURL *destination = target.URLByDeletingLastPathComponent;
        NSFileCoordinator *coordinator = [[NSFileCoordinator alloc] initWithFilePresenter:nil];
        __block NSError *probeError = nil;
        __block BOOL probeSucceeded = NO;
        NSError *coordinationError = nil;
        [coordinator coordinateWritingItemAtURL:destination
                                        options:NSFileCoordinatorWritingForMerging
                                          error:&coordinationError
                                     byAccessor:^(NSURL *coordinatedDestination) {
            NSString *probeName = [NSString stringWithFormat:@".ffaccess-%@.tmp", NSUUID.UUID.UUIDString];
            NSURL *probeURL = [coordinatedDestination URLByAppendingPathComponent:probeName];
            errno = 0;
            int descriptor = open(probeURL.fileSystemRepresentation,
                O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
            if (descriptor < 0) {
                probeError = FFPOSIXAccessError(64, @"Destination write probe open", probeURL, errno);
                return;
            }
            const unsigned char probe[] = {'F','F','A','C','C','E','S','S'};
            ssize_t written = write(descriptor, probe, sizeof(probe));
            int savedErrno = errno;
            close(descriptor);
            if (written != (ssize_t)sizeof(probe)) {
                unlink(probeURL.fileSystemRepresentation);
                probeError = FFPOSIXAccessError(64, @"Destination write probe", probeURL,
                    written < 0 ? savedErrno : EIO);
                return;
            }
            if (unlink(probeURL.fileSystemRepresentation) != 0) {
                probeError = FFPOSIXAccessError(64, @"Destination write probe cleanup", probeURL, errno);
                return;
            }
            probeSucceeded = YES;
        }];
        if (!probeError && coordinationError) probeError = coordinationError;
        if (!probeSucceeded || probeError) {
            context.error = FFNamedError(64, @"WRITE_FAILED",
                probeError.localizedDescription ?: @"Destination write verification failed.");
            FFDiagnosticLog(@"AccessVerifier", @"Write: FAILED (%@)", context.error.localizedDescription);
            return context;
        }
        context.writeVerified = YES;
        FFDiagnosticLog(@"AccessVerifier", @"Write: SUCCESS");
    } else {
        context.writeVerified = YES;
        FFDiagnosticLog(@"AccessVerifier", @"Write: SKIPPED (read-only operation)");
    }

    context.error = nil;
    context.usable = context.opened && context.readVerified && context.writeVerified;
    if (context.usable) {
        context.activeFeature = FFActiveFeatureAtTarget(context.targetURL, context.gameIdentifier);
    }
    return context;
}
@end

@interface FFAccessManager : NSObject
+ (BOOL)storeBookmarkForAuthorizedURL:(NSURL *)url error:(NSError **)error;
+ (NSURL *)beginBookmarkedFolderAccessWithStale:(BOOL *)stale error:(NSError **)error;
+ (void)endBookmarkedFolderAccess:(NSURL *)url;
+ (void)invalidateStoredBookmark:(NSString *)reason;
@end

@implementation FFAccessManager
+ (BOOL)storeBookmarkForAuthorizedURL:(NSURL *)url error:(NSError **)error {
    NSData *bookmark = [url bookmarkDataWithOptions:0
                         includingResourceValuesForKeys:nil relativeToURL:nil error:error];
    if (!bookmark) {
        NSString *detail = (error && *error) ? (*error).localizedDescription : @"creation failed";
        FFDiagnosticLog(@"Bookmark", @"Stored: NO (%@)", detail);
        return NO;
    }
    [NSUserDefaults.standardUserDefaults setObject:bookmark forKey:FFBookmarkKey];
    FFDiagnosticLog(@"Bookmark", @"Stored: YES");
    return YES;
}

+ (NSURL *)beginBookmarkedFolderAccessWithStale:(BOOL *)stale error:(NSError **)error {
    NSData *bookmark = [NSUserDefaults.standardUserDefaults dataForKey:FFBookmarkKey];
    if (!bookmark) {
        if (error) *error = FFError(65, @"No authorized game folder is stored.");
        FFDiagnosticLog(@"Bookmark", @"Restored: NO (missing)");
        return nil;
    }
    BOOL bookmarkStale = NO;
    NSURL *url = [NSURL URLByResolvingBookmarkData:bookmark options:0 relativeToURL:nil
                            bookmarkDataIsStale:&bookmarkStale error:error];
    FFDiagnosticLog(@"Bookmark", @"Restored: %@", url ? @"YES" : @"NO");
    FFDiagnosticLog(@"Bookmark", @"Stale: %@", bookmarkStale ? @"YES" : @"NO");
    if (!url) return nil;

    BOOL accessed = [url startAccessingSecurityScopedResource];
    FFDiagnosticLog(@"AuthorizedFolderAccess", @"Security-scoped resource: %@", accessed ? @"STARTED" : @"FAILED");
    if (!accessed) {
        if (error) *error = FFError(66, @"Folder authorization expired. Select the game folder again.");
        return nil;
    }
    if (bookmarkStale) {
        NSError *renewError = nil;
        if (![self storeBookmarkForAuthorizedURL:url error:&renewError]) {
            [url stopAccessingSecurityScopedResource];
            if (error) *error = renewError ?: FFError(66, @"The stale folder bookmark could not be renewed.");
            return nil;
        }
        FFDiagnosticLog(@"Bookmark", @"Renewed: YES");
    }
    if (stale) *stale = bookmarkStale;
    return url;
}

+ (void)endBookmarkedFolderAccess:(NSURL *)url {
    if (!url) return;
    [url stopAccessingSecurityScopedResource];
    FFDiagnosticLog(@"AuthorizedFolderAccess", @"Security-scoped resource: STOPPED");
}

+ (void)invalidateStoredBookmark:(NSString *)reason {
    [NSUserDefaults.standardUserDefaults removeObjectForKey:FFBookmarkKey];
    FFDiagnosticLog(@"Bookmark", @"Invalidated: %@", reason.length ? reason : @"authorization unavailable");
}
@end

@interface FFCompatibilityRouter : NSObject
+ (FFAccessContext *)routeGame:(NSString *)gameIdentifier requiresWrite:(BOOL)requiresWrite;
+ (FFAccessContext *)verifyAuthorizedURL:(NSURL *)url
                                 forGame:(NSString *)gameIdentifier
                           requiresWrite:(BOOL)requiresWrite;
@end


@implementation FFCompatibilityRouter
+ (FFAccessContext *)verifyAuthorizedURL:(NSURL *)url
                                 forGame:(NSString *)gameIdentifier
                           requiresWrite:(BOOL)requiresWrite {
    FFAccessContext *context = [FFAccessContext new];
    context.method = FFAccessMethodAuthorizedFolder;
    context.gameIdentifier = gameIdentifier;
    context.rootURL = url;
    context.discovered = url != nil;
    return [FFAccessVerifier verifyContext:context requiresWrite:requiresWrite allowBackupOnly:NO];
}

+ (FFAccessContext *)routeGame:(NSString *)gameIdentifier requiresWrite:(BOOL)requiresWrite {
    NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
    FFDiagnosticLog(@"Compatibility", @"iOS: %ld.%ld.%ld", (long)version.majorVersion,
        (long)version.minorVersion, (long)version.patchVersion);
    FFDiagnosticLog(@"GameDetector", @"Bundle: %@", gameIdentifier ?: @"NONE");

    FFAccessContext *direct = [FFGameDetector detectDirectContainerForGame:gameIdentifier];
    if (direct.discovered) {
        [FFAccessVerifier verifyContext:direct requiresWrite:requiresWrite allowBackupOnly:NO];
        if (direct.usable) {
            FFDiagnosticLog(@"Compatibility", @"Selected access method: DirectAccess");
            FFDiagnosticLog(@"Compatibility", @"Final access state: READY");
            return direct;
        }
    }

    // On iOS 18.5 and later 18.x releases, Files does not expose another
    // application's private data container. A document picker cannot grant a
    // URL the user cannot select, so report the verified access state instead
    // of presenting a folder workflow that cannot authorize the target.
    if (version.majorVersion == 18 && version.minorVersion >= 5) {
        direct.needsFolderSelection = NO;
        NSString *state = direct.discovered ? @"CONTAINER_FOUND_ACCESS_DENIED"
                                            : @"AUTHORIZED_CONTAINER_ACCESS_UNAVAILABLE";
        direct.error = FFNamedError(67, state,
            @"iOS 18.5+ did not grant this app legitimate read/write access to the game's private container. The folder is not exposed in Files, so manual folder selection is unavailable.");
        return direct;
    }

#ifdef FM_OFFLINE_BUILD
    direct.needsFolderSelection = NO;
    direct.error = direct.error ?: FFError(67,
        @"3105 MCM direct access is unavailable on this device/signing method. Offline mode does not use a folder picker.");
    FFDiagnosticLog(@"Compatibility", @"Offline direct-only mode: no AuthorizedFolderAccess fallback");
    FFDiagnosticLog(@"Compatibility", @"Final access state: DIRECT ACCESS UNAVAILABLE");
    return direct;
#endif

    NSString *fallbackReason = direct.error.localizedDescription ?: @"Direct access did not pass filesystem verification.";
    FFDiagnosticLog(@"Compatibility", @"Falling back to AuthorizedFolderAccess");
    FFDiagnosticLog(@"Compatibility", @"Fallback reason: %@", fallbackReason);

    NSError *bookmarkError = nil;
    BOOL stale = NO;
    NSURL *authorizedRoot = [FFAccessManager beginBookmarkedFolderAccessWithStale:&stale error:&bookmarkError];
    if (!authorizedRoot) {
        FFAccessContext *failed = [FFAccessContext new];
        failed.method = FFAccessMethodNone;
        failed.gameIdentifier = gameIdentifier;
        failed.fallbackReason = fallbackReason;
        failed.error = bookmarkError ?: FFError(65, @"Select an authorized game folder to continue.");
        failed.needsFolderSelection = YES;
        if (bookmarkError.code == 66) [FFAccessManager invalidateStoredBookmark:bookmarkError.localizedDescription];
        FFDiagnosticLog(@"Compatibility", @"Final access state: AUTHORIZATION REQUIRED");
        return failed;
    }

    FFAccessContext *authorized = [self verifyAuthorizedURL:authorizedRoot
                                                   forGame:gameIdentifier
                                             requiresWrite:requiresWrite];
    authorized.fallbackReason = fallbackReason;
    [FFAccessManager endBookmarkedFolderAccess:authorizedRoot];
    if (authorized.usable) {
        FFDiagnosticLog(@"Compatibility", @"Selected access method: AuthorizedFolderAccess");
        FFDiagnosticLog(@"Compatibility", @"Final access state: READY");
        return authorized;
    }
    [FFAccessManager invalidateStoredBookmark:authorized.error.localizedDescription];
    authorized.needsFolderSelection = YES;
    FFDiagnosticLog(@"Compatibility", @"Final access state: AUTHORIZATION REQUIRED");
    return authorized;
}
@end

static BOOL FFCreateBackupIfNeeded(NSURL *target, NSError **error) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSURL *backup = [NSURL fileURLWithPath:[target.path stringByAppendingString:FFBackupSuffix]];
    if ([fm fileExistsAtPath:backup.path]) {
        NSData *saved = [NSData dataWithContentsOfURL:backup options:NSDataReadingMappedIfSafe error:nil];
        if (saved.length && FFDataLooksLikeUnityBundle(saved)) {
            FFDiagnosticLog(@"ApplyManager", @"Backup Original: VERIFIED (existing, never overwritten)");
            return YES;
        }
        if (error) *error = FFNamedError(13, @"ORIGINAL_BACKUP_FAILED", @"Existing original backup is invalid; apply aborted safely.");
        return NO;
    }
    NSDictionary *attributes = [fm attributesOfItemAtPath:target.path error:error];
    if (!attributes || [attributes fileSize] == 0) {
        if (error) *error = FFNamedError(13, @"ORIGINAL_BACKUP_FAILED", @"Original file is missing or empty.");
        return NO;
    }
    NSData *original = [NSData dataWithContentsOfURL:target options:NSDataReadingMappedIfSafe error:error];
    if (!original.length || !FFDataLooksLikeUnityBundle(original) ||
        ![fm copyItemAtURL:target toURL:backup error:error]) {
        if (error && !*error) *error = FFNamedError(13, @"ORIGINAL_BACKUP_FAILED", @"Could not create the original backup.");
        return NO;
    }
    NSData *saved = [NSData dataWithContentsOfURL:backup options:NSDataReadingMappedIfSafe error:nil];
    if (!saved.length || ![[ZXDigest(original) lowercaseString] isEqualToString:[ZXDigest(saved) lowercaseString]]) {
        [fm removeItemAtURL:backup error:nil];
        if (error) *error = FFNamedError(13, @"ORIGINAL_BACKUP_FAILED", @"Backup verification failed.");
        return NO;
    }
    FFDiagnosticLog(@"ApplyManager", @"Backup Original: SUCCESS + SHA256 VERIFIED");
    return YES;
}

static BOOL FFReplaceTargetWithData(NSURL *target, NSData *data, NSError **error) {
    if (!FFDataLooksLikeUnityBundle(data)) {
        if (error) *error = FFError(14, @"The selected feature is not a valid UnityFS cache bundle.");
        return NO;
    }

    NSFileManager *fm = NSFileManager.defaultManager;
    NSURL *directory = [target URLByDeletingLastPathComponent];
    NSString *temporaryName = [NSString stringWithFormat:@".%@.%@.tmp", target.lastPathComponent, NSUUID.UUID.UUIDString];
    NSURL *temporary = [directory URLByAppendingPathComponent:temporaryName];
    if (![data writeToURL:temporary options:NSDataWritingAtomic error:error]) return NO;

    BOOL succeeded = NO;
    if ([fm fileExistsAtPath:target.path]) {
        NSURL *result = nil;
        succeeded = [fm replaceItemAtURL:target
                            withItemAtURL:temporary
                           backupItemName:nil
                                  options:0
                         resultingItemURL:&result
                                    error:error];
    } else {
        succeeded = [fm moveItemAtURL:temporary toURL:target error:error];
    }
    if (!succeeded && [fm fileExistsAtPath:temporary.path]) [fm removeItemAtURL:temporary error:nil];
    NSData *installed = succeeded ? [NSData dataWithContentsOfURL:target options:NSDataReadingMappedIfSafe error:nil] : nil;
    if (!succeeded || ![[ZXDigest(installed) lowercaseString] isEqualToString:[ZXDigest(data) lowercaseString]]) {
        if (error && !*error) *error = FFNamedError(51, @"APPLY_FAILED", @"Post-write SHA-256 verification failed.");
        return NO;
    }
    FFDiagnosticLog(@"ApplyManager", @"APPLY_SUCCESS: target SHA256 verified");
    return YES;
}

static BOOL FFInstallFeatureData(NSData *data, NSURL *target, NSError **error) {
    if (!FFCreateBackupIfNeeded(target, error)) return NO;
    if (FFReplaceTargetWithData(target, data, error)) return YES;
    NSError *initial = error ? *error : nil;
    NSURL *backup = [NSURL fileURLWithPath:[target.path stringByAppendingString:FFBackupSuffix]];
    NSData *original = [NSData dataWithContentsOfURL:backup options:NSDataReadingMappedIfSafe error:nil];
    if (original.length) FFReplaceTargetWithData(target, original, nil);
    if (error) *error = initial ?: FFNamedError(51, @"APPLY_FAILED", @"Installation failed and original recovery was attempted.");
    return NO;
}

static BOOL FFReplaceRawData(NSURL *target, NSData *data, NSError **error) {
    if (!data.length) {
        if (error) *error = FFError(45, @"Protected resource is empty.");
        return NO;
    }
    NSFileManager *fm = NSFileManager.defaultManager;
    NSURL *directory = target.URLByDeletingLastPathComponent;
    NSURL *temporary = [directory URLByAppendingPathComponent:
        [NSString stringWithFormat:@".%@.%@.tmp", target.lastPathComponent, NSUUID.UUID.UUIDString]];
    if (![data writeToURL:temporary options:NSDataWritingAtomic error:error]) return NO;
    NSURL *result = nil;
    BOOL succeeded = [fm replaceItemAtURL:target withItemAtURL:temporary backupItemName:nil
                                  options:0 resultingItemURL:&result error:error];
    if (!succeeded && [fm fileExistsAtPath:temporary.path]) [fm removeItemAtURL:temporary error:nil];
    NSData *installed = succeeded ? [NSData dataWithContentsOfURL:target options:NSDataReadingMappedIfSafe error:nil] : nil;
    if (!succeeded || ![[ZXDigest(installed) lowercaseString] isEqualToString:[ZXDigest(data) lowercaseString]]) {
        if (error && !*error) *error = FFNamedError(51, @"APPLY_FAILED", @"Post-write SHA-256 verification failed.");
        return NO;
    }
    FFDiagnosticLog(@"ApplyManager", @"APPLY_SUCCESS: protected target SHA256 verified");
    return YES;
}

static BOOL FFInstallRawData(NSURL *target, NSData *data, NSError **error) {
    if (!FFCreateBackupIfNeeded(target, error)) return NO;
    if (FFReplaceRawData(target, data, error)) return YES;
    NSError *initial = error ? *error : nil;
    NSURL *backup = [NSURL fileURLWithPath:[target.path stringByAppendingString:FFBackupSuffix]];
    NSData *original = [NSData dataWithContentsOfURL:backup options:NSDataReadingMappedIfSafe error:nil];
    if (original.length) FFReplaceRawData(target, original, nil);
    if (error) *error = initial ?: FFNamedError(51, @"APPLY_FAILED", @"Installation failed and original recovery was attempted.");
    return NO;
}

static NSURL *FFFindUniqueAssetTarget(NSURL *container, NSURL *assetBundles, NSString *filename,
                                      NSString *displayName, BOOL allowBackupOnly, NSError **error) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSMutableArray<NSURL *> *roots = [NSMutableArray array];
    if (assetBundles) [roots addObject:assetBundles];
    if (container && (!assetBundles || ![container.path isEqualToString:assetBundles.path])) [roots addObject:container];
    NSMutableSet<NSString *> *exactMatches = [NSMutableSet set];
    NSMutableSet<NSString *> *versionedMatches = [NSMutableSet set];
    NSMutableSet<NSString *> *identityMatches = [NSMutableSet set];
    BOOL threeDTarget = [filename isEqualToString:FFThreeDShaderFilename];
    NSData *threeDIdentity = threeDTarget
        ? [@"CAB-88002acb86723c32269b375ebf7fc438" dataUsingEncoding:NSASCIIStringEncoding]
        : nil;
    NSString *lowerFilename = filename.lowercaseString;

    for (NSURL *root in roots) {
        BOOL regular = NO;
        NSURL *candidate = [root URLByAppendingPathComponent:filename];
        if ([fm fileExistsAtPath:candidate.path isDirectory:&regular] && !regular) {
            [exactMatches addObject:candidate.standardizedURL.path];
        } else if (allowBackupOnly) {
            NSURL *backupCandidate = [NSURL fileURLWithPath:[candidate.path stringByAppendingString:FFBackupSuffix]];
            if ([fm fileExistsAtPath:backupCandidate.path isDirectory:&regular] && !regular) {
                [exactMatches addObject:candidate.standardizedURL.path];
            }
        }
        NSDirectoryEnumerator<NSURL *> *enumerator = [fm enumeratorAtURL:root
            includingPropertiesForKeys:@[NSURLIsRegularFileKey, NSURLFileSizeKey] options:NSDirectoryEnumerationSkipsHiddenFiles |
            NSDirectoryEnumerationSkipsPackageDescendants errorHandler:^BOOL(NSURL *url, NSError *inner) {
                (void)url; (void)inner; return YES;
            }];
        NSUInteger visited = 0;
        NSUInteger maximum = [root.path isEqualToString:assetBundles.path] ? 250000 : 80000;
        for (NSURL *url in enumerator) {
            if (++visited > maximum) break;
            NSNumber *isRegular = nil;
            NSNumber *fileSize = nil;
            [url getResourceValue:&isRegular forKey:NSURLIsRegularFileKey error:nil];
            if (!isRegular.boolValue) continue;
            BOOL isBackup = allowBackupOnly && [url.path hasSuffix:FFBackupSuffix];
            NSURL *liveURL = isBackup
                ? [NSURL fileURLWithPath:[url.path substringToIndex:url.path.length - FFBackupSuffix.length]]
                : url;
            NSString *lowerName = liveURL.lastPathComponent.lowercaseString;
            if ([lowerName isEqualToString:lowerFilename]) {
                [exactMatches addObject:liveURL.standardizedURL.path];
                continue;
            }
            if (!threeDTarget) continue;
            BOOL versionedName = [lowerName hasPrefix:[lowerFilename stringByAppendingString:@"."]] ||
                [lowerName hasPrefix:[lowerFilename stringByAppendingString:@"~"]];
            if (!versionedName && ![lowerName containsString:@"shader"]) continue;
            [url getResourceValue:&fileSize forKey:NSURLFileSizeKey error:nil];
            if (fileSize.unsignedLongLongValue < 100000 || fileSize.unsignedLongLongValue > 2000000) continue;
            NSData *candidateData = [NSData dataWithContentsOfURL:url options:NSDataReadingMappedIfSafe error:nil];
            if (!FFDataLooksLikeUnityBundle(candidateData)) continue;
            BOOL identityMatch = [candidateData rangeOfData:threeDIdentity options:0
                range:NSMakeRange(0, candidateData.length)].location != NSNotFound;
            if (!identityMatch) continue;
            [identityMatches addObject:liveURL.standardizedURL.path];
            if (versionedName) [versionedMatches addObject:liveURL.standardizedURL.path];
        }
    }
    if (exactMatches.count == 1) return [NSURL fileURLWithPath:exactMatches.anyObject];
    if (exactMatches.count > 1) {
        if (error) *error = FFNamedError(49, @"ASSET_NOT_FOUND",
            [NSString stringWithFormat:@"Multiple exact %@ targets were found; update aborted safely.", displayName]);
        return nil;
    }
    if (versionedMatches.count == 1) return [NSURL fileURLWithPath:versionedMatches.anyObject];
    if (versionedMatches.count > 1 || identityMatches.count > 1) {
        if (error) *error = FFNamedError(49, @"ASSET_NOT_FOUND",
            [NSString stringWithFormat:@"Multiple verified %@ candidates were found; update aborted safely.", displayName]);
        return nil;
    }
    if (identityMatches.count == 1) return [NSURL fileURLWithPath:identityMatches.anyObject];
    if (error) *error = FFNamedError(49, @"ASSET_NOT_FOUND",
        [NSString stringWithFormat:@"The exact %@ target was not found. No unique filename or Unity bundle identity matched; no file was changed.", displayName]);
    return nil;
}

static BOOL FFVerifyDirectAssetTarget(NSURL *target, NSError **error) {
    errno = 0;
    int readDescriptor = open(target.fileSystemRepresentation, O_RDONLY | O_CLOEXEC);
    if (readDescriptor < 0) {
        NSError *posix = FFPOSIXAccessError(63, @"Required asset read open", target, errno);
        if (error) *error = FFNamedError(63, @"READ_FAILED", posix.localizedDescription);
        return NO;
    }
    unsigned char header[8] = {0};
    ssize_t bytesRead = read(readDescriptor, header, sizeof(header));
    close(readDescriptor);
    const unsigned char unityHeader[] = {'U','n','i','t','y','F','S',0};
    if (bytesRead != (ssize_t)sizeof(header) || memcmp(header, unityHeader, sizeof(unityHeader)) != 0) {
        if (error) *error = FFNamedError(63, @"READ_FAILED", @"Required asset is not a readable UnityFS file.");
        return NO;
    }
    errno = 0;
    int writeDescriptor = open(target.fileSystemRepresentation, O_WRONLY | O_CLOEXEC);
    if (writeDescriptor < 0) {
        NSError *posix = FFPOSIXAccessError(64, @"Required asset write open", target, errno);
        if (error) *error = FFNamedError(64, @"WRITE_FAILED", posix.localizedDescription);
        return NO;
    }
    close(writeDescriptor);
    FFDiagnosticLog(@"AccessVerifier", @"Open/Read/Write: SUCCESS (%@)", target.lastPathComponent);
    return YES;
}

static BOOL FFInstallHologramPackage(NSData *package, NSString *selectedGameIdentifier,
                                     NSString **targetPath, NSError **error) {
    if (![selectedGameIdentifier isEqualToString:FFBundleIDFreeFireTH]) {
        if (error) *error = FFError(52, @"Hologram is available only for FREE FIRE TH.");
        return NO;
    }
    if (package.length < 12 || memcmp(package.bytes, "FFPKG001", 8) != 0) {
        if (error) *error = FFError(50, @"Hologram package is invalid.");
        return NO;
    }
    const uint8_t *bytes = package.bytes;
    uint32_t manifestLength = FFReadBE32(bytes + 8);
    if (!FFRangeFits(12, manifestLength, package.length)) {
        if (error) *error = FFError(50, @"Hologram manifest is invalid.");
        return NO;
    }
    NSDictionary *manifest = [NSJSONSerialization JSONObjectWithData:
        [package subdataWithRange:NSMakeRange(12, manifestLength)] options:0 error:error];
    NSArray *files = [manifest[@"files"] isKindOfClass:NSArray.class] ? manifest[@"files"] : nil;
    if (![manifest[@"feature"] isEqualToString:@"HOLOGRAM_GUN"] || files.count != 1) {
        if (error) *error = FFError(50, @"Hologram package metadata is invalid.");
        return NO;
    }
    NSUInteger payloadOffset = 12 + manifestLength;
    NSMutableDictionary<NSString *, NSData *> *validated = [NSMutableDictionary dictionary];
    for (NSDictionary *entry in files) {
        NSString *name = entry[@"name"];
        unsigned long long offset = [entry[@"offset"] unsignedLongLongValue];
        unsigned long long size = [entry[@"size"] unsignedLongLongValue];
        if (![name isEqualToString:FFHologramShaderFilename] ||
            !FFRangeFits(payloadOffset + offset, size, package.length)) return NO;
        NSData *data = [package subdataWithRange:NSMakeRange(payloadOffset + (NSUInteger)offset, (NSUInteger)size)];
        if (![ZXDigest(data) isEqualToString:entry[@"sha256"]]) return NO;
        validated[name] = data;
    }
    NSData *shader = validated[FFHologramShaderFilename];
    if (!shader.length || !FFDataLooksLikeUnityBundle(shader)) {
        if (error) *error = FFError(50, @"Hologram shader data is invalid.");
        return NO;
    }
    NSString *gameIdentifier = nil;
    NSURL *assetBundles = nil;
    NSURL *container = FFDirectGameContainer(selectedGameIdentifier, &gameIdentifier, nil, &assetBundles, error);
    if (!container) return NO;
    if (![gameIdentifier isEqualToString:FFBundleIDFreeFireTH]) {
        if (error) *error = FFError(52, @"Hologram is available only for Free Fire, not Free Fire MAX.");
        return NO;
    }
    NSURL *target = FFFindUniqueAssetTarget(container, assetBundles, FFHologramShaderFilename,
        @"Hologram shader", NO, error);
    if (!target) return NO;
    if (!FFVerifyDirectAssetTarget(target, error)) return NO;
    if (!FFInstallRawData(target, shader, error)) return NO;
    if (targetPath) *targetPath = target.path;
    return YES;
}

static BOOL FFInstallThreeDData(NSData *data, NSString *selectedGameIdentifier,
                                NSString **targetPath, NSError **error) {
    if (!FFGameDefinition(selectedGameIdentifier)) {
        if (error) *error = FFNamedError(60, @"GAME_NOT_FOUND", @"Selected game is unsupported.");
        return NO;
    }
    if (data.length < 100000 || data.length > 2000000 || !FFDataLooksLikeUnityBundle(data)) {
        if (error) *error = FFNamedError(50, @"ASSET_NOT_FOUND", @"3D resource is not a valid UnityFS bundle.");
        return NO;
    }
    NSString *detectedIdentifier = nil;
    NSURL *assetBundles = nil;
    NSURL *container = FFDirectGameContainer(selectedGameIdentifier, &detectedIdentifier, nil,
        &assetBundles, error);
    if (!container || ![detectedIdentifier isEqualToString:selectedGameIdentifier]) {
        if (error && !*error) *error = FFNamedError(60, @"CONTAINER_NOT_FOUND", @"Game data container was not discovered by bundle ID.");
        return NO;
    }
    NSURL *target = FFFindUniqueAssetTarget(container, assetBundles, FFThreeDShaderFilename,
        @"3D shader", NO, error);
    if (!target) return NO;
    if (!FFVerifyDirectAssetTarget(target, error)) return NO;
    if (!FFInstallRawData(target, data, error)) return NO;
    if (targetPath) *targetPath = target.path;
    return YES;
}

static BOOL FFRestoreOriginal(NSURL *target, NSError **error) {
    NSURL *backup = [NSURL fileURLWithPath:[target.path stringByAppendingString:FFBackupSuffix]];
    NSData *data = [NSData dataWithContentsOfURL:backup options:NSDataReadingMappedIfSafe error:error];
    if (!data) {
        if (error && !*error) *error = FFNamedError(15, @"RESTORE_FAILED", @"Original backup was not found.");
        return NO;
    }
    if (!FFReplaceTargetWithData(target, data, error)) {
        if (error && !*error) *error = FFNamedError(51, @"RESTORE_FAILED", @"Original data could not be restored.");
        return NO;
    }
    FFDiagnosticLog(@"ApplyManager", @"RESTORE_SUCCESS: original SHA256 verified");
    return YES;
}

static BOOL FFRestoreDirectAsset(NSString *gameIdentifier, NSString *filename,
                                 NSString *displayName, NSString **targetPath, NSError **error) {
    NSString *detectedIdentifier = nil;
    NSURL *assetBundles = nil;
    NSURL *container = FFDirectGameContainer(gameIdentifier, &detectedIdentifier, nil,
        &assetBundles, error);
    if (!container || ![detectedIdentifier isEqualToString:gameIdentifier]) {
        if (error && !*error) *error = FFNamedError(60, @"CONTAINER_NOT_FOUND", @"Game container is unavailable for restore.");
        return NO;
    }
    NSURL *target = FFFindUniqueAssetTarget(container, assetBundles, filename, displayName, YES, error);
    if (!target || !FFRestoreOriginal(target, error)) return NO;
    if (targetPath) *targetPath = target.path;
    return YES;
}

static void FFSaveHologramState(NSString *gameIdentifier, NSString *color,
                                NSString *targetPath, NSInteger durationDays) {
    NSDate *applied = [NSDate date];
    NSTimeInterval seconds = (durationDays == 3 ? 3 : 1) * 86400.0;
    NSDictionary *state = @{
        @"game": gameIdentifier ?: @"",
        @"color": color ?: @"",
        @"target": targetPath ?: @"",
        @"applied_at": @([applied timeIntervalSince1970]),
        @"expires_at": @([applied timeIntervalSince1970] + seconds),
        @"duration_days": @(durationDays == 3 ? 3 : 1),
    };
    [NSUserDefaults.standardUserDefaults setObject:state forKey:FFHologramStateKey];
    FFDiagnosticLog(@"ApplyManager", @"Hologram state saved: applied=%@ expires=%@",
        state[@"applied_at"], state[@"expires_at"]);
}

static BOOL FFRestoreExpiredHologram(BOOL *restoreNeeded, NSString **gameOut,
                                     NSString **pathOut, NSError **error) {
    NSDictionary *state = [NSUserDefaults.standardUserDefaults dictionaryForKey:FFHologramStateKey];
    NSString *game = [state[@"game"] isKindOfClass:NSString.class] ? state[@"game"] : nil;
    NSNumber *expires = [state[@"expires_at"] isKindOfClass:NSNumber.class] ? state[@"expires_at"] : nil;
    BOOL expired = FFGameDefinition(game) && expires && expires.doubleValue <= NSDate.date.timeIntervalSince1970;
    if (restoreNeeded) *restoreNeeded = expired;
    if (!expired) return YES;
    if (gameOut) *gameOut = game;
    FFDiagnosticLog(@"ApplyManager", @"HOLOGRAM_EXPIRED: automatic restore requested");
    NSString *detectedIdentifier = nil;
    NSURL *assetBundles = nil;
    NSURL *container = FFDirectGameContainer(game, &detectedIdentifier, nil, &assetBundles, error);
    if (!container || ![detectedIdentifier isEqualToString:game]) {
        if (error && !*error) *error = FFNamedError(60, @"CONTAINER_NOT_FOUND", @"Expired Hologram state kept for the next access attempt.");
        return NO;
    }
    NSURL *target = FFFindUniqueAssetTarget(container, assetBundles, FFHologramShaderFilename,
        @"Hologram shader", YES, error);
    if (!target || !FFRestoreOriginal(target, error)) {
        if (error && !*error) *error = FFNamedError(51, @"RESTORE_FAILED", @"Expired Hologram state was retained for retry.");
        return NO;
    }
    if (pathOut) *pathOut = target.path;
    [NSUserDefaults.standardUserDefaults removeObjectForKey:FFHologramStateKey];
    NSString *activeKey = FFActiveProfileDefaultsKey(game);
    if (activeKey) [NSUserDefaults.standardUserDefaults removeObjectForKey:activeKey];
    FFDiagnosticLog(@"ApplyManager", @"RESTORE_SUCCESS: expired Hologram restored and state cleared");
    return YES;
}

typedef void (^FFVerifiedTargetOperation)(NSURL *target, NSError **operationError);

@interface FFFeatureManager : NSObject
+ (BOOL)installProfileData:(NSData *)data
                   forGame:(NSString *)gameIdentifier
              accessMethod:(FFAccessMethod)accessMethod
                targetPath:(NSString **)targetPath
                     error:(NSError **)error;
+ (BOOL)restoreOriginalForGame:(NSString *)gameIdentifier
                  accessMethod:(FFAccessMethod)accessMethod
                    targetPath:(NSString **)targetPath
                         error:(NSError **)error;
@end

@implementation FFFeatureManager
+ (BOOL)performTargetOperationForGame:(NSString *)gameIdentifier
                         accessMethod:(FFAccessMethod)accessMethod
                      allowBackupOnly:(BOOL)allowBackupOnly
                            operation:(FFVerifiedTargetOperation)operation
                           targetPath:(NSString **)targetPath
                                error:(NSError **)error {
    FFDiagnosticLog(@"FeatureManager", @"Requested access method: %@", FFAccessMethodName(accessMethod));
    FFAccessContext *context = nil;
    NSURL *authorizedRoot = nil;
    if (accessMethod == FFAccessMethodDirect) {
        context = [FFGameDetector detectDirectContainerForGame:gameIdentifier];
        if (context.discovered) {
            [FFAccessVerifier verifyContext:context requiresWrite:YES allowBackupOnly:allowBackupOnly];
        }
    } else if (accessMethod == FFAccessMethodAuthorizedFolder) {
        NSError *bookmarkError = nil;
        BOOL stale = NO;
        authorizedRoot = [FFAccessManager beginBookmarkedFolderAccessWithStale:&stale error:&bookmarkError];
        context = [FFAccessContext new];
        context.method = FFAccessMethodAuthorizedFolder;
        context.gameIdentifier = gameIdentifier;
        context.rootURL = authorizedRoot;
        context.discovered = authorizedRoot != nil;
        context.error = bookmarkError;
        if (authorizedRoot) {
            [FFAccessVerifier verifyContext:context requiresWrite:YES allowBackupOnly:allowBackupOnly];
        }
    } else {
        context = [FFAccessContext new];
        context.error = FFError(67, @"No verified filesystem access method is active.");
    }

    if (!context.usable || !context.targetURL) {
        if (authorizedRoot) [FFAccessManager endBookmarkedFolderAccess:authorizedRoot];
        if (error) *error = context.error ?: FFError(67, @"Filesystem access must be verified again.");
        FFDiagnosticLog(@"FeatureManager", @"Final access state: FAILED (%@)",
            context.error.localizedDescription ?: @"verification failed");
        return NO;
    }

    if (targetPath) *targetPath = context.targetURL.path;
    NSFileCoordinator *coordinator = [[NSFileCoordinator alloc] initWithFilePresenter:nil];
    __block NSError *operationError = nil;
    NSError *coordinationError = nil;
    [coordinator coordinateWritingItemAtURL:context.targetURL
                                    options:NSFileCoordinatorWritingForReplacing
                                      error:&coordinationError
                                 byAccessor:^(NSURL *coordinatedTarget) {
        operation(coordinatedTarget, &operationError);
    }];
    if (!operationError && coordinationError) operationError = coordinationError;
    if (authorizedRoot) [FFAccessManager endBookmarkedFolderAccess:authorizedRoot];
    if (operationError) {
        if (error) *error = operationError;
        FFDiagnosticLog(@"FeatureManager", @"Final access state: FAILED (%@)", operationError.localizedDescription);
        return NO;
    }
    FFDiagnosticLog(@"FeatureManager", @"Final access state: SUCCESS");
    return YES;
}

+ (BOOL)installProfileData:(NSData *)data
                   forGame:(NSString *)gameIdentifier
              accessMethod:(FFAccessMethod)accessMethod
                targetPath:(NSString **)targetPath
                     error:(NSError **)error {
    return [self performTargetOperationForGame:gameIdentifier
                                  accessMethod:accessMethod
                               allowBackupOnly:NO
                                     operation:^(NSURL *target, NSError **operationError) {
        if (!FFInstallFeatureData(data, target, operationError) && operationError && !*operationError) {
            *operationError = FFError(51, @"Option installation failed.");
        }
    } targetPath:targetPath error:error];
}

+ (BOOL)restoreOriginalForGame:(NSString *)gameIdentifier
                  accessMethod:(FFAccessMethod)accessMethod
                    targetPath:(NSString **)targetPath
                         error:(NSError **)error {
    return [self performTargetOperationForGame:gameIdentifier
                                  accessMethod:accessMethod
                               allowBackupOnly:YES
                                     operation:^(NSURL *target, NSError **operationError) {
        if (!FFRestoreOriginal(target, operationError) && operationError && !*operationError) {
            *operationError = FFError(51, @"Restore failed.");
        }
    } targetPath:targetPath error:error];
}
@end

typedef void (^FFHologramSelectionHandler)(NSDictionary *color);

@interface FFHologramPickerController : UIViewController
- (instancetype)initWithColors:(NSArray<NSDictionary *> *)colors
                           title:(NSString *)title
                      applyTitle:(NSString *)applyTitle
                     selection:(FFHologramSelectionHandler)selection;
@end

@implementation FFHologramPickerController {
    NSArray<NSDictionary *> *_colors;
    FFHologramSelectionHandler _selection;
    NSArray<UIButton *> *_colorButtons;
    UIButton *_applyButton;
    NSInteger _selectedIndex;
    NSString *_pickerTitle;
    NSString *_pickerApplyTitle;
}

- (instancetype)initWithColors:(NSArray<NSDictionary *> *)colors
                           title:(NSString *)title
                      applyTitle:(NSString *)applyTitle
                     selection:(FFHologramSelectionHandler)selection {
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _colors = [colors copy];
        _selection = [selection copy];
        _pickerTitle = [title copy] ?: @"OPTIONS";
        _pickerApplyTitle = [applyTitle copy] ?: @"APPLY";
        _selectedIndex = NSNotFound;
        self.modalPresentationStyle = UIModalPresentationPageSheet;
    }
    return self;
}

}
        [self setStatus:@"Restoring original cache…" path:nil active:nil error:NO];
        FFAccessMethod accessMethod = self->_accessMethod;
        NSString *activeKey = FFActiveProfileDefaultsKey(selectedGame);
        NSString *activeProfile = activeKey ? [NSUserDefaults.standardUserDefaults stringForKey:activeKey] : nil;
        __block NSString *path = nil;
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSError *error = nil;
            BOOL restored = NO;
            if ([activeProfile hasPrefix:@"HOLOGRAM"]) {
                restored = FFRestoreDirectAsset(selectedGame, FFHologramShaderFilename,
                    @"Hologram shader", &path, &error);
            } else if ([activeProfile hasPrefix:@"3D"]) {
                restored = FFRestoreDirectAsset(selectedGame, FFThreeDShaderFilename,
                    @"3D shader", &path, &error);
            } else {
                restored = [FFFeatureManager restoreOriginalForGame:selectedGame
                    accessMethod:accessMethod targetPath:&path error:&error];
            }
            if (!restored && !error) error = FFNamedError(51, @"RESTORE_FAILED", @"Restore failed safely.");
            dispatch_async(dispatch_get_main_queue(), ^{
                if (![self->_selectedGameIdentifier isEqualToString:selectedGame]) return;
                [self setBusy:NO];
                if (error) {
                    if ([error.domain isEqualToString:@"com.acidevloper.robotexternal"] &&
                        error.code >= 60 && error.code <= 67) {
                        self->_accessContext = nil;
                        self->_accessMethod = FFAccessMethodNone;
                        self->_usingSelectedFolder = NO;
                        self->_connectedGameIdentifier = nil;
                        self->_gameInstalled = NO;
                    }
                    [self setStatus:error.localizedDescription path:path active:nil error:YES];
                }
                else {
                    NSString *key = FFActiveProfileDefaultsKey(selectedGame);
                    if (key) [NSUserDefaults.standardUserDefaults removeObjectForKey:key];
                    if ([activeProfile hasPrefix:@"HOLOGRAM"]) {
                        [NSUserDefaults.standardUserDefaults removeObjectForKey:FFHologramStateKey];
                    }
                    self->_readyToRun = NO;
                    [self setStatus:@"RESTORE_SUCCESS — ORIGINAL RESTORED" path:path active:@"ORIGINAL" error:NO];
                }
                [self rebuildInterface];
            });
        });
    }];
}

- (void)restoreOriginalFromSelectedFolder {
    __block NSString *path = nil;
    [self withSelectedRoot:^(NSURL *root, NSError **operationError) {
        NSFileCoordinator *rootCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:nil];
        __block NSError *inner = nil;
        [rootCoordinator coordinateReadingItemAtURL:root options:0 error:&inner byAccessor:^(NSURL *coordinatedRoot) {
            NSURL *directory = FFFindGameAssetBundles(coordinatedRoot, &inner);
            NSURL *target = directory ? FFTargetFile(directory, self->_selectedGameIdentifier, YES, &inner) : nil;
            if (!target) return;
            path = target.path;
            NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:nil];
            [fileCoordinator coordinateWritingItemAtURL:target options:NSFileCoordinatorWritingForReplacing error:&inner byAccessor:^(NSURL *coordinatedTarget) {
                FFRestoreOriginal(coordinatedTarget, &inner);
            }];
        }];
        if (inner) *operationError = inner;
    } completion:^(NSError *error) {
        [self setBusy:NO];
        if (error) {
            [self setStatus:error.localizedDescription path:path active:nil error:YES];
            return;
        }
        NSString *key = FFActiveProfileDefaultsKey(self->_selectedGameIdentifier);
        if (key) [NSUserDefaults.standardUserDefaults removeObjectForKey:key];
        [self setStatus:@"Original cache restored" path:path active:@"ORIGINAL" error:NO];
    }];
}

@end
@interface FougoVectorIconView : UIView
@property (nonatomic, assign) FougoVectorIconType iconType;
@property (nonatomic, strong) UIColor *strokeColor;
@property (nonatomic, assign) CGFloat lineWidth;
- (instancetype)initWithFrame:(CGRect)frame iconType:(FougoVectorIconType)type;
@end

@hu.92 alpha:0.90];
        _lineWidth = 1.75;

        _shapeLayer = [CAShapeLayer layer];
        _shapeLayer.fillColor = [UIColor clearColor].CGColor;
        _shapeLayer.strokeColor = _strokeColor.CGColor;
        _shapeLayer.lineWidth = _lineWidth;
        _shapeLayer.lineCap = kCALineCapRound;
        _shapeLayer.lineJoin = kCALineJoinRound;
        [self.layer addSublayer:_shapeLayer];
    }
    return self;
}

- (void)setStrokeColor:(UIColor *)strokeColor {
    _strokeColor = strokeColor;
    _shapeLayer.strokeColor = strokeColor.CGColor;
}

- (void)setLineWidth:(CGFloat)lineWidth {
    _lineWidth = lineWidth;
    _shapeLayer.lineWidth = lineWidth;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _shapeLayer.frame = self.bounds;
    _shapeLayer.path = [self buildVectorPathInRect:self.bounds].CGPath;
}

- (UIBezierPath *)buildVectorPathInRect:(CGRect)rect {
    CGFloat w = rect.size.width;
    CGFloat h = rect.size.height;
    UIBezierPath *p = [UIBezierPath bezierPath];
    if (w <= 0 || h <= 0) return p;

    switch (_iconType) {
        case FougoVectorIconHome: {
            [p moveToPoint:CGPointMake(w * 0.14, h * 0.46)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.14)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.46)];
            [p moveToPoint:CGPointMake(w * 0.24, h * 0.42)];
            [p addLineToPoint:CGPointMake(w * 0.24, h * 0.84)];
            [p addLineToPoint:CGPointMake(w * 0.76, h * 0.84)];
            [p addLineToPoint:CGPointMake(w * 0.76, h * 0.42)];
            [p moveToPoint:CGPointMake(w * 0.42, h * 0.84)];
            [p addLineToPoint:CGPointMake(w * 0.42, h * 0.58)];
            [p addLineToPoint:CGPointMake(w * 0.58, h * 0.58)];
            [p addLineToPoint:CGPointMake(w * 0.58, h * 0.84)];
            break;
        }
        case FougoVectorIconGames: {
            CGFloat r = w * 0.08;
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.15, h * 0.15, w * 0.30, h * 0.30) cornerRadius:r]];
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.55, h * 0.15, w * 0.30, h * 0.30) cornerRadius:r]];
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.15, h * 0.55, w * 0.30, h * 0.30) cornerRadius:r]];
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.55, h * 0.55, w * 0.30, h * 0.30) cornerRadius:r]];
            break;
        }
        case FougoVectorIconSettings: {
            CGPoint c = CGPointMake(w * 0.5, h * 0.5);
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.16 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.30 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            for (NSInteger i = 0; i < 6; i++) {
                CGFloat ang = (CGFloat)i * (M_PI / 3.0);
                CGPoint p1 = CGPointMake(c.x + cos(ang) * (w * 0.30), c.y + sin(ang) * (h * 0.30));
                CGPoint p2 = CGPointMake(c.x + cos(ang) * (w * 0.41), c.y + sin(ang) * (h * 0.41));
                [p moveToPoint:p1];
                [p addLineToPoint:p2];
            }
            break;
        }
        case FougoVectorIconCrosshair: {
            CGPoint c = CGPointMake(w * 0.5, h * 0.5);
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.32 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.06 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p moveToPoint:CGPointMake(c.x, h * 0.08)];
            [p addLineToPoint:CGPointMake(c.x, h * 0.24)];
            [p moveToPoint:CGPointMake(c.x, h * 0.76)];
            [p addLineToPoint:CGPointMake(c.x, h * 0.92)];
            [p moveToPoint:CGPointMake(w * 0.08, c.y)];
            [p addLineToPoint:CGPointMake(w * 0.24, c.y)];
            [p moveToPoint:CGPointMake(w * 0.76, c.y)];
            [p addLineToPoint:CGPointMake(w * 0.92, c.y)];
            break;
        }
        case FougoVectorIconLayers: {
            [p moveToPoint:CGPointMake(w * 0.50, h * 0.16)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.34)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.52)];
            [p addLineToPoint:CGPointMake(w * 0.14, h * 0.34)];
            [p closePath];
            [p moveToPoint:CGPointMake(w * 0.14, h * 0.52)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.70)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.52)];
            [p moveToPoint:CGPointMake(w * 0.14, h * 0.68)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.86)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.68)];
            break;
        }
        case FougoVectorIconChevronRight: {
            [p moveToPoint:CGPointMake(w * 0.36, h * 0.22)];
            [p addLineToPoint:CGPointMake(w * 0.66, h * 0.50)];
            [p addLineToPoint:CGPointMake(w * 0.36, h * 0.78)];
            break;
        }
        case FougoVectorIconSliders: {
            [p moveToPoint:CGPointMake(w * 0.16, h * 0.30)];
            [p addLineToPoint:CGPointMake(w * 0.84, h * 0.30)];
            [p moveToPoint:CGPointMake(w * 0.16, h * 0.70)];
            [p addLineToPoint:CGPointMake(w * 0.84, h * 0.70)];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:CGPointMake(w * 0.38, h * 0.30) radius:w * 0.09 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:CGPointMake(w * 0.64, h * 0.70) radius:w * 0.09 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            break;
        }
        case FougoVectorIconShield: {
            [p moveToPoint:CGPointMake(w * 0.50, h * 0.12)];
            [p addLineToPoint:CGPointMake(w * 0.84, h * 0.26)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.50, h * 0.88) controlPoint:CGPointMake(w * 0.84, h * 0.68)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.16, h * 0.26) controlPoint:CGPointMake(w * 0.16, h * 0.68)];
            [p closePath];
            break;
        }
    }
    return p;
}

@end

// ============================================================================
// Interactive Frosted Liquid-Glass Game / Module Card
// ============================================================================
@interface FougoLiquidGameCard : UIControl
@property (nonatomic, copy) NSString *gameTitle;
@property (nonatomic, copy) NSString *gameSubtitle;
@property (nonatomic, assign) BOOL isSelectedCard;
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title subtitle:(NSString *)subtitle iconType:(FougoVectorIconType)iconType;
@end

@implementation FougoLiquidGameCard {
    UIVisualEffectView *_blurView;
    UIView *_glassTintView;
    CAGradientLayer *_topSheenLayer;
    UIView *_iconWell;
    FougoVectorIconView *_leadIcon;
    FougoVectorIconView *_chevronIcon;
    UILabel *_titleLabel;
    UILabel *_subtitleLabel;
}

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title subtitle:(NSString *)subtitle iconType:(FougoVectorIconType)iconType {
    self = [super initWithFrame:frame];
    if (self) {
        _gameTitle = [title copy];
        _gameSubtitle = [subtitle copy];
        self.backgroundColor = [UIColor clearColor];
        self.clipsToBounds = NO;

        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 14);
        self.layer.shadowRadius = 24.0;
        self.layer.shadowOpacity = 0.45;

        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
        _blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
        _blurView.frame = self.bounds;
        _blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _blurView.layer.cornerRadius = 24.0;
        _blurView.layer.masksToBounds = YES;
        _blurView.layer.borderWidth = 1.25;
        _blurView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
        _blurView.userInteractionEnabled = NO;
        [self addSubview:_blurView];

        _glassTintView = [[UIView alloc] initWithFrame:self.bounds];
        _glassTintView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _glassTintView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.04];
        _glassTintView.userInteractionEnabled = NO;
        [_blurView.contentView addSubview:_glassTintView];

        _topSheenLayer = [CAGradientLayer layer];
        _topSheenLayer.colors = @[
            (id)[UIColor colorWithWhite:1.0 alpha:0.16].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.03].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor
        ];
        _topSheenLayer.locations = @[@0.0, @0.45, @1.0];
        _topSheenLayer.startPoint = CGPointMake(0.2, 0.0);
        _topSheenLayer.endPoint = CGPointMake(0.8, 1.0);
        [_blurView.contentView.layer addSublayer:_topSheenLayer];

        _iconWell = [[UIView alloc] initWithFrame:CGRectMake(20, 0, 48, 48)];
        _iconWell.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.07];
        _iconWell.layer.cornerRadius = 15.0;
        _iconWell.layer.borderWidth = 1.0;
        _iconWell.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
        _iconWell.userInteractionEnabled = NO;
        [self addSubview:_iconWell];

        _leadIcon = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(12, 12, 24, 24) iconType:iconType];
        _leadIcon.strokeColor = [UIColor colorWithRed:0.65 green:0.93 blue:1.0 alpha:0.95];
        [_iconWell addSubview:_leadIcon];

        _titleLabel = [[UILabel alloc] init];
        _titleLabel.text = _gameTitle;
        _titleLabel.font = [UIFont systemFontOfSize:17.5 weight:UIFontWeightHeavy];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.userInteractionEnabled = NO;
        [self addSubview:_titleLabel];

        _subtitleLabel = [[UILabel alloc] init];
        _subtitleLabel.text = _gameSubtitle;
        _subtitleLabel.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightMedium];
        _subtitleLabel.textColor = [UIColor colorWithWhite:0.74 alpha:0.85];
        _subtitleLabel.userInteractionEnabled = NO;
        [self addSubview:_subtitleLabel];

        _chevronIcon = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(0, 0, 18, 18) iconType:FougoVectorIconChevronRight];
        _chevronIcon.strokeColor = [UIColor colorWithWhite:0.85 alpha:0.65];
        [self addSubview:_chevronIcon];
    }
    return self;
}

- (void)setIsSelectedCard:(BOOL)isSelectedCard {
    _isSelectedCard = isSelectedCard;
    [UIView animateWithDuration:0.25 animations:^{
        if (isSelectedCard) {
            self->_blurView.layer.borderColor = [UIColor colorWithRed:0.45 green:0.90 blue:1.0 alpha:0.82].CGColor;
            self->_glassTintView.backgroundColor = [UIColor colorWithRed:0.16 green:0.64 blue:0.95 alpha:0.16];
            self->_iconWell.backgroundColor = [UIColor colorWithRed:0.25 green:0.80 blue:1.0 alpha:0.18];
            self->_iconWell.layer.borderColor = [UIColor colorWithRed:0.55 green:0.92 blue:1.0 alpha:0.55].CGColor;
        } else {
            self->_blurView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.16].CGColor;
            self->_glassTintView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.04];
            self->_iconWell.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.07];
            self->_iconWell.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
        }
    }];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.bounds;
    _topSheenLayer.frame = b;
    _iconWell.frame = CGRectMake(18, (b.size.height - 48.0) * 0.5, 48.0, 48.0);
    _leadIcon.frame = CGRectMake(12, 12, 24, 24);
    if (_gameSubtitle.length > 0) {
        _titleLabel.frame = CGRectMake(80, b.size.height * 0.5 - 19.0, b.size.width - 120.0, 22.0);
        _subtitleLabel.frame = CGRectMake(80, b.size.height * 0.5 + 3.0, b.size.width - 120.0, 16.0);
    } else {
        _titleLabel.frame = CGRectMake(80, (b.size.height - 24.0) * 0.5, b.size.width - 120.0, 24.0);
        _subtitleLabel.frame = CGRectZero;
    }
    _chevronIcon.frame = CGRectMake(b.size.width - 36.0, (b.size.height - 18.0) * 0.5, 18.0, 18.0);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [UIView animateWithDuration:0.14 delay:0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
        self.transform = CGAffineTransformMakeScale(0.975, 0.975);
    } completion:nil];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    [UIView animateWithDuration:0.32 delay:0 usingSpringWithDamping:0.74 initialSpringVelocity:0.8 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
        self.transform = CGAffineTransformIdentity;
    } completion:nil];
    [self sendActionsForControlEvents:UIControlEventTouchUpInside];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesCancelled:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

@end

// ============================================================================
// Floating Frosted Liquid-Glass Bottom Navigation Bar (HOME | GAMES | SETTINGS)
// ============================================================================
@protocol FougoLiquidBottomNavDelegate <NSObject>
- (void)liquidBottomNavDidSelectIndex:(NSInteger)index;
@end

@interface FougoLiquidBottomNav : UIView
@property (nonatomic, weak) id<FougoLiquidBottomNavDelegate> delegate;
@property (nonatomic, assign) NSInteger selectedIndex;
- (void)setSelectedIndex:(NSInteger)selectedIndex animated:(BOOL)animated;
@end

@implementation FougoLiquidBottomNav {
    UIVisualEffectView *_blurView;
    CAGradientLayer *_topSheenLayer;
    UIView *_activeLensPill;
    NSMutableArray<UIView *> *_itemContainers;
    NSMutableArray<FougoVectorIconView *> *_itemIcons;
    NSMutableArray<UILabel *> *_itemLabels;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.clipsToBounds = NO;
        _selectedIndex = 1;

        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 12);
        self.layer.shadowRadius = 24.0;
        self.layer.shadowOpacity = 0.52;

        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterialDark];
        _blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
        _blurView.frame = self.bounds;
        _blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _blurView.layer.cornerRadius = 31.0;
        _blurView.layer.masksToBounds = YES;
        _blurView.layer.borderWidth = 1.0;
        _blurView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.22].CGColor;
        _blurView.userInteractionEnabled = NO;
        [self addSubview:_blurView];

        _topSheenLayer = [CAGradientLayer layer];
        _topSheenLayer.colors = @[
            (id)[UIColor colorWithWhite:1.0 alpha:0.16].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.02].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor
        ];
        _topSheenLayer.locations = @[@0.0, @0.5, @1.0];
        _topSheenLayer.startPoint = CGPointMake(0.5, 0.0);
        _topSheenLayer.endPoint = CGPointMake(0.5, 1.0);
        [_blurView.contentView.layer addSublayer:_topSheenLayer];

        _activeLensPill = [[UIView alloc] init];
        _activeLensPill.backgroundColor = [UIColor colorWithRed:0.35 green:0.84 blue:1.0 alpha:0.18];
        _activeLensPill.layer.cornerRadius = 26.0;
        _activeLensPill.layer.borderWidth = 1.0;
        _activeLensPill.layer.borderColor = [UIColor colorWithRed:0.55 green:0.92 blue:1.0 alpha:0.48].CGColor;
        _activeLensPill.userInteractionEnabled = NO;
        [_blurView.contentView addSubview:_activeLensPill];

        NSArray<NSString *> *titles = @[@"HOME", @"GAMES", @"SETTINGS"];
        NSArray<NSNumber *> *icons = @[
            @(FougoVectorIconHome),
            @(FougoVectorIconGames),
            @(FougoVectorIconSettings)
        ];

        _itemContainers = [NSMutableArray array];
        _itemIcons = [NSMutableArray array];
        _itemLabels = [NSMutableArray array];

        for (NSInteger i = 0; i < 3; i++) {
            UIView *slot = [[UIView alloc] init];
            slot.userInteractionEnabled = NO;
            [_blurView.contentView addSubview:slot];
            [_itemContainers addObject:slot];

            FougoVectorIconView *ic = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(0, 0, 20, 20) iconType:(FougoVectorIconType)[icons[i] integerValue]];
            [slot addSubview:ic];
            [_itemIcons addObject:ic];

            UILabel *lb = [[UILabel alloc] init];
            lb.text = titles[i];
            lb.font = [UIFont systemFontOfSize:10.0 weight:UIFontWeightBold];
            lb.textAlignment = NSTextAlignmentCenter;
            [slot addSubview:lb];
            [_itemLabels addObject:lb];
        }

        [self refreshActiveNavVisualsAnimated:NO];
    }
    return self;
}

- (void)setSelectedIndex:(NSInteger)selectedIndex animated:(BOOL)animated {
    _selectedIndex = MAX(0, MIN(2, selectedIndex));
    [self refreshActiveNavVisualsAnimated:animated];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.bounds;
    _blurView.layer.cornerRadius = b.size.height * 0.5;
    _topSheenLayer.frame = b;

    CGFloat slotW = b.size.width / 3.0;
    for (NSInteger i = 0; i < 3; i++) {
        UIView *slot = _itemContainers[i];
        slot.frame = CGRectMake(slotW * i, 0, slotW, b.size.height);

        FougoVectorIconView *ic = _itemIcons[i];
        ic.frame = CGRectMake((slotW - 20.0) * 0.5, 11.0, 20.0, 20.0);

        UILabel *lb = _itemLabels[i];
        lb.frame = CGRectMake(4.0, 35.0, slotW - 8.0, 14.0);
    }

    CGFloat pillW = slotW - 12.0;
    CGFloat pillH = b.size.height - 10.0;
    _activeLensPill.frame = CGRectMake(slotW * _selectedIndex + 6.0, 5.0, pillW, pillH);
    _activeLensPill.layer.cornerRadius = pillH * 0.5;
}

- (void)refreshActiveNavVisualsAnimated:(BOOL)animated {
    CGRect b = self.bounds;
    CGFloat slotW = b.size.width / 3.0;
    CGFloat pillW = MAX(56.0, slotW - 12.0);
    CGFloat pillH = MAX(38.0, b.size.height - 10.0);

    void (^applyBlock)(void) = ^{
        if (b.size.width > 0) {
            self->_activeLensPill.frame = CGRectMake(slotW * self->_selectedIndex + 6.0, 5.0, pillW, pillH);
            self->_activeLensPill.layer.cornerRadius = pillH * 0.5;
        }
        for (NSInteger i = 0; i < 3; i++) {
            BOOL active = (i == self->_selectedIndex);
            UIView *slot = self->_itemContainers[i];
            FougoVectorIconView *ic = self->_itemIcons[i];
            UILabel *lb = self->_itemLabels[i];

            slot.transform = active ? CGAffineTransformMakeScale(1.04, 1.04) : CGAffineTransformIdentity;
            ic.strokeColor = active
                ? [UIColor colorWithRed:0.68 green:0.95 blue:1.0 alpha:1.0]
                : [UIColor colorWithWhite:0.75 alpha:0.62];
            lb.textColor = active
                ? [UIColor whiteColor]
                : [UIColor colorWithWhite:0.75 alpha:0.58];
        }
    };

    if (animated) {
        [UIView animateWithDuration:0.32 delay:0 usingSpringWithDamping:0.78 initialSpringVelocity:0.8 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:applyBlock completion:nil];
    } else {
        applyBlock();
    }
}

- (void)handleTouchAtPoint:(CGPoint)pt ended:(BOOL)ended {
    CGFloat slotW = MAX(1.0, self.bounds.size.width / 3.0);
    NSInteger idx = MAX(0, MIN(2, (NSInteger)(pt.x / slotW)));

    [UIView animateWithDuration:0.18 delay:0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
        self->_activeLensPill.transform = ended ? CGAffineTransformIdentity : CGAffineTransformMakeScale(1.04, 0.95);
    } completion:nil];

    if (idx != _selectedIndex || ended) {
        _selectedIndex = idx;
        [self refreshActiveNavVisualsAnimated:YES];
        if (ended) {
            [self.delegate liquidBottomNavDidSelectIndex:idx];
        }
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = [touches anyObject];
    [self handleTouchAtPoint:[t locationInView:self] ended:NO];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = [touches anyObject];
    [self handleTouchAtPoint:[t locationInView:self] ended:NO];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = [touches anyObject];
    [self handleTouchAtPoint:[t locationInView:self] ended:YES];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [UIView animateWithDuration:0.25 animations:^{
        self->_activeLensPill.transform = CGAffineTransformIdentity;
    }];
}

@end

// ============================================================================
// Main Dashboard View Controller — FOUGO EXTERNAL
// ============================================================================
@interface FougoDashboardViewController : UIViewController <FougoLiquidBottomNavDelegate>
@property (nonatomic, strong) UILabel *topKickerLabel;
@property (nonatomic, strong) UILabel *brandHeaderLabel;

// Tab 0: HOME (License & Device Telemetry)
@property (nonatomic, strong) UIVisualEffectView *homeGlassPanel;
@property (nonatomic, strong) UILabel *licKeyValLabel;
@property (nonatomic, strong) UILabel *licPlanValLabel;
@property (nonatomic, strong) UILabel *licExpValLabel;
@property (nonatomic, strong) UILabel *licHwidValLabel;
@property (nonatomic, strong) UIButton *copyHwidButton;

// Tab 1: GAMES (Select Game + Module Control)
@property (nonatomic, strong) UIView *gamesViewport;
@property (nonatomic, strong) FougoLiquidGameCard *freeFireCard;
@property (nonatomic, strong) FougoLiquidGameCard *freeFireMaxCard;
@property (nonatomic, strong) FougoLiquidGameCard *bodyModuleCard;
@property (nonatomic, strong) FougoLiquidGameCard *neckModuleCard;
@property (nonatomic, strong) UIButton *applyModuleBtn;
@property (nonatomic, strong) UIButton *restoreOriginalBtn;
@property (nonatomic, strong) UILabel *moduleStatusBanner;

// Tab 2: SETTINGS
@property (nonatomic, strong) UIVisualEffectView *settingsGlassPanel;
@property (nonatomic, strong) UISwitch *refractionSwitch;
@property (nonatomic, strong) UISwitch *depthReactionSwitch;
@property (nonatomic, strong) UISlider *distortionSlider;
@property (nonatomic, strong) UIButton *logoutKeyButton;

@property (nonatomic, strong) FougoLiquidBottomNav *bottomNav;
@property (nonatomic, assign) NSInteger activeTabIndex;
@property (nonatomic, copy) NSString *selectedGameName;
@property (nonatomic, copy) NSString *selectedModuleName;
@end

@implementation FougoDashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.activeTabIndex = 1;
    self.selectedGameName = @"FREE FIRE MAX";
    self.selectedModuleName = @"BODY";

    [self setupDarkAtmosphericSurface];
    [self setupDashboardHeader];
    [self setupHomeLicenseSurface];
    [self setupGamesAndModuleWorkspace];
    [self setupSettingsGlassSurface];
    [self setupFloatingLiquidBottomNav];
    [self liquidBottomNavDidSelectIndex:1];
}

- (void)setupDarkAtmosphericSurface {
    self.view.backgroundColor = [UIColor colorWithRed:0.02 green:0.04 blue:0.09 alpha:1.0];

    CAGradientLayer *bg = [CAGradientLayer layer];
    bg.name = @"fougo_dash_bg";
    bg.frame = [UIScreen mainScreen].bounds;
    bg.colors = @[
        (id)[UIColor colorWithRed:0.03 green:0.06 blue:0.13 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.05 green:0.10 blue:0.19 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.02 green:0.04 blue:0.08 alpha:1.0].CGColor
    ];
    bg.startPoint = CGPointMake(0.2, 0.0);
    bg.endPoint = CGPointMake(0.8, 1.0);
    [self.view.layer insertSublayer:bg atIndex:0];
}

- (void)setupDashboardHeader {
    self.topKickerLabel = [[UILabel alloc] init];
    self.topKickerLabel.text = @"FOUGO EXTERNAL • LOCAL CONTROL";
    self.topKickerLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightBold];
    self.topKickerLabel.textColor = [UIColor colorWithRed:0.55 green:0.90 blue:1.0 alpha:0.92];
    self.topKickerLabel.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:self.topKickerLabel];

    self.brandHeaderLabel = [[UILabel alloc] init];
    self.brandHeaderLabel.text = @"SELECT GAME";
    self.brandHeaderLabel.font = [UIFont systemFontOfSize:26.0 weight:UIFontWeightHeavy];
    self.brandHeaderLabel.textColor = [UIColor whiteColor];
    self.brandHeaderLabel.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:self.brandHeaderLabel];
}

- (void)setupHomeLicenseSurface {
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
    self.homeGlassPanel = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.homeGlassPanel.layer.cornerRadius = 26.0;
    self.homeGlassPanel.layer.masksToBounds = YES;
    self.homeGlassPanel.layer.borderWidth = 1.2;
    self.homeGlassPanel.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
    self.homeGlassPanel.alpha = 0.0;
    self.homeGlassPanel.hidden = YES;
    [self.view addSubview:self.homeGlassPanel];

    UIView *hc = self.homeGlassPanel.contentView;

    NSString *savedKey = [[NSUserDefaults standardUserDefaults] stringForKey:@"FougoActivatedKey"] ?: @"FOUGO-VIP-ACTIVE";
    NSString *idfv = [UIDevice currentDevice].identifierForVendor.UUIDString ?: @"IOS-ARM64-VERIFIED";

    NSArray *titles = @[@"LICENSE KEY", @"ACTIVE PLAN", @"EXPIRATION", @"DEVICE HWID"];
    NSArray *defaults = @[savedKey, @"30 DAYS VIP", @"ACTIVE • VERIFIED", [idfv substringToIndex:MIN(18, idfv.length)]];

    for (NSInteger i = 0; i < 4; i++) {
        UILabel *tLb = [[UILabel alloc] init];
        tLb.text = titles[i];
        tLb.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightBold];
        tLb.textColor = [UIColor colorWithRed:0.58 green:0.90 blue:1.0 alpha:0.80];
        tLb.tag = 710 + i;
        [hc addSubview:tLb];

        UILabel *vLb = [[UILabel alloc] init];
        vLb.text = defaults[i];
        vLb.font = [UIFont monospacedSystemFontOfSize:14.0 weight:UIFontWeightBold];
        vLb.textColor = [UIColor whiteColor];
        vLb.tag = 720 + i;
        [hc addSubview:vLb];
    }

    self.copyHwidButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.copyHwidButton setTitle:@"COPY DEVICE HWID" forState:UIControlStateNormal];
    self.copyHwidButton.titleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightBold];
    self.copyHwidButton.backgroundColor = [UIColor colorWithRed:0.18 green:0.76 blue:0.98 alpha:0.22];
    self.copyHwidButton.layer.cornerRadius = 14.0;
    self.copyHwidButton.layer.borderWidth = 1.0;
    self.copyHwidButton.layer.borderColor = [UIColor colorWithRed:0.50 green:0.92 blue:1.0 alpha:0.55].CGColor;
    [self.copyHwidButton addTarget:self action:@selector(handleCopyHwid) forControlEvents:UIControlEventTouchUpInside];
    [hc addSubview:self.copyHwidButton];
}

- (void)setupGamesAndModuleWorkspace {
    self.gamesViewport = [[UIView alloc] init];
    self.gamesViewport.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.gamesViewport];

    self.freeFireCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                             title:@"FREE FIRE"
                                                          subtitle:@"Standard Target Profile"
                                                          iconType:FougoVectorIconCrosshair];
    self.freeFireCard.isSelectedCard = NO;
    [self.freeFireCard addTarget:self action:@selector(selectFreeFireCard) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.freeFireCard];

    self.freeFireMaxCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                                title:@"FREE FIRE MAX"
                                                             subtitle:@"Enhanced Resolution Target"
                                                             iconType:FougoVectorIconLayers];
    self.freeFireMaxCard.isSelectedCard = YES;
    [self.freeFireMaxCard addTarget:self action:@selector(selectFreeFireMaxCard) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.freeFireMaxCard];

    self.bodyModuleCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                               title:@"BODY"
                                                            subtitle:@"Primary Calibration"
                                                            iconType:FougoVectorIconShield];
    self.bodyModuleCard.isSelectedCard = YES;
    [self.bodyModuleCard addTarget:self action:@selector(selectBodyModule) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.bodyModuleCard];

    self.neckModuleCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                               title:@"NECK"
                                                            subtitle:@"Upper Calibration"
                                                            iconType:FougoVectorIconCrosshair];
    self.neckModuleCard.isSelectedCard = NO;
    [self.neckModuleCard addTarget:self action:@selector(selectNeckModule) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.neckModuleCard];

    self.applyModuleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.applyModuleBtn setTitle:@"APPLY SELECTED" forState:UIControlStateNormal];
    self.applyModuleBtn.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightBold];
    self.applyModuleBtn.backgroundColor = [UIColor colorWithRed:0.14 green:0.74 blue:0.96 alpha:0.92];
    self.applyModuleBtn.layer.cornerRadius = 16.0;
    self.applyModuleBtn.layer.borderWidth = 1.0;
    self.applyModuleBtn.layer.borderColor = [UIColor colorWithRed:0.65 green:0.94 blue:1.0 alpha:0.60].CGColor;
    [self.applyModuleBtn addTarget:self action:@selector(handleApplySelectedModule) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.applyModuleBtn];

    self.restoreOriginalBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.restoreOriginalBtn setTitle:@"RESTORE ORIGINAL" forState:UIControlStateNormal];
    self.restoreOriginalBtn.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightBold];
    self.restoreOriginalBtn.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.07];
    self.restoreOriginalBtn.layer.cornerRadius = 16.0;
    self.restoreOriginalBtn.layer.borderWidth = 1.0;
    self.restoreOriginalBtn.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
    [self.restoreOriginalBtn addTarget:self action:@selector(handleRestoreOriginal) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.restoreOriginalBtn];

    self.moduleStatusBanner = [[UILabel alloc] init];
    self.moduleStatusBanner.text = @"STATE: READY • FREE FIRE MAX (BODY)";
    self.moduleStatusBanner.font = [UIFont monospacedSystemFontOfSize:11.0 weight:UIFontWeightBold];
    self.moduleStatusBanner.textColor = [UIColor colorWithRed:0.58 green:0.92 blue:1.0 alpha:0.92];
    self.moduleStatusBanner.textAlignment = NSTextAlignmentCenter;
    [self.gamesViewport addSubview:self.moduleStatusBanner];
}

- (void)setupSettingsGlassSurface {
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
    self.settingsGlassPanel = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.settingsGlassPanel.layer.cornerRadius = 26.0;
    self.settingsGlassPanel.layer.masksToBounds = YES;
    self.settingsGlassPanel.layer.borderWidth = 1.2;
    self.settingsGlassPanel.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
    self.settingsGlassPanel.alpha = 0.0;
    self.settingsGlassPanel.hidden = YES;
    [self.view addSubview:self.settingsGlassPanel];

    UIView *sc = self.settingsGlassPanel.contentView;

    FougoVectorIconView *settingsLead = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(24, 24, 22, 22) iconType:FougoVectorIconSliders];
    settingsLead.strokeColor = [UIColor colorWithRed:0.65 green:0.93 blue:1.0 alpha:0.95];
    [sc addSubview:settingsLead];

    UILabel *row1 = [[UILabel alloc] initWithFrame:CGRectMake(58, 22, 220, 26)];
    row1.text = @"SURFACE PREFERENCES";
    row1.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightBold];
    row1.textColor = [UIColor whiteColor];
    [sc addSubview:row1];

    UILabel *r1Title = [[UILabel alloc] init];
    r1Title.text = @"REFRACTION SURFACE";
    r1Title.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    r1Title.textColor = [UIColor colorWithWhite:0.88 alpha:0.9];
    r1Title.tag = 601;
    [sc addSubview:r1Title];

    self.refractionSwitch = [[UISwitch alloc] init];
    self.refractionSwitch.on = YES;
    self.refractionSwitch.onTintColor = [UIColor colorWithRed:0.20 green:0.78 blue:0.96 alpha:1.0];
    [sc addSubview:self.refractionSwitch];

    UILabel *r2Title = [[UILabel alloc] init];
    r2Title.text = @"GLASS DEPTH";
    r2Title.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    r2Title.textColor = [UIColor colorWithWhite:0.88 alpha:0.9];
    r2Title.tag = 602;
    [sc addSubview:r2Title];

    self.depthReactionSwitch = [[UISwitch alloc] init];
    self.depthReactionSwitch.on = YES;
    self.depthReactionSwitch.onTintColor = [UIColor colorWithRed:0.20 green:0.78 blue:0.96 alpha:1.0];
    [sc addSubview:self.depthReactionSwitch];

    self.distortionSlider = [[UISlider alloc] init];
    self.distortionSlider.minimumValue = 0.2;
    self.distortionSlider.maximumValue = 1.0;
    self.distortionSlider.value = 0.85;
    self.distortionSlider.minimumTrackTintColor = [UIColor colorWithRed:0.35 green:0.86 blue:1.0 alpha:1.0];
    [sc addSubview:self.distortionSlider];

    self.logoutKeyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.logoutKeyButton setTitle:@"SIGN OUT LICENSE KEY" forState:UIControlStateNormal];
    self.logoutKeyButton.titleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightBold];
    self.logoutKeyButton.backgroundColor = [UIColor colorWithRed:1.0 green:0.32 blue:0.42 alpha:0.18];
    self.logoutKeyButton.layer.cornerRadius = 14.0;
    self.logoutKeyButton.layer.borderWidth = 1.0;
    self.logoutKeyButton.layer.borderColor = [UIColor colorWithRed:1.0 green:0.40 blue:0.50 alpha:0.45].CGColor;
    [self.logoutKeyButton addTarget:self action:@selector(handleLogoutLicense) forControlEvents:UIControlEventTouchUpInside];
    [sc addSubview:self.logoutKeyButton];
}

- (void)setupFloatingLiquidBottomNav {
    self.bottomNav = [[FougoLiquidBottomNav alloc] initWithFrame:CGRectMake(24, self.view.bounds.size.height - 90, self.view.bounds.size.width - 48, 62)];
    self.bottomNav.delegate = self;
    [self.view addSubview:self.bottomNav];
}

#pragma mark - Actions

- (void)selectFreeFireCard {
    self.selectedGameName = @"FREE FIRE";
    self.freeFireCard.isSelectedCard = YES;
    self.freeFireMaxCard.isSelectedCard = NO;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"TARGET: %@ (%@)", self.selectedGameName, self.selectedModuleName];
}

- (void)selectFreeFireMaxCard {
    self.selectedGameName = @"FREE FIRE MAX";
    self.freeFireCard.isSelectedCard = NO;
    self.freeFireMaxCard.isSelectedCard = YES;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"TARGET: %@ (%@)", self.selectedGameName, self.selectedModuleName];
}

- (void)selectBodyModule {
    self.selectedModuleName = @"BODY";
    self.bodyModuleCard.isSelectedCard = YES;
    self.neckModuleCard.isSelectedCard = NO;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"SELECTED: %@ • %@", self.selectedGameName, self.selectedModuleName];
}

- (void)selectNeckModule {
    self.selectedModuleName = @"NECK";
    self.bodyModuleCard.isSelectedCard = NO;
    self.neckModuleCard.isSelectedCard = YES;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"SELECTED: %@ • %@", self.selectedGameName, self.selectedModuleName];
}

- (void)handleApplySelectedModule {
    self.moduleStatusBanner.textColor = [UIColor colorWithRed:0.35 green:0.98 blue:0.78 alpha:1.0];
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"APPLIED: %@ ON %@", self.selectedModuleName, self.selectedGameName];
}

- (void)handleRestoreOriginal {
    self.moduleStatusBanner.textColor = [UIColor colorWithRed:0.58 green:0.92 blue:1.0 alpha:0.92];
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"RESTORED ORIGINAL: %@", self.selectedGameName];
}

- (void)handleCopyHwid {
    NSString *idfv = [UIDevice currentDevice].identifierForVendor.UUIDString ?: @"IOS-ARM64-DEVICE";
    [UIPasteboard generalPasteboard].string = idfv;
    [self.copyHwidButton setTitle:@"HWID COPIED TO CLIPBOARD" forState:UIControlStateNormal];
}

- (void)handleLogoutLicense {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"FougoActivatedKey"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self liquidBottomNavDidSelectIndex:0];
}

- (void)liquidBottomNavDidSelectIndex:(NSInteger)index {
    self.activeTabIndex = index;
    if (index == 0) {
        self.brandHeaderLabel.text = @"LICENSE STATUS";
        self.homeGlassPanel.hidden = NO;
    } else if (index == 1) {
        self.brandHeaderLabel.text = @"SELECT GAME";
        self.gamesViewport.hidden = NO;
    } else {
        self.brandHeaderLabel.text = @"SETTINGS";
        self.settingsGlassPanel.hidden = NO;
    }

    [UIView animateWithDuration:0.30 delay:0 usingSpringWithDamping:0.80 initialSpringVelocity:0.8 options:UIViewAnimationOptionAllowUserInteraction animations:^{
        self.homeGlassPanel.alpha = (index == 0) ? 1.0 : 0.0;
        self.gamesViewport.alpha = (index == 1) ? 1.0 : 0.0;
        self.settingsGlassPanel.alpha = (index == 2) ? 1.0 : 0.0;
    } completion:^(BOOL finished) {
        self.homeGlassPanel.hidden = (index != 0);
        self.gamesViewport.hidden = (index != 1);
        self.settingsGlassPanel.hidden = (index != 2);
    }];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect b = self.view.bounds;
    for (CALayer *l in self.view.layer.sublayers) {
        if ([l.name isEqualToString:@"fougo_dash_bg"]) {
            l.frame = b;
        }
    }

    CGFloat topSafe = 50.0;
    CGFloat bottomSafe = 22.0;
    if (@available(iOS 11.0, *)) {
        topSafe = MAX(44.0, self.view.safeAreaInsets.top + 14.0);
        bottomSafe = MAX(18.0, self.view.safeAreaInsets.bottom + 8.0);
    }

    CGFloat contentW = MIN(b.size.width - 36.0, 396.0);
    CGFloat contentX = (b.size.width - contentW) * 0.5;

    self.topKickerLabel.frame = CGRectMake(contentX, topSafe, contentW, 16.0);
    self.brandHeaderLabel.frame = CGRectMake(contentX, topSafe + 20.0, contentW, 34.0);

    CGFloat navH = 62.0;
    CGFloat navY = b.size.height - bottomSafe - navH;
    self.bottomNav.frame = CGRectMake(contentX, navY, contentW, navH);

    CGFloat availTop = CGRectGetMaxY(self.brandHeaderLabel.frame) + 18.0;
    CGFloat availH = navY - availTop - 16.0;

    // Tab 0: Home Panel
    CGFloat homeH = MIN(310.0, availH);
    self.homeGlassPanel.frame = CGRectMake(contentX, availTop + (availH - homeH) * 0.5, contentW, homeH);
    UIView *hc = self.homeGlassPanel.contentView;
    for (NSInteger i = 0; i < 4; i++) {
        CGFloat rowY = 22.0 + i * 54.0;
        [hc viewWithTag:710 + i].frame = CGRectMake(24, rowY, contentW - 48, 14);
        [hc viewWithTag:720 + i].frame = CGRectMake(24, rowY + 16.0, contentW - 48, 22);
    }
    self.copyHwidButton.frame = CGRectMake(24, homeH - 58.0, contentW - 48, 42.0);

    // Tab 1: Games & Modules Viewport
    self.gamesViewport.frame = CGRectMake(contentX, availTop, contentW, availH);
    CGFloat gameCardH = 82.0;
    self.freeFireCard.frame = CGRectMake(0, 0, contentW, gameCardH);
    self.freeFireMaxCard.frame = CGRectMake(0, gameCardH + 12.0, contentW, gameCardH);

    CGFloat modY = (gameCardH + 12.0) * 2.0 + 4.0;
    CGFloat halfW = (contentW - 12.0) * 0.5;
    self.bodyModuleCard.frame = CGRectMake(0, modY, halfW, 74.0);
    self.neckModuleCard.frame = CGRectMake(halfW + 12.0, modY, halfW, 74.0);

    CGFloat btnY = modY + 88.0;
    self.applyModuleBtn.frame = CGRectMake(0, btnY, halfW, 48.0);
    self.restoreOriginalBtn.frame = CGRectMake(halfW + 12.0, btnY, halfW, 48.0);
    self.moduleStatusBanner.frame = CGRectMake(0, btnY + 56.0, contentW, 20.0);

    // Tab 2: Settings Panel
    CGFloat panelH = 280.0;
    self.settingsGlassPanel.frame = CGRectMake(contentX, availTop + MAX(0.0, (availH - panelH) * 0.5), contentW, panelH);

    UIView *sc = self.settingsGlassPanel.contentView;
    [sc viewWithTag:601].frame = CGRectMake(24, 74, contentW - 100, 28);
    self.refractionSwitch.frame = CGRectMake(contentW - 76, 72, 51, 31);
    [sc viewWithTag:602].frame = CGRectMake(24, 122, contentW - 100, 28);
    self.depthReactionSwitch.frame = CGRectMake(contentW - 76, 120, 51, 31);
    self.distortionSlider.frame = CGRectMake(24, 168, contentW - 48, 30);
    self.logoutKeyButton.frame = CGRectMake(24, 216, contentW - 48, 42);
}

@end

@interface FougoDashboardAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation FougoDashboardAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[FougoDashboardViewController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FougoDashboardAppDelegate class]));
    }
}
