#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
#import <math.h>
#import "ProtectedConfig.h"

// ============================================================================
// FOUGO EXTERNAL — Frosted Liquid-Glass Workspace & License Dashboard
// ============================================================================

typedef NS_ENUM(NSInteger, FougoVectorIconType) {
    FougoVectorIconHome = 0,
    FougoVectorIconGames = 1,
    FougoVectorIconSettings = 2,
    FougoVectorIconCrosshair = 3,
    FougoVectorIconLayers = 4,
    FougoVectorIconChevronRight = 5,
    FougoVectorIconSliders = 6,
    FougoVectorIconShield = 7
};

@interface FougoVectorIconView : UIView
@property (nonatomic, assign) FougoVectorIconType iconType;
@property (nonatomic, strong) UIColor *strokeColor;
@property (nonatomic, assign) CGFloat lineWidth;
- (instancetype)initWithFrame:(CGRect)frame iconType:(FougoVectorIconType)type;
@end

@implementation FougoVectorIconView {
    CAShapeLayer *_shapeLayer;
}

- (instancetype)initWithFrame:(CGRect)frame iconType:(FougoVectorIconType)type {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        _iconType = type;
        _strokeColor = [UIColor colorWithWhite:0.92 alpha:0.90];
        _lineWidth = 1.75;

        _shapeLayer = [CAShapeLayer layer];
        _shapeLayer.fillColor = [UIColor clearColor].CGColor;
        _shapeLayer.strokeColor = _strokeColor.CGColor;
        _shapeLayer.lineWidth = _lineWidth;
        _shapeLayer.lineCap = kCALineCapRound;
        _shapeLayer.lineJoin = kCALineJoinRound;
        [self.layer addSublayer:_shapeLayer];
    }
    return self;
}

- (void)setStrokeColor:(UIColor *)strokeColor {
    _strokeColor = strokeColor;
    _shapeLayer.strokeColor = strokeColor.CGColor;
}

- (void)setLineWidth:(CGFloat)lineWidth {
    _lineWidth = lineWidth;
    _shapeLayer.lineWidth = lineWidth;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _shapeLayer.frame = self.bounds;
    _shapeLayer.path = [self buildVectorPathInRect:self.bounds].CGPath;
}

- (UIBezierPath *)buildVectorPathInRect:(CGRect)rect {
    CGFloat w = rect.size.width;
    CGFloat h = rect.size.height;
    UIBezierPath *p = [UIBezierPath bezierPath];
    if (w <= 0 || h <= 0) return p;

    switch (_iconType) {
        case FougoVectorIconHome: {
            [p moveToPoint:CGPointMake(w * 0.14, h * 0.46)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.14)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.46)];
            [p moveToPoint:CGPointMake(w * 0.24, h * 0.42)];
            [p addLineToPoint:CGPointMake(w * 0.24, h * 0.84)];
            [p addLineToPoint:CGPointMake(w * 0.76, h * 0.84)];
            [p addLineToPoint:CGPointMake(w * 0.76, h * 0.42)];
            [p moveToPoint:CGPointMake(w * 0.42, h * 0.84)];
            [p addLineToPoint:CGPointMake(w * 0.42, h * 0.58)];
            [p addLineToPoint:CGPointMake(w * 0.58, h * 0.58)];
            [p addLineToPoint:CGPointMake(w * 0.58, h * 0.84)];
            break;
        }
        case FougoVectorIconGames: {
            CGFloat r = w * 0.08;
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.15, h * 0.15, w * 0.30, h * 0.30) cornerRadius:r]];
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.55, h * 0.15, w * 0.30, h * 0.30) cornerRadius:r]];
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.15, h * 0.55, w * 0.30, h * 0.30) cornerRadius:r]];
            [p appendPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(w * 0.55, h * 0.55, w * 0.30, h * 0.30) cornerRadius:r]];
            break;
        }
        case FougoVectorIconSettings: {
            CGPoint c = CGPointMake(w * 0.5, h * 0.5);
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.16 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.30 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            for (NSInteger i = 0; i < 6; i++) {
                CGFloat ang = (CGFloat)i * (M_PI / 3.0);
                CGPoint p1 = CGPointMake(c.x + cos(ang) * (w * 0.30), c.y + sin(ang) * (h * 0.30));
                CGPoint p2 = CGPointMake(c.x + cos(ang) * (w * 0.41), c.y + sin(ang) * (h * 0.41));
                [p moveToPoint:p1];
                [p addLineToPoint:p2];
            }
            break;
        }
        case FougoVectorIconCrosshair: {
            CGPoint c = CGPointMake(w * 0.5, h * 0.5);
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.32 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:c radius:w * 0.06 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p moveToPoint:CGPointMake(c.x, h * 0.08)];
            [p addLineToPoint:CGPointMake(c.x, h * 0.24)];
            [p moveToPoint:CGPointMake(c.x, h * 0.76)];
            [p addLineToPoint:CGPointMake(c.x, h * 0.92)];
            [p moveToPoint:CGPointMake(w * 0.08, c.y)];
            [p addLineToPoint:CGPointMake(w * 0.24, c.y)];
            [p moveToPoint:CGPointMake(w * 0.76, c.y)];
            [p addLineToPoint:CGPointMake(w * 0.92, c.y)];
            break;
        }
        case FougoVectorIconLayers: {
            [p moveToPoint:CGPointMake(w * 0.50, h * 0.16)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.34)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.52)];
            [p addLineToPoint:CGPointMake(w * 0.14, h * 0.34)];
            [p closePath];
            [p moveToPoint:CGPointMake(w * 0.14, h * 0.52)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.70)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.52)];
            [p moveToPoint:CGPointMake(w * 0.14, h * 0.68)];
            [p addLineToPoint:CGPointMake(w * 0.50, h * 0.86)];
            [p addLineToPoint:CGPointMake(w * 0.86, h * 0.68)];
            break;
        }
        case FougoVectorIconChevronRight: {
            [p moveToPoint:CGPointMake(w * 0.36, h * 0.22)];
            [p addLineToPoint:CGPointMake(w * 0.66, h * 0.50)];
            [p addLineToPoint:CGPointMake(w * 0.36, h * 0.78)];
            break;
        }
        case FougoVectorIconSliders: {
            [p moveToPoint:CGPointMake(w * 0.16, h * 0.30)];
            [p addLineToPoint:CGPointMake(w * 0.84, h * 0.30)];
            [p moveToPoint:CGPointMake(w * 0.16, h * 0.70)];
            [p addLineToPoint:CGPointMake(w * 0.84, h * 0.70)];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:CGPointMake(w * 0.38, h * 0.30) radius:w * 0.09 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            [p appendPath:[UIBezierPath bezierPathWithArcCenter:CGPointMake(w * 0.64, h * 0.70) radius:w * 0.09 startAngle:0 endAngle:M_PI * 2.0 clockwise:YES]];
            break;
        }
        case FougoVectorIconShield: {
            [p moveToPoint:CGPointMake(w * 0.50, h * 0.12)];
            [p addLineToPoint:CGPointMake(w * 0.84, h * 0.26)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.50, h * 0.88) controlPoint:CGPointMake(w * 0.84, h * 0.68)];
            [p addQuadCurveToPoint:CGPointMake(w * 0.16, h * 0.26) controlPoint:CGPointMake(w * 0.16, h * 0.68)];
            [p closePath];
            break;
        }
    }
    return p;
}

@end

// ============================================================================
// Interactive Frosted Liquid-Glass Game / Module Card
// ============================================================================
@interface FougoLiquidGameCard : UIControl
@property (nonatomic, copy) NSString *gameTitle;
@property (nonatomic, copy) NSString *gameSubtitle;
@property (nonatomic, assign) BOOL isSelectedCard;
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title subtitle:(NSString *)subtitle iconType:(FougoVectorIconType)iconType;
@end

@implementation FougoLiquidGameCard {
    UIVisualEffectView *_blurView;
    UIView *_glassTintView;
    CAGradientLayer *_topSheenLayer;
    UIView *_iconWell;
    FougoVectorIconView *_leadIcon;
    FougoVectorIconView *_chevronIcon;
    UILabel *_titleLabel;
    UILabel *_subtitleLabel;
}

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title subtitle:(NSString *)subtitle iconType:(FougoVectorIconType)iconType {
    self = [super initWithFrame:frame];
    if (self) {
        _gameTitle = [title copy];
        _gameSubtitle = [subtitle copy];
        self.backgroundColor = [UIColor clearColor];
        self.clipsToBounds = NO;

        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 14);
        self.layer.shadowRadius = 24.0;
        self.layer.shadowOpacity = 0.45;

        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
        _blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
        _blurView.frame = self.bounds;
        _blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _blurView.layer.cornerRadius = 24.0;
        _blurView.layer.masksToBounds = YES;
        _blurView.layer.borderWidth = 1.25;
        _blurView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
        _blurView.userInteractionEnabled = NO;
        [self addSubview:_blurView];

        _glassTintView = [[UIView alloc] initWithFrame:self.bounds];
        _glassTintView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _glassTintView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.04];
        _glassTintView.userInteractionEnabled = NO;
        [_blurView.contentView addSubview:_glassTintView];

        _topSheenLayer = [CAGradientLayer layer];
        _topSheenLayer.colors = @[
            (id)[UIColor colorWithWhite:1.0 alpha:0.16].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.03].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor
        ];
        _topSheenLayer.locations = @[@0.0, @0.45, @1.0];
        _topSheenLayer.startPoint = CGPointMake(0.2, 0.0);
        _topSheenLayer.endPoint = CGPointMake(0.8, 1.0);
        [_blurView.contentView.layer addSublayer:_topSheenLayer];

        _iconWell = [[UIView alloc] initWithFrame:CGRectMake(20, 0, 48, 48)];
        _iconWell.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.07];
        _iconWell.layer.cornerRadius = 15.0;
        _iconWell.layer.borderWidth = 1.0;
        _iconWell.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
        _iconWell.userInteractionEnabled = NO;
        [self addSubview:_iconWell];

        _leadIcon = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(12, 12, 24, 24) iconType:iconType];
        _leadIcon.strokeColor = [UIColor colorWithRed:0.65 green:0.93 blue:1.0 alpha:0.95];
        [_iconWell addSubview:_leadIcon];

        _titleLabel = [[UILabel alloc] init];
        _titleLabel.text = _gameTitle;
        _titleLabel.font = [UIFont systemFontOfSize:17.5 weight:UIFontWeightHeavy];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.userInteractionEnabled = NO;
        [self addSubview:_titleLabel];

        _subtitleLabel = [[UILabel alloc] init];
        _subtitleLabel.text = _gameSubtitle;
        _subtitleLabel.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightMedium];
        _subtitleLabel.textColor = [UIColor colorWithWhite:0.74 alpha:0.85];
        _subtitleLabel.userInteractionEnabled = NO;
        [self addSubview:_subtitleLabel];

        _chevronIcon = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(0, 0, 18, 18) iconType:FougoVectorIconChevronRight];
        _chevronIcon.strokeColor = [UIColor colorWithWhite:0.85 alpha:0.65];
        [self addSubview:_chevronIcon];
    }
    return self;
}

- (void)setIsSelectedCard:(BOOL)isSelectedCard {
    _isSelectedCard = isSelectedCard;
    [UIView animateWithDuration:0.25 animations:^{
        if (isSelectedCard) {
            self->_blurView.layer.borderColor = [UIColor colorWithRed:0.45 green:0.90 blue:1.0 alpha:0.82].CGColor;
            self->_glassTintView.backgroundColor = [UIColor colorWithRed:0.16 green:0.64 blue:0.95 alpha:0.16];
            self->_iconWell.backgroundColor = [UIColor colorWithRed:0.25 green:0.80 blue:1.0 alpha:0.18];
            self->_iconWell.layer.borderColor = [UIColor colorWithRed:0.55 green:0.92 blue:1.0 alpha:0.55].CGColor;
        } else {
            self->_blurView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.16].CGColor;
            self->_glassTintView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.04];
            self->_iconWell.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.07];
            self->_iconWell.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
        }
    }];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.bounds;
    _topSheenLayer.frame = b;
    _iconWell.frame = CGRectMake(18, (b.size.height - 48.0) * 0.5, 48.0, 48.0);
    _leadIcon.frame = CGRectMake(12, 12, 24, 24);
    if (_gameSubtitle.length > 0) {
        _titleLabel.frame = CGRectMake(80, b.size.height * 0.5 - 19.0, b.size.width - 120.0, 22.0);
        _subtitleLabel.frame = CGRectMake(80, b.size.height * 0.5 + 3.0, b.size.width - 120.0, 16.0);
    } else {
        _titleLabel.frame = CGRectMake(80, (b.size.height - 24.0) * 0.5, b.size.width - 120.0, 24.0);
        _subtitleLabel.frame = CGRectZero;
    }
    _chevronIcon.frame = CGRectMake(b.size.width - 36.0, (b.size.height - 18.0) * 0.5, 18.0, 18.0);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [UIView animateWithDuration:0.14 delay:0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
        self.transform = CGAffineTransformMakeScale(0.975, 0.975);
    } completion:nil];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    [UIView animateWithDuration:0.32 delay:0 usingSpringWithDamping:0.74 initialSpringVelocity:0.8 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
        self.transform = CGAffineTransformIdentity;
    } completion:nil];
    [self sendActionsForControlEvents:UIControlEventTouchUpInside];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesCancelled:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

@end

// ============================================================================
// Floating Frosted Liquid-Glass Bottom Navigation Bar (HOME | GAMES | SETTINGS)
// ============================================================================
@protocol FougoLiquidBottomNavDelegate <NSObject>
- (void)liquidBottomNavDidSelectIndex:(NSInteger)index;
@end

@interface FougoLiquidBottomNav : UIView
@property (nonatomic, weak) id<FougoLiquidBottomNavDelegate> delegate;
@property (nonatomic, assign) NSInteger selectedIndex;
- (void)setSelectedIndex:(NSInteger)selectedIndex animated:(BOOL)animated;
@end

@implementation FougoLiquidBottomNav {
    UIVisualEffectView *_blurView;
    CAGradientLayer *_topSheenLayer;
    UIView *_activeLensPill;
    NSMutableArray<UIView *> *_itemContainers;
    NSMutableArray<FougoVectorIconView *> *_itemIcons;
    NSMutableArray<UILabel *> *_itemLabels;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.clipsToBounds = NO;
        _selectedIndex = 1;

        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 12);
        self.layer.shadowRadius = 24.0;
        self.layer.shadowOpacity = 0.52;

        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterialDark];
        _blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
        _blurView.frame = self.bounds;
        _blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _blurView.layer.cornerRadius = 31.0;
        _blurView.layer.masksToBounds = YES;
        _blurView.layer.borderWidth = 1.0;
        _blurView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.22].CGColor;
        _blurView.userInteractionEnabled = NO;
        [self addSubview:_blurView];

        _topSheenLayer = [CAGradientLayer layer];
        _topSheenLayer.colors = @[
            (id)[UIColor colorWithWhite:1.0 alpha:0.16].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.02].CGColor,
            (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor
        ];
        _topSheenLayer.locations = @[@0.0, @0.5, @1.0];
        _topSheenLayer.startPoint = CGPointMake(0.5, 0.0);
        _topSheenLayer.endPoint = CGPointMake(0.5, 1.0);
        [_blurView.contentView.layer addSublayer:_topSheenLayer];

        _activeLensPill = [[UIView alloc] init];
        _activeLensPill.backgroundColor = [UIColor colorWithRed:0.35 green:0.84 blue:1.0 alpha:0.18];
        _activeLensPill.layer.cornerRadius = 26.0;
        _activeLensPill.layer.borderWidth = 1.0;
        _activeLensPill.layer.borderColor = [UIColor colorWithRed:0.55 green:0.92 blue:1.0 alpha:0.48].CGColor;
        _activeLensPill.userInteractionEnabled = NO;
        [_blurView.contentView addSubview:_activeLensPill];

        NSArray<NSString *> *titles = @[@"HOME", @"GAMES", @"SETTINGS"];
        NSArray<NSNumber *> *icons = @[
            @(FougoVectorIconHome),
            @(FougoVectorIconGames),
            @(FougoVectorIconSettings)
        ];

        _itemContainers = [NSMutableArray array];
        _itemIcons = [NSMutableArray array];
        _itemLabels = [NSMutableArray array];

        for (NSInteger i = 0; i < 3; i++) {
            UIView *slot = [[UIView alloc] init];
            slot.userInteractionEnabled = NO;
            [_blurView.contentView addSubview:slot];
            [_itemContainers addObject:slot];

            FougoVectorIconView *ic = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(0, 0, 20, 20) iconType:(FougoVectorIconType)[icons[i] integerValue]];
            [slot addSubview:ic];
            [_itemIcons addObject:ic];

            UILabel *lb = [[UILabel alloc] init];
            lb.text = titles[i];
            lb.font = [UIFont systemFontOfSize:10.0 weight:UIFontWeightBold];
            lb.textAlignment = NSTextAlignmentCenter;
            [slot addSubview:lb];
            [_itemLabels addObject:lb];
        }

        [self refreshActiveNavVisualsAnimated:NO];
    }
    return self;
}

- (void)setSelectedIndex:(NSInteger)selectedIndex animated:(BOOL)animated {
    _selectedIndex = MAX(0, MIN(2, selectedIndex));
    [self refreshActiveNavVisualsAnimated:animated];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect b = self.bounds;
    _blurView.layer.cornerRadius = b.size.height * 0.5;
    _topSheenLayer.frame = b;

    CGFloat slotW = b.size.width / 3.0;
    for (NSInteger i = 0; i < 3; i++) {
        UIView *slot = _itemContainers[i];
        slot.frame = CGRectMake(slotW * i, 0, slotW, b.size.height);

        FougoVectorIconView *ic = _itemIcons[i];
        ic.frame = CGRectMake((slotW - 20.0) * 0.5, 11.0, 20.0, 20.0);

        UILabel *lb = _itemLabels[i];
        lb.frame = CGRectMake(4.0, 35.0, slotW - 8.0, 14.0);
    }

    CGFloat pillW = slotW - 12.0;
    CGFloat pillH = b.size.height - 10.0;
    _activeLensPill.frame = CGRectMake(slotW * _selectedIndex + 6.0, 5.0, pillW, pillH);
    _activeLensPill.layer.cornerRadius = pillH * 0.5;
}

- (void)refreshActiveNavVisualsAnimated:(BOOL)animated {
    CGRect b = self.bounds;
    CGFloat slotW = b.size.width / 3.0;
    CGFloat pillW = MAX(56.0, slotW - 12.0);
    CGFloat pillH = MAX(38.0, b.size.height - 10.0);

    void (^applyBlock)(void) = ^{
        if (b.size.width > 0) {
            self->_activeLensPill.frame = CGRectMake(slotW * self->_selectedIndex + 6.0, 5.0, pillW, pillH);
            self->_activeLensPill.layer.cornerRadius = pillH * 0.5;
        }
        for (NSInteger i = 0; i < 3; i++) {
            BOOL active = (i == self->_selectedIndex);
            UIView *slot = self->_itemContainers[i];
            FougoVectorIconView *ic = self->_itemIcons[i];
            UILabel *lb = self->_itemLabels[i];

            slot.transform = active ? CGAffineTransformMakeScale(1.04, 1.04) : CGAffineTransformIdentity;
            ic.strokeColor = active
                ? [UIColor colorWithRed:0.68 green:0.95 blue:1.0 alpha:1.0]
                : [UIColor colorWithWhite:0.75 alpha:0.62];
            lb.textColor = active
                ? [UIColor whiteColor]
                : [UIColor colorWithWhite:0.75 alpha:0.58];
        }
    };

    if (animated) {
        [UIView animateWithDuration:0.32 delay:0 usingSpringWithDamping:0.78 initialSpringVelocity:0.8 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:applyBlock completion:nil];
    } else {
        applyBlock();
    }
}

- (void)handleTouchAtPoint:(CGPoint)pt ended:(BOOL)ended {
    CGFloat slotW = MAX(1.0, self.bounds.size.width / 3.0);
    NSInteger idx = MAX(0, MIN(2, (NSInteger)(pt.x / slotW)));

    [UIView animateWithDuration:0.18 delay:0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
        self->_activeLensPill.transform = ended ? CGAffineTransformIdentity : CGAffineTransformMakeScale(1.04, 0.95);
    } completion:nil];

    if (idx != _selectedIndex || ended) {
        _selectedIndex = idx;
        [self refreshActiveNavVisualsAnimated:YES];
        if (ended) {
            [self.delegate liquidBottomNavDidSelectIndex:idx];
        }
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = [touches anyObject];
    [self handleTouchAtPoint:[t locationInView:self] ended:NO];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = [touches anyObject];
    [self handleTouchAtPoint:[t locationInView:self] ended:NO];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = [touches anyObject];
    [self handleTouchAtPoint:[t locationInView:self] ended:YES];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [UIView animateWithDuration:0.25 animations:^{
        self->_activeLensPill.transform = CGAffineTransformIdentity;
    }];
}

@end

// ============================================================================
// Main Dashboard View Controller — FOUGO EXTERNAL
// ============================================================================
@interface FougoDashboardViewController : UIViewController <FougoLiquidBottomNavDelegate>
@property (nonatomic, strong) UILabel *topKickerLabel;
@property (nonatomic, strong) UILabel *brandHeaderLabel;

// Tab 0: HOME (License & Device Telemetry)
@property (nonatomic, strong) UIVisualEffectView *homeGlassPanel;
@property (nonatomic, strong) UILabel *licKeyValLabel;
@property (nonatomic, strong) UILabel *licPlanValLabel;
@property (nonatomic, strong) UILabel *licExpValLabel;
@property (nonatomic, strong) UILabel *licHwidValLabel;
@property (nonatomic, strong) UIButton *copyHwidButton;

// Tab 1: GAMES (Select Game + Module Control)
@property (nonatomic, strong) UIView *gamesViewport;
@property (nonatomic, strong) FougoLiquidGameCard *freeFireCard;
@property (nonatomic, strong) FougoLiquidGameCard *freeFireMaxCard;
@property (nonatomic, strong) FougoLiquidGameCard *bodyModuleCard;
@property (nonatomic, strong) FougoLiquidGameCard *neckModuleCard;
@property (nonatomic, strong) UIButton *applyModuleBtn;
@property (nonatomic, strong) UIButton *restoreOriginalBtn;
@property (nonatomic, strong) UILabel *moduleStatusBanner;

// Tab 2: SETTINGS
@property (nonatomic, strong) UIVisualEffectView *settingsGlassPanel;
@property (nonatomic, strong) UISwitch *refractionSwitch;
@property (nonatomic, strong) UISwitch *depthReactionSwitch;
@property (nonatomic, strong) UISlider *distortionSlider;
@property (nonatomic, strong) UIButton *logoutKeyButton;

@property (nonatomic, strong) FougoLiquidBottomNav *bottomNav;
@property (nonatomic, assign) NSInteger activeTabIndex;
@property (nonatomic, copy) NSString *selectedGameName;
@property (nonatomic, copy) NSString *selectedModuleName;
@end

@implementation FougoDashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.activeTabIndex = 1;
    self.selectedGameName = @"FREE FIRE MAX";
    self.selectedModuleName = @"BODY";

    [self setupDarkAtmosphericSurface];
    [self setupDashboardHeader];
    [self setupHomeLicenseSurface];
    [self setupGamesAndModuleWorkspace];
    [self setupSettingsGlassSurface];
    [self setupFloatingLiquidBottomNav];
    [self liquidBottomNavDidSelectIndex:1];
}

- (void)setupDarkAtmosphericSurface {
    self.view.backgroundColor = [UIColor colorWithRed:0.02 green:0.04 blue:0.09 alpha:1.0];

    CAGradientLayer *bg = [CAGradientLayer layer];
    bg.name = @"fougo_dash_bg";
    bg.frame = [UIScreen mainScreen].bounds;
    bg.colors = @[
        (id)[UIColor colorWithRed:0.03 green:0.06 blue:0.13 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.05 green:0.10 blue:0.19 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.02 green:0.04 blue:0.08 alpha:1.0].CGColor
    ];
    bg.startPoint = CGPointMake(0.2, 0.0);
    bg.endPoint = CGPointMake(0.8, 1.0);
    [self.view.layer insertSublayer:bg atIndex:0];
}

- (void)setupDashboardHeader {
    self.topKickerLabel = [[UILabel alloc] init];
    self.topKickerLabel.text = @"FOUGO EXTERNAL • LOCAL CONTROL";
    self.topKickerLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightBold];
    self.topKickerLabel.textColor = [UIColor colorWithRed:0.55 green:0.90 blue:1.0 alpha:0.92];
    self.topKickerLabel.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:self.topKickerLabel];

    self.brandHeaderLabel = [[UILabel alloc] init];
    self.brandHeaderLabel.text = @"SELECT GAME";
    self.brandHeaderLabel.font = [UIFont systemFontOfSize:26.0 weight:UIFontWeightHeavy];
    self.brandHeaderLabel.textColor = [UIColor whiteColor];
    self.brandHeaderLabel.textAlignment = NSTextAlignmentLeft;
    [self.view addSubview:self.brandHeaderLabel];
}

- (void)setupHomeLicenseSurface {
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
    self.homeGlassPanel = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.homeGlassPanel.layer.cornerRadius = 26.0;
    self.homeGlassPanel.layer.masksToBounds = YES;
    self.homeGlassPanel.layer.borderWidth = 1.2;
    self.homeGlassPanel.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
    self.homeGlassPanel.alpha = 0.0;
    self.homeGlassPanel.hidden = YES;
    [self.view addSubview:self.homeGlassPanel];

    UIView *hc = self.homeGlassPanel.contentView;

    NSString *savedKey = [[NSUserDefaults standardUserDefaults] stringForKey:@"FougoActivatedKey"] ?: @"FOUGO-VIP-ACTIVE";
    NSString *idfv = [UIDevice currentDevice].identifierForVendor.UUIDString ?: @"IOS-ARM64-VERIFIED";

    NSArray *titles = @[@"LICENSE KEY", @"ACTIVE PLAN", @"EXPIRATION", @"DEVICE HWID"];
    NSArray *defaults = @[savedKey, @"30 DAYS VIP", @"ACTIVE • VERIFIED", [idfv substringToIndex:MIN(18, idfv.length)]];

    for (NSInteger i = 0; i < 4; i++) {
        UILabel *tLb = [[UILabel alloc] init];
        tLb.text = titles[i];
        tLb.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightBold];
        tLb.textColor = [UIColor colorWithRed:0.58 green:0.90 blue:1.0 alpha:0.80];
        tLb.tag = 710 + i;
        [hc addSubview:tLb];

        UILabel *vLb = [[UILabel alloc] init];
        vLb.text = defaults[i];
        vLb.font = [UIFont monospacedSystemFontOfSize:14.0 weight:UIFontWeightBold];
        vLb.textColor = [UIColor whiteColor];
        vLb.tag = 720 + i;
        [hc addSubview:vLb];
    }

    self.copyHwidButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.copyHwidButton setTitle:@"COPY DEVICE HWID" forState:UIControlStateNormal];
    self.copyHwidButton.titleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightBold];
    self.copyHwidButton.backgroundColor = [UIColor colorWithRed:0.18 green:0.76 blue:0.98 alpha:0.22];
    self.copyHwidButton.layer.cornerRadius = 14.0;
    self.copyHwidButton.layer.borderWidth = 1.0;
    self.copyHwidButton.layer.borderColor = [UIColor colorWithRed:0.50 green:0.92 blue:1.0 alpha:0.55].CGColor;
    [self.copyHwidButton addTarget:self action:@selector(handleCopyHwid) forControlEvents:UIControlEventTouchUpInside];
    [hc addSubview:self.copyHwidButton];
}

- (void)setupGamesAndModuleWorkspace {
    self.gamesViewport = [[UIView alloc] init];
    self.gamesViewport.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.gamesViewport];

    self.freeFireCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                             title:@"FREE FIRE"
                                                          subtitle:@"Standard Target Profile"
                                                          iconType:FougoVectorIconCrosshair];
    self.freeFireCard.isSelectedCard = NO;
    [self.freeFireCard addTarget:self action:@selector(selectFreeFireCard) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.freeFireCard];

    self.freeFireMaxCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                                title:@"FREE FIRE MAX"
                                                             subtitle:@"Enhanced Resolution Target"
                                                             iconType:FougoVectorIconLayers];
    self.freeFireMaxCard.isSelectedCard = YES;
    [self.freeFireMaxCard addTarget:self action:@selector(selectFreeFireMaxCard) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.freeFireMaxCard];

    self.bodyModuleCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                               title:@"BODY"
                                                            subtitle:@"Primary Calibration"
                                                            iconType:FougoVectorIconShield];
    self.bodyModuleCard.isSelectedCard = YES;
    [self.bodyModuleCard addTarget:self action:@selector(selectBodyModule) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.bodyModuleCard];

    self.neckModuleCard = [[FougoLiquidGameCard alloc] initWithFrame:CGRectZero
                                                               title:@"NECK"
                                                            subtitle:@"Upper Calibration"
                                                            iconType:FougoVectorIconCrosshair];
    self.neckModuleCard.isSelectedCard = NO;
    [self.neckModuleCard addTarget:self action:@selector(selectNeckModule) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.neckModuleCard];

    self.applyModuleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.applyModuleBtn setTitle:@"APPLY SELECTED" forState:UIControlStateNormal];
    self.applyModuleBtn.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightBold];
    self.applyModuleBtn.backgroundColor = [UIColor colorWithRed:0.14 green:0.74 blue:0.96 alpha:0.92];
    self.applyModuleBtn.layer.cornerRadius = 16.0;
    self.applyModuleBtn.layer.borderWidth = 1.0;
    self.applyModuleBtn.layer.borderColor = [UIColor colorWithRed:0.65 green:0.94 blue:1.0 alpha:0.60].CGColor;
    [self.applyModuleBtn addTarget:self action:@selector(handleApplySelectedModule) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.applyModuleBtn];

    self.restoreOriginalBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.restoreOriginalBtn setTitle:@"RESTORE ORIGINAL" forState:UIControlStateNormal];
    self.restoreOriginalBtn.titleLabel.font = [UIFont systemFontOfSize:13.5 weight:UIFontWeightBold];
    self.restoreOriginalBtn.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.07];
    self.restoreOriginalBtn.layer.cornerRadius = 16.0;
    self.restoreOriginalBtn.layer.borderWidth = 1.0;
    self.restoreOriginalBtn.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
    [self.restoreOriginalBtn addTarget:self action:@selector(handleRestoreOriginal) forControlEvents:UIControlEventTouchUpInside];
    [self.gamesViewport addSubview:self.restoreOriginalBtn];

    self.moduleStatusBanner = [[UILabel alloc] init];
    self.moduleStatusBanner.text = @"STATE: READY • FREE FIRE MAX (BODY)";
    self.moduleStatusBanner.font = [UIFont monospacedSystemFontOfSize:11.0 weight:UIFontWeightBold];
    self.moduleStatusBanner.textColor = [UIColor colorWithRed:0.58 green:0.92 blue:1.0 alpha:0.92];
    self.moduleStatusBanner.textAlignment = NSTextAlignmentCenter;
    [self.gamesViewport addSubview:self.moduleStatusBanner];
}

- (void)setupSettingsGlassSurface {
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark];
    self.settingsGlassPanel = [[UIVisualEffectView alloc] initWithEffect:blur];
    self.settingsGlassPanel.layer.cornerRadius = 26.0;
    self.settingsGlassPanel.layer.masksToBounds = YES;
    self.settingsGlassPanel.layer.borderWidth = 1.2;
    self.settingsGlassPanel.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
    self.settingsGlassPanel.alpha = 0.0;
    self.settingsGlassPanel.hidden = YES;
    [self.view addSubview:self.settingsGlassPanel];

    UIView *sc = self.settingsGlassPanel.contentView;

    FougoVectorIconView *settingsLead = [[FougoVectorIconView alloc] initWithFrame:CGRectMake(24, 24, 22, 22) iconType:FougoVectorIconSliders];
    settingsLead.strokeColor = [UIColor colorWithRed:0.65 green:0.93 blue:1.0 alpha:0.95];
    [sc addSubview:settingsLead];

    UILabel *row1 = [[UILabel alloc] initWithFrame:CGRectMake(58, 22, 220, 26)];
    row1.text = @"SURFACE PREFERENCES";
    row1.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightBold];
    row1.textColor = [UIColor whiteColor];
    [sc addSubview:row1];

    UILabel *r1Title = [[UILabel alloc] init];
    r1Title.text = @"REFRACTION SURFACE";
    r1Title.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    r1Title.textColor = [UIColor colorWithWhite:0.88 alpha:0.9];
    r1Title.tag = 601;
    [sc addSubview:r1Title];

    self.refractionSwitch = [[UISwitch alloc] init];
    self.refractionSwitch.on = YES;
    self.refractionSwitch.onTintColor = [UIColor colorWithRed:0.20 green:0.78 blue:0.96 alpha:1.0];
    [sc addSubview:self.refractionSwitch];

    UILabel *r2Title = [[UILabel alloc] init];
    r2Title.text = @"GLASS DEPTH";
    r2Title.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    r2Title.textColor = [UIColor colorWithWhite:0.88 alpha:0.9];
    r2Title.tag = 602;
    [sc addSubview:r2Title];

    self.depthReactionSwitch = [[UISwitch alloc] init];
    self.depthReactionSwitch.on = YES;
    self.depthReactionSwitch.onTintColor = [UIColor colorWithRed:0.20 green:0.78 blue:0.96 alpha:1.0];
    [sc addSubview:self.depthReactionSwitch];

    self.distortionSlider = [[UISlider alloc] init];
    self.distortionSlider.minimumValue = 0.2;
    self.distortionSlider.maximumValue = 1.0;
    self.distortionSlider.value = 0.85;
    self.distortionSlider.minimumTrackTintColor = [UIColor colorWithRed:0.35 green:0.86 blue:1.0 alpha:1.0];
    [sc addSubview:self.distortionSlider];

    self.logoutKeyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.logoutKeyButton setTitle:@"SIGN OUT LICENSE KEY" forState:UIControlStateNormal];
    self.logoutKeyButton.titleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightBold];
    self.logoutKeyButton.backgroundColor = [UIColor colorWithRed:1.0 green:0.32 blue:0.42 alpha:0.18];
    self.logoutKeyButton.layer.cornerRadius = 14.0;
    self.logoutKeyButton.layer.borderWidth = 1.0;
    self.logoutKeyButton.layer.borderColor = [UIColor colorWithRed:1.0 green:0.40 blue:0.50 alpha:0.45].CGColor;
    [self.logoutKeyButton addTarget:self action:@selector(handleLogoutLicense) forControlEvents:UIControlEventTouchUpInside];
    [sc addSubview:self.logoutKeyButton];
}

- (void)setupFloatingLiquidBottomNav {
    self.bottomNav = [[FougoLiquidBottomNav alloc] initWithFrame:CGRectMake(24, self.view.bounds.size.height - 90, self.view.bounds.size.width - 48, 62)];
    self.bottomNav.delegate = self;
    [self.view addSubview:self.bottomNav];
}

#pragma mark - Actions

- (void)selectFreeFireCard {
    self.selectedGameName = @"FREE FIRE";
    self.freeFireCard.isSelectedCard = YES;
    self.freeFireMaxCard.isSelectedCard = NO;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"TARGET: %@ (%@)", self.selectedGameName, self.selectedModuleName];
}

- (void)selectFreeFireMaxCard {
    self.selectedGameName = @"FREE FIRE MAX";
    self.freeFireCard.isSelectedCard = NO;
    self.freeFireMaxCard.isSelectedCard = YES;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"TARGET: %@ (%@)", self.selectedGameName, self.selectedModuleName];
}

- (void)selectBodyModule {
    self.selectedModuleName = @"BODY";
    self.bodyModuleCard.isSelectedCard = YES;
    self.neckModuleCard.isSelectedCard = NO;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"SELECTED: %@ • %@", self.selectedGameName, self.selectedModuleName];
}

- (void)selectNeckModule {
    self.selectedModuleName = @"NECK";
    self.bodyModuleCard.isSelectedCard = NO;
    self.neckModuleCard.isSelectedCard = YES;
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"SELECTED: %@ • %@", self.selectedGameName, self.selectedModuleName];
}

- (void)handleApplySelectedModule {
    self.moduleStatusBanner.textColor = [UIColor colorWithRed:0.35 green:0.98 blue:0.78 alpha:1.0];
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"APPLIED: %@ ON %@", self.selectedModuleName, self.selectedGameName];
}

- (void)handleRestoreOriginal {
    self.moduleStatusBanner.textColor = [UIColor colorWithRed:0.58 green:0.92 blue:1.0 alpha:0.92];
    self.moduleStatusBanner.text = [NSString stringWithFormat:@"RESTORED ORIGINAL: %@", self.selectedGameName];
}

- (void)handleCopyHwid {
    NSString *idfv = [UIDevice currentDevice].identifierForVendor.UUIDString ?: @"IOS-ARM64-DEVICE";
    [UIPasteboard generalPasteboard].string = idfv;
    [self.copyHwidButton setTitle:@"HWID COPIED TO CLIPBOARD" forState:UIControlStateNormal];
}

- (void)handleLogoutLicense {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"FougoActivatedKey"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self liquidBottomNavDidSelectIndex:0];
}

- (void)liquidBottomNavDidSelectIndex:(NSInteger)index {
    self.activeTabIndex = index;
    if (index == 0) {
        self.brandHeaderLabel.text = @"LICENSE STATUS";
        self.homeGlassPanel.hidden = NO;
    } else if (index == 1) {
        self.brandHeaderLabel.text = @"SELECT GAME";
        self.gamesViewport.hidden = NO;
    } else {
        self.brandHeaderLabel.text = @"SETTINGS";
        self.settingsGlassPanel.hidden = NO;
    }

    [UIView animateWithDuration:0.30 delay:0 usingSpringWithDamping:0.80 initialSpringVelocity:0.8 options:UIViewAnimationOptionAllowUserInteraction animations:^{
        self.homeGlassPanel.alpha = (index == 0) ? 1.0 : 0.0;
        self.gamesViewport.alpha = (index == 1) ? 1.0 : 0.0;
        self.settingsGlassPanel.alpha = (index == 2) ? 1.0 : 0.0;
    } completion:^(BOOL finished) {
        self.homeGlassPanel.hidden = (index != 0);
        self.gamesViewport.hidden = (index != 1);
        self.settingsGlassPanel.hidden = (index != 2);
    }];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect b = self.view.bounds;
    for (CALayer *l in self.view.layer.sublayers) {
        if ([l.name isEqualToString:@"fougo_dash_bg"]) {
            l.frame = b;
        }
    }

    CGFloat topSafe = 50.0;
    CGFloat bottomSafe = 22.0;
    if (@available(iOS 11.0, *)) {
        topSafe = MAX(44.0, self.view.safeAreaInsets.top + 14.0);
        bottomSafe = MAX(18.0, self.view.safeAreaInsets.bottom + 8.0);
    }

    CGFloat contentW = MIN(b.size.width - 36.0, 396.0);
    CGFloat contentX = (b.size.width - contentW) * 0.5;

    self.topKickerLabel.frame = CGRectMake(contentX, topSafe, contentW, 16.0);
    self.brandHeaderLabel.frame = CGRectMake(contentX, topSafe + 20.0, contentW, 34.0);

    CGFloat navH = 62.0;
    CGFloat navY = b.size.height - bottomSafe - navH;
    self.bottomNav.frame = CGRectMake(contentX, navY, contentW, navH);

    CGFloat availTop = CGRectGetMaxY(self.brandHeaderLabel.frame) + 18.0;
    CGFloat availH = navY - availTop - 16.0;

    // Tab 0: Home Panel
    CGFloat homeH = MIN(310.0, availH);
    self.homeGlassPanel.frame = CGRectMake(contentX, availTop + (availH - homeH) * 0.5, contentW, homeH);
    UIView *hc = self.homeGlassPanel.contentView;
    for (NSInteger i = 0; i < 4; i++) {
        CGFloat rowY = 22.0 + i * 54.0;
        [hc viewWithTag:710 + i].frame = CGRectMake(24, rowY, contentW - 48, 14);
        [hc viewWithTag:720 + i].frame = CGRectMake(24, rowY + 16.0, contentW - 48, 22);
    }
    self.copyHwidButton.frame = CGRectMake(24, homeH - 58.0, contentW - 48, 42.0);

    // Tab 1: Games & Modules Viewport
    self.gamesViewport.frame = CGRectMake(contentX, availTop, contentW, availH);
    CGFloat gameCardH = 82.0;
    self.freeFireCard.frame = CGRectMake(0, 0, contentW, gameCardH);
    self.freeFireMaxCard.frame = CGRectMake(0, gameCardH + 12.0, contentW, gameCardH);

    CGFloat modY = (gameCardH + 12.0) * 2.0 + 4.0;
    CGFloat halfW = (contentW - 12.0) * 0.5;
    self.bodyModuleCard.frame = CGRectMake(0, modY, halfW, 74.0);
    self.neckModuleCard.frame = CGRectMake(halfW + 12.0, modY, halfW, 74.0);

    CGFloat btnY = modY + 88.0;
    self.applyModuleBtn.frame = CGRectMake(0, btnY, halfW, 48.0);
    self.restoreOriginalBtn.frame = CGRectMake(halfW + 12.0, btnY, halfW, 48.0);
    self.moduleStatusBanner.frame = CGRectMake(0, btnY + 56.0, contentW, 20.0);

    // Tab 2: Settings Panel
    CGFloat panelH = 280.0;
    self.settingsGlassPanel.frame = CGRectMake(contentX, availTop + MAX(0.0, (availH - panelH) * 0.5), contentW, panelH);

    UIView *sc = self.settingsGlassPanel.contentView;
    [sc viewWithTag:601].frame = CGRectMake(24, 74, contentW - 100, 28);
    self.refractionSwitch.frame = CGRectMake(contentW - 76, 72, 51, 31);
    [sc viewWithTag:602].frame = CGRectMake(24, 122, contentW - 100, 28);
    self.depthReactionSwitch.frame = CGRectMake(contentW - 76, 120, 51, 31);
    self.distortionSlider.frame = CGRectMake(24, 168, contentW - 48, 30);
    self.logoutKeyButton.frame = CGRectMake(24, 216, contentW - 48, 42);
}

@end

@interface FougoDashboardAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation FougoDashboardAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[FougoDashboardViewController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FougoDashboardAppDelegate class]));
    }
}
