#ifndef ProtectedConfig_h
#define ProtectedConfig_h

#import <Foundation/Foundation.h>

static NSString * const kFougoAppName = @"FOUGO EXTERNAL";
static NSString * const kFougoAppSubtitle = @"LICENSE AUTHENTICATION GATEWAY";
static NSString * const kFougoBundleVersion = @"4.0.0";
static NSString * const kFougoDefaultApiPort = @"5050";

#endif /* ProtectedConfig_h */
